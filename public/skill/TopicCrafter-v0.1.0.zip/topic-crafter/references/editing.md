# Editing an existing topic

A question is identified by **(CT key, variant number)**, which is
`(ct_key, question_no)` in JSON. Edits change content, never identities. For
fixes listed in a report from the Cerebry platform, follow `platform.md` →
"Fixing a platform issue report" instead.

## 1. Understand the request before you change anything

Skip this when the request is already precise ("Set 2, variant 3: change 12 to
15"). Otherwise:

1. **Triage the request.** Which kind of change is it?
   - **Content:** a wrong fact, a wrong answer, difficulty, coverage.
   - **Wording or style:** tone, length, hint style, contexts, names.
   - **Structure:** adding or removing sets or variants, reordering, changing a
     set's question type or difficulty.
   - **Display or formatting:** "it looks wrong", maths not showing, a picture
     missing.
   - **Mixed.**
2. **Find the end state.** What should the result look like? Ask for an example
   if needed.
3. **Find the scope.** One question, one set, some sets, or the whole topic?
   Don't ask for exact lists. "All sets with word problems" is enough.
4. **Use reference questions.** If the style they want is unclear, look for
   questions in the topic that already have it. Otherwise ask the creator to
   point at **1–2 questions they like**, and use those as the model.
5. **Display problems:** you can't see the preview. Ask which set and variant,
   and what they see. A screenshot helps.

Ask short questions with your suggestion attached. Allow **at most 2 rounds**.
If the intent is still unclear after that, say what's blocking and wait. Never
guess an edit.

Then **propose your interpretation** in a sentence or two and get a yes:

> "So: shorten the hints in sets 1–3 to one idea each, without giving the
> method away, and leave sets 4–6 as they are. Shall I go ahead?"

## 2. When a request needs a gentle correction

Politely say why in plain words, offer the better option, and let the creator
decide. Follow the order in `communication.md`.

| Request | The problem | Offer instead |
| --- | --- | --- |
| "Make variant 3 harder" | Variants of a set must be equally hard, or the test is unfair (`variants.md`). | A new, harder set on the same skill, or making every variant of the set harder. |
| "Add a few questions on a new idea to set 2" | A set holds versions of one question. A new idea belongs in a new set. | A new set, added to the plan for approval. |
| "Put A, B, C, D before the options" or "number the parts" | The platform labels and shuffles options and parts itself, so they would show twice. | Leave them out. The platform adds the labels. |
| "Make key words bold" | The platform doesn't show bold or italics in questions. | Rephrase so the key word stands out, or put it in quotation marks. |
| "Add this picture" (an attachment, or a web or stock link) | Only image links created on the Cerebry platform can be used. | "Could you share the image link from the Cerebry platform?" Or rewrite the question so it needs no picture. |
| "Add a video, audio clip or PDF link" | Only images are allowed in Cerebry topics. | A Cerebry image link, or a description in words. |
| "Change the answer to X" when X is wrong | The question would mark correct answers as wrong. | Explain the working briefly. If they meant different numbers, change the question to fit. |
| "The hint should give the answer" | Hints should help without giving the answer away. | A hint that points to the method or first step. |
| "Use dropdowns with fractions in them" | Dropdown choices can't show maths notation. | A multiple-choice question, which can show fractions. |
| "Make this a true/false: which of these is correct?" | True/false judges one statement. Choosing among several is multiple choice. | Multiple choice, or one true/false statement per question. |
| "Put two languages in one topic" | A topic has one language. | Two topics, one per language. |
| "Renumber the questions" or "rename the sets" | Numbers and keys are permanent IDs that the platform uses to track questions. | Reorder them, which keeps the IDs. Rename only if they insist, after confirming. |
| "Just edit the .json" | The `.json` must be made from the `.md`, or the two drift apart. | Edit the `.md` and rebuild the `.json`. |
| Anything that contradicts the approved plan | It changes what was agreed. | Update `ContentPlan.md` first, then edit. |

## 3. Start from the right file

- **You have `<topic_name>.md`:** edit it directly.
- **The creator edited the `.md` themselves:** use their file as the new base.
  Run the parser and validator, fix only format problems, and tell them in plain
  words what you fixed. Their `.json` is now out of date, so re-deliver both
  files.
- **They only have `<topic_name>.json`:** run
  `python3 scripts/topic_parser.py to-md <topic_name>.json` and edit the result.
  It keeps `Topic ID`, CT keys and variant numbers. Questions it reports as "kept
  as Raw JSON" are in `#### Raw JSON` blocks. Leave them alone unless the
  creator asked to change them.
- **There is no code execution:** follow `setup.md` → Chat-only fallback. You
  can't make a new `.json` in that case, so ask them to continue in a chat with
  code execution.

## 4. Locate before you change

Find each target by its `## CT <n>: <ct_key>` heading and its
`### Variant <number>` heading. If the creator names a question another way
("question 3 of the second set"), map it to the key and number, and name it back
in plain words ("Set 2, variant 3"). If a reference is ambiguous, ask instead of
guessing.

## 5. Allowed operations

| Request | What to do in `<topic_name>.md` |
| --- | --- |
| Change a question | Edit only that variant's sections. Keep its heading and number. If a premise changed, recompute every answer-bearing field: correct option, blank values, tolerance, regex, solution and hint. |
| Change a set's style or method | Ask whether every variant should follow, because variants must stay equivalent (`variants.md`). |
| Add variants to a CT | Write new equivalents of variant 1, or of the variant the creator names (`variants.md`). Append `### Variant <max+1>`, `<max+2>`, … at the end of the CT, then raise `Total variants:`. |
| Add a CT | Add it to `ContentPlan.md` and get approval first. If there is no plan, start one with just the new CTs. Then append `## CT <n+1>: <new_unique_key>` with `Type`, `Difficulty` and `Total variants`, number its variants 1, 2, 3…, and raise `Total CTs:`. |
| Delete a variant or CT | Remove its section and lower the count. Never renumber the others; gaps are fine. |
| Reorder | Move whole sections. Numbers stay with their questions. |
| Change a CT's type or difficulty | This changes every variant: rewrite all of them in the new type's sections. Confirm with the creator first. |

Never change `Topic ID`, an existing CT key, or an existing variant number unless
the creator explicitly asks for that structural change. Renaming a CT key is a
structural change, so confirm it first.

## 6. After editing

1. Run `python3 scripts/topic_parser.py to-json <topic_name>.md`. IDs and order
   come from the Markdown.
2. Run `python3 scripts/topic_validator.py <topic_name>.json`.
3. Fix only the reported errors, in at most 2 rounds (see SKILL.md).
4. Run `python3 scripts/topic_parser.py check-pair <topic_name>.md <topic_name>.json`.
5. Re-deliver both files with the same names and the "upload the .json"
   instruction (`platform.md` → Delivery message).
6. Summarise the changes in plain words, set by set and variant by variant.

Example summary:

> Done. Your topic now has 4 sets and 11 questions.
>
> - **Set 1 (One-step equations), variant 2:** changed 12 to 15 in the question
>   and reworked the answer, solution and hint to match.
> - **Set 3 (Equations with brackets), variant 1:** the hint gave the answer
>   away, so it now points to the first step instead.
> - **New set 4 (Word problems):** typed number answers, medium, 3 variants.
>
> I checked the format of every question. Please read the updated
> `linear_equations.md`, and when you're happy, upload
> `linear_equations.json` to the Cerebry topic ingestion platform.
