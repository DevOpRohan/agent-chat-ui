# Content guidelines

These are the platform's authoring rules, taken from the generation contract the
backend's own question crafter uses. The validator enforces the mechanical ones;
the rest are judged by reviewers, so follow them while drafting.

## Topic, CT and variants

- A **CT** (configuration type) is a family of equivalent questions: same
  concept, method, type, difficulty and cognitive load. Every learner gets a
  unique but equivalent question.
- **Variant 1** is the original question. The other variants are its
  equivalents. They change only surface details (values, names, context,
  equivalent objects and units, wording). The skill tested, the steps, the
  answer structure, the notation and the hint and solution style all stay the
  same.
- Every variant must be solvable on its own and must not refer to another
  variant. No two variants are near duplicates, and every variant's answer is
  worked out again. The full rules, examples and the per-variant check are in
  `variants.md`.
- Difficulty:
  - `EASY`: recall and simple one-step application.
  - `MEDIUM`: multi-step reasoning with moderate complexity.
  - `HARD`: complex problem solving or advanced concepts.
- Keep values realistic. For example, a ball doesn't weigh 100 kg.

## LaTeX (the most common failure)

- Inline math is `\( ... \)` and display math is `\[ ... \]`. In the `.md` use
  **single** backslashes; the parser handles JSON escaping.
- **Every number goes in LaTeX** (`\(25\)` m/s), and so do formulas, units with
  symbols, and operators. The exceptions are FIB/DROP_DOWN keyword values and
  DECIMAL `Value:` lines, which are plain.
- Abbreviations and short forms go in `\text{}` inside math: `\(\text{DNA}\)`, not `DNA` or `\(DNA\)`.
- Prefer `\dfrac` to `\frac`. Use `\frac` only in cramped spots such as exponents,
  subscripts, limits and log bases.
- Never nest delimiters. Write `\[ 220 - 19 = 201 \]`, not `\[ \(220\) - \(19\) \]`.
- A line break inside one LaTeX block is `\\`, never `\n`. Better still, use separate blocks on separate lines.
- Balance every `\(`/`\)`, `\[`/`\]` and `{`/`}`. The validator checks delimiter
  balance locally; the platform's LaTeX parser (server-side) also checks that each block compiles.
- Element symbols go in non-italic text (`\(\text{Na}\)`). Scientific names go in italics.
  Use `=` for exact values and `\approx` for approximations. Use \(3.14\) for π in science.

## Plain text, no Markdown

- Fields are plain text plus LaTeX. **No Markdown emphasis or headings inside a
  field**: no `**bold**`, `*italic*`, `_italic_` or `#` lines. The validator warns
  (`STYLE`) when it sees emphasis outside math.
- Scientific and biological names go in italic LaTeX: `\(\textit{Hydrilla}\)`,
  `\(\textit{E. coli}\)`. Element symbols go in upright LaTeX text: `\(\text{H}_2\text{O}\)`.
- If a question needs a passage, table or data set, put it in the question text.
  Never point to an external lesson, figure or document.

## Images (the only media allowed)

- **Images only.** Cerebry topics take no video, audio, PDF or other media
  links, and never use the `![…](url "video")` title form.
- **Cerebry image links only, confirmed first.** When the creator wants images,
  don't add any until both of these are true:
  1. the creator has given you the actual image link(s); and
  2. the creator has confirmed the links were created on the Cerebry platform.

  Ask plainly: "Please share the image links. Were they created on the Cerebry
  platform? I can only use image links from Cerebry." Only after they confirm
  may you put the links in questions.
- **Never invent, search for or generate links.** That rules out stock or web
  images, generated images, and placeholders such as `example.com`. The example
  files' links only show the syntax. Never copy them.
- **Files the creator attaches** (photos, PDF pages) can't go into a question
  themselves. Ask for the Cerebry link of that image instead.
- **Without a confirmed link:**
  - write the question so it needs no picture (describe the figure or the data
    in words), and say so in plain words; or
  - if the picture is essential, mark that question in `ContentPlan.md` as
    "needs a Cerebry image link" and wait for the link before writing it.
- The description in `![description](url)` says what the picture shows. Never
  refer to a figure, diagram or table that isn't in the question.

## Hints

- Exactly one line. A statement that ends with the language's period (`.` for
  English; see `languages.md`), never a question.
- Thought-provoking without giving the answer away. For example, "Consider the
  relationship between force and acceleration." is fine, but "The answer is
  mitochondria." isn't.
- Every base question needs a hint. That includes each part of a subpart question
  and **each MTC match**.
- Subpart parents carry no hint or solution of their own; those go inside the parts.

## Solutions

- Step by step, at the level of the grade and difficulty, and 100% correct.
- No "Step 1:" labels.
- Pick the layout that keeps reading effort low. A simple definition is one short
  paragraph. A concept with parts gets a few short paragraphs. A calculation is a
  worked solution with one step per line, joined by "So", "Therefore" or `\(\implies\)`.
- MCQ: never refer to options by letter or position, and never end with "Hence
  option B is correct". The platform shuffles options and appends that line itself.
- TRUE_FALSE: never say "the statement is true/false" or "first option".
  Explain the reasoning instead; the platform appends the verdict.

## No serial prefixes

The renderer numbers lists itself. Never prefix options, parts, match columns or
variants with `A.`, `1)`, `(a)`, `i.` or `Q1.`.

## Type behaviour worth knowing

- **MCQ**: options are shuffled at runtime. Make 4 plausible options that are
  parallel in form and similar in length; the correct one must not be the longest
  or most detailed. Each distractor should come from a real misconception, in the
  same domain. No "All of the above" or "None of the above" unless asked, and no
  near-duplicates. The solution explains why the answer is right and why the
  main distractors are wrong. For a multiple
  answer question (MSQ), mark several `[x]` and say "Select all that apply". The
  correct option text must match one option exactly.
- **FIB** (drag and drop) and **DROP_DOWN** (a dropdown per blank): mark blanks in
  the question with `{placeholder1}`, `{placeholder2}` and so on. Give each blank
  3 distractors unless the user asks otherwise. Distractors must be the same kind
  as the answer (same unit, style and part of speech), distinct, and never repeat
  the correct word.
- **MTC**: displayed on mobile. Keep each column to 2–3 words with one-to-one
  pairs, and give every match a hint and an explanation. The platform's preview
  needs the explanation, so never leave it out.
- **DECIMAL / MATH_EXPRESSION / PATTERN_MATCH** (typed answer boxes): the question
  text has **no** `{placeholderN}` tokens and no `____` blanks. Tokens appear only
  in the Answer box, each exactly once, numbered 1..N in order (numbering restarts
  in every part).
  - DECIMAL: for any plain numeric answer, whole numbers included. `Value:` is a
    plain number in the displayed unit; put units in the answer box (`{placeholder1} m`).
    Use exact tolerance (`0`/`0`) unless the stem states a rounding or measurement rule,
    and match `Min decimal places` to the precision asked. Use `Answers interchangeable: true`
    only for an unordered set of answers (never with one placeholder).
  - MATH_EXPRESSION: for symbolic answers. Use `Matching: EXACT` when a specific form
    is assessed (factorised, simplified, expanded), and `EQUIVALENT` only when any
    equivalent form is acceptable. `Variables:` lists exactly the free symbols.
    Every value and alternative is wrapped in one delimiter pair (`\((x+1)^2\)`)
    and contains no `#`. Alternatives must be mathematically equal to the value
    and different from it.
  - PATTERN_MATCH: for text graded by a regex. Define exactly which answers are
    accepted, write a full-match regex (`^…$`), and give positive examples that
    match it. Avoid catch-alls like `.*`; prefer `[0-9]` to `\d`; escape literal
    punctuation; avoid nested quantifiers. Keep to syntax every regex engine shares:
    no inline flags such as `(?i)`, no lookbehind and no named groups. The offline
    check uses Python, but the learner-side grader is not verified. For case
    tolerance, use classes such as `[Tt]he`.
- **Subpart types**: one shared context with 2–4 connected parts (unless asked
  otherwise), each independently answerable. HYBRID_SUBPART mixes at least two
  base types. Across DECIMAL parts, every non-zero tolerance must be the same pair.

## Safe contexts

Questions are for school learners, so every setting must be safe to copy at home
or in class.

- Never tell or suggest learners to taste, smell, mix or heat chemicals or
  cleaning products. For example, never mix vinegar or acids with bleach-type
  cleaners. Stating a textbook fact, such as "acids taste sour", is fine; an
  instruction to try it isn't.
- Use everyday, low-risk substances and adult supervision for any activity, and
  avoid fire, electricity, sharp tools or medicines unless the curriculum
  requires them, described safely.
- When the approved plan's context could read as unsafe, choose a safe version
  and tell the creator in plain words.

## Don't

- Don't reference images, diagrams or tables that aren't in the question as a
  confirmed Cerebry image link or as text (see Images above).
- Don't leave template text, cut-off sentences, circular reasoning or fictional facts
  (no compounds like C₂H₇).
- Don't invent answers you aren't sure of. Ask the user, or flag the question in your summary.
