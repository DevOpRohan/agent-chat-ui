# Languages

A topic has one language (v1). Put it in the topic header as `- Language: <name>`,
spelled exactly as below (matching is case-insensitive, and the parser writes
this exact spelling). Every question, and every DECIMAL / MATH_EXPRESSION /
PATTERN_MATCH part, gets it in JSON.

| Language | Sentence end | Notes |
| --- | --- | --- |
| English | `.` | |
| Arabic | `.` | Right-to-left text. Keep LaTeX and numbers in LaTeX delimiters. The question mark is `؟`. |
| Hindi | `।` | Hints and solutions end with the danda `।`. |
| Traditional Chinese | `。` | Full-width punctuation; the question mark is `？`. |
| Vietnamese | `.` | |
| Bahasa | `.` | Indonesian. |
| Japanese | `。` | Full-width punctuation. |
| Filipino | `.` | |
| Uzbek | `.` | |
| Russian | `.` | |
| Azerbaijani | `.` | |
| Kyrgyzstan | `.` | The platform's name for Kyrgyz; write `Kyrgyzstan`. |
| Korean | `.` | |
| Malay | `.` | |
| Cebuano | `.` | |
| Hiligaynon | `.` | |
| Ilocano | `.` | |
| Waray | `.` | |
| Spanish | `.` | |
| Portuguese (Portugal) | `.` | European Portuguese; include the parentheses. |
| French | `.` | |
| Tamil | `.` | |

Rules that the validator enforces or the platform expects:

- **Hints** are one line, read as statements, and end with the sentence-end mark
  in the table (not `?`, `؟` or `？`).
- Write every learner-visible field in the topic language: question, options,
  placeholders' keywords, answer-box labels, solution, hint and match text. Keep
  LaTeX commands themselves (`\dfrac`, `\text{}`) as they are; translate the words
  inside `\text{...}`.
- Plain numbers in DECIMAL `Value:` lines always use `.` as the decimal point,
  whatever the language.
- Regexes for PATTERN_MATCH must accept the script the learner will type in.
- If the user asks for a language that isn't in this list, say so and ask them to
  pick one from it. Don't silently fall back to English.
