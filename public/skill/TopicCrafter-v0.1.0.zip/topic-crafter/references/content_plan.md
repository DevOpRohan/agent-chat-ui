# Clarifying questions and the ContentPlan

This page covers Steps 1 and 2 of SKILL.md: what to ask first, how to use the
creator's source material, the `ContentPlan.md` template, and when the plan
counts as approved.

## 1. Clarifying questions (first reply)

- Ask **4–6 questions** on whatever the request leaves open. Never ask about
  something the creator already told you. If the request already covers the
  usual points, ask the next most useful ones: style and tone, real-life
  contexts, misconceptions to target, how hard "hard" should be, or solution
  detail. Always ask at least 4 in the first reply. Only if the creator says
  "use your defaults" or "no questions" in their first message, go straight to
  the plan and list your choices under Assumptions.
- **Recommend a default for every question**, so the creator can answer only
  the ones they care about, or say "go with your defaults".
- You can merge related points into one question, such as grade and board.
- Allow **at most 2 rounds** and **at most 6 questions per round**. Use a second
  round only for blockers, for example when answers conflict, an unsupported
  language is asked for, or the source material is unreadable. After round 2,
  write the plan with stated assumptions and put anything still unclear under
  Open questions.

### Question bank

Pick the 4–6 that matter most for this request. They are roughly in priority
order. When sets will have more than 1 variant, always include **Mode**.

| Topic | Ask | Recommended default |
| --- | --- | --- |
| Audience and grade | Who are the learners: grade or age, and ability level? | Infer it from the request. If there's no clue, Grade 8, mixed ability. |
| Curriculum or board | Which curriculum or board should it follow (CBSE, ICSE, Cambridge, IB, a state board…)? | Infer it from the request, otherwise CBSE. Learning goals are written with Bloom's levels in mind. |
| Concepts and scope | Which chapter or concepts, and anything to leave out? | The standard sub-skills of the topic for that grade, from basic to applied. |
| Size | How many question sets (CTs), and how many variants (equivalent versions) of each? | 6 sets with 5 variants each, 30 questions in all. The limit is 20 sets and 20 variants per set. |
| Mode | Shall I write the first question of each set for you to check, and add the other versions once you're happy (Pragmatic)? Or write everything in one go for you to review at the end (Blitz)? | Pragmatic when the questions need multi-step reasoning or calculation, long worked solutions or heavy logic. Blitz when they are short and direct with brief solutions. If unsure, Pragmatic. In Pragmatic, the first questions come all together unless the creator wants them one at a time. |
| Question types and mix | Which kinds of questions: multiple choice, fill in the blanks, typed number answers, true or false, matching, written answers? | Mostly multiple choice. Use typed number answers for calculations, fill in the blanks for key terms, and one written-answer set for reasoning. |
| Difficulty mix | What share of easy, medium and hard? | 40% easy, 40% medium, 20% hard. With only a few sets, use the closest whole-set split (3 sets: one easy, one medium, one hard) and say so. |
| Language | Which language should the questions be in? | English, or the language the creator writes in (see `languages.md`). |
| Source material | Do you have a textbook chapter, worksheet or past paper I should follow? | None. Follow the curriculum. |
| Style | Any preferences, such as real-life contexts, local names and currency, hint length, or how detailed the solutions are? | Real-life contexts for the grade, local names and units, one-line hints, and step-by-step solutions. |
| Images | Do any questions need pictures? I can only use image links created on the Cerebry platform. | No images. Write every question so it works without a picture. |

Always state the platform defaults you will use, so the creator approves real
numbers. MCQ has 4 options. FIB and DROP_DOWN have 3 wrong choices per blank.
MTC has 4–6 pairs. A question in parts has 2–4 parts.

### Example first reply

> Happy to build this with you! A few quick questions first. Each has my
> suggestion, so you can just say "go with your defaults".
>
> 1. **Learners:** Which grade, and which board? *My suggestion: Grade 8, CBSE.*
> 2. **Scope:** Should it cover the whole chapter on photosynthesis, or only the
>    process and its raw materials? *My suggestion: the whole chapter, from
>    inputs and outputs to the factors that affect the rate.*
> 3. **Size:** How many question sets, and how many versions of each question?
>    *My suggestion: 6 sets × 5 versions = 30 questions.*
> 4. **Question kinds and difficulty:** *My suggestion: mostly multiple choice,
>    plus one fill-in-the-blank set for key terms and one short written-answer
>    set; 40% easy, 40% medium, 20% hard.*
> 5. **How we work:** I can write the first question of each set for you to
>    check, and add the other versions once you're happy with them
>    (Pragmatic). Or I can write everything in one go, and you review the
>    finished topic (Blitz). *My suggestion: Blitz, because these questions
>    are short, with brief answers. For questions with several steps of working
>    or long solutions, I'd suggest Pragmatic.*
> 6. **Pictures:** Do you need diagrams? I can only use image links made on the
>    Cerebry platform. *My suggestion: no pictures. I'll describe things in
>    words instead.*
>
> Once you reply, I'll send you a content plan to check before I write anything.

## 2. The creator's source material

When the creator attaches a PDF, textbook pages, a worksheet or photos of pages:

- **Read it before you plan.** If it is long, ask which chapter or pages to
  use, and don't work through a whole book. If you have code execution, extract
  the text. If a page is scanned and you can't read it, say so and ask for a
  clearer copy or the text itself. Never guess at content you couldn't read.
- **Agree on how to use it.** Either:
  - **inspired by** it: new questions matched to its scope, terms and level; or
  - **adapted** from it: its own questions put into the topic format, keeping
    their wording and answers.

  Record the choice in the plan's overview.
- **Follow it.** Use its terminology, notation, units, examples and level. If
  the source has an error, point it out and don't copy it.
- **Note your sources.** For each CT, say which pages or exercises it draws on.
- **Pictures in the source can't be used** directly. The image rule applies
  (`content_guidelines.md` → Images): only image links that the creator gives
  and confirms come from the Cerebry platform.
- Don't copy long passages word for word unless the creator asks you to adapt
  their own material.

## 3. ContentPlan.md template

Write the plan as a file named `ContentPlan.md`. In chat, add a short summary:
the sets and question totals, the difficulty spread, and the one to three
choices most worth a second look.

Write maths so a person can read it (3x + 5 = 20, x², ½). LaTeX belongs only in
the topic file. `ContentPlan.md` is not a topic file, so never run the parser on
it.

```markdown
# Content plan: <Topic name>

Version 1 · draft for your review · no questions written yet
Files to deliver: <topic_name>.md and <topic_name>.json

## Overview

- **Audience:** <grade or age, ability level>
- **Curriculum:** <board, syllabus, chapter>
- **Language:** <one of the supported languages>
- **Source material:** <none / title and pages, and "inspired by" or "adapted">
- **Learning goals:** by the end, learners can:
  1. <goal, with a verb such as identify, explain, calculate, compare>
  2. <goal>
  3. <goal>
- **Size:** <N> question sets × <variants> variants = <total> questions
- **Difficulty spread:** Easy <n sets / n questions / %> · Medium <…> · Hard <…>
- **Question kinds:** <for example: multiple choice ×3, fill in the blanks ×1, typed number ×2>
- **Mode:** <Pragmatic: the first question of each set is reviewed first (all together / one at a time), then the variants · or Blitz: everything in one go>
- **Assumptions:** <every default you chose that the creator didn't state>

## At a glance

| # | Question set | Kind (type) | Difficulty | Variants |
| --- | --- | --- | --- | --- |
| 1 | <plain title> | Multiple choice (MCQ) | Easy | 5 |
| 2 | <plain title> | Typed number (DECIMAL) | Medium | 5 |

## Question set 1: <plain-language title>

- **CT key:** `<name>_ct_001`
- **Learning objective:** <what a learner who gets this right can do>
- **Concept or skill tested:** <the precise idea or skill>
- **Why this set exists:** <its role in the topic, such as foundation, common
  error, application or stretch>
- **Question type:** <type, in plain words and its code> · **Why:** <why this
  type fits the skill>
- **Difficulty:** <Easy / Medium / Hard> · **What it means here:** <for example,
  "one step, whole numbers, the context states the formula">
- **Variants:** <n>
  - **What changes between variants:** <values, names, contexts, objects>
  - **What stays fixed:** <method and steps, answer structure, number of
    options, notation, hint style>
- **Sample question (draft of variant 1):**
  > <the stem as the learner will see it, with maths written readably>
  >
  > Options (MCQ): <the correct one marked "(correct)">, or blanks or answer boxes
  > **Answer:** <the correct answer, with one line of working if it helps>
- **Misconceptions the wrong choices target** (MCQ, FIB, DROP_DOWN only):
  - <wrong choice>: <the mistake it catches>
  - <wrong choice>: <the mistake it catches>
  - <wrong choice>: <the mistake it catches>
- **Media and notation:** <"none"; or notation needs such as chemical formulas,
  units or fractions; or "needs a Cerebry image link: <what the picture shows> ·
  waiting for your link">
- **Source:** <pages or exercise, if there is source material>

## Question set 2: <plain-language title>

…

## Coverage and progression

- **Goal coverage:** goal 1 → sets 1, 2 · goal 2 → sets 3, 4 · goal 3 → sets 5, 6
- **Progression:** <how the sets build, for example from recall to application
  to reasoning>
- **Balance:** <conceptual vs procedural vs applied; question kinds; difficulty>
- **Left out on purpose:** <sub-topics not covered, and why>

## Open questions

1. <question> · My suggestion: <default>
2. <question> · My suggestion: <default>

## Review notes

<Pragmatic only, filled in while the creator reviews the first questions: the
preferences they stated that the questions alone don't show, in their words.>
```

Notes on filling it in:

- Write one section per CT, in the order they will appear in the topic.
- **The sample question is a real draft of variant 1**, with its answer worked
  out. It is how the creator judges style and level before anything is written,
  so make it good.
- Base "what changes" and "what stays fixed" on `variants.md`.
- Give misconceptions only for MCQ, FIB and DROP_DOWN, including those parts
  inside subpart questions. Each wrong choice names the specific mistake it
  catches.
- **Images:** if a question really needs a picture and you have no confirmed
  Cerebry link yet, write "needs a Cerebry image link: <what it shows> · waiting
  for your link" and list it under Open questions. Otherwise, design the
  question so it needs no picture, and say so.
- Keep each CT section to about 12 lines. The creator should be able to read
  the whole plan in a few minutes.

## 4. Approval: a hard stop

- End the plan message with one direct question, such as: "Does this plan
  match what you need? Tell me what to change, or say 'approved' and I'll start
  writing."
- **Write no questions in the same turn**, and none until the creator
  explicitly approves. In Pragmatic mode, the ask ends "…and I'll write the
  first question of each set for you to check."
- **These count as approval:** "approved", "yes, go ahead", "looks good, start",
  or "go with this plan".
- **These do not count:** silence, "thanks", praise, a question about the plan,
  comments on some sets only, or a vague "ok" in reply to a change. When in
  doubt, ask one line: "Great. Shall I start writing all 30 questions now?"
  (Pragmatic: "Shall I write the first question of each set now?")
- **"Approved, with one small change"** counts as approval if the change is
  small and clear, such as "make set 3 medium". Update the plan, say what you
  changed, and start. If the change is large or unclear, share the updated plan
  and ask again.
- **Tweaks:** update `ContentPlan.md`, raise the version, add a line at the top
  saying what changed, share it again and ask again. Plan revisions don't count
  as clarification rounds. Review notes added in Pragmatic mode (SKILL.md, 3b)
  don't need a new plan version or a new approval.
- **"Skip the plan, just write it":** explain in one line that the plan is a
  quick check that saves rework. Show it, keep it compact, and still wait for a
  yes.
- **The approved plan is the contract.** Write exactly what it says. If
  something can't be done as planned, for example an image link never arrived,
  tell the creator and offer an alternative before you deviate.
- **New requirements mid-way:** pause, update the plan, and confirm before you
  continue.
