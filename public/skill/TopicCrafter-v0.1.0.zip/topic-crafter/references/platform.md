# The Cerebry topic ingestion platform

This page explains what happens to your files after delivery, what to tell the
creator, and how to handle what the platform sends back. These are Steps 5 and
7 of SKILL.md.

## What the platform does

The creator uploads **`<topic_name>.json`** to the **Cerebry topic ingestion
platform**. The platform accepts only the `.json`, never the `.md`. Then:

1. It **checks every question** with the same rules as this skill's validator.
   It also runs one more check on how maths is written (a LaTeX compile check)
   that isn't available offline.
2. **All good:** it saves the topic and gives the creator a **preview link**.
3. **Problems found:** it runs an **automatic fixer once**. The fixer repairs
   syntax, structure and styling only: maths formatting, punctuation, field
   layout. It never changes meaning or correct answers. The platform then
   returns the fixer's report and a preview, plus an **issue report** for
   anything still open.
4. **Some checks couldn't run** because a platform service was busy or down.
   That is not a problem in the topic, and the creator just uploads it again
   later.

So:

- **The `.json` must come from the parser.** It is the only file the platform
  reads. A hand-written or stale `.json` fails, or silently drops the creator's
  latest edits.
- **The `.md` is the creator's readable copy** for reviewing and editing. When
  it changes, the `.json` must be rebuilt from it before the next upload.
- **The checks are about format, not about whether answers are right.** Neither
  your validator nor the platform checks that an answer is correct or that a
  question teaches well. That is what the creator's review is for, so ask for it.

## Delivery message (Step 5)

Adapt this to the topic and keep it short and warm. Name the real files.

> Your topic is ready: **Photosynthesis (Grade 8)**, 6 question sets and 30
> questions (12 easy, 12 medium, 6 hard).
>
> - **`photosynthesis_grade_8.md`**: please open this one and read it through.
>   It's the readable version of your topic.
> - **`photosynthesis_grade_8.json`**: the same topic in the form the platform
>   reads, an exact mirror of the `.md`. There's no need to open it.
>
> I checked the format of every question. Two things I'd like your eye on:
> <set and variant, in plain words>.
>
> Would you like any tweaks or updates?
>
> When it looks good, upload the **.json** file (`photosynthesis_grade_8.json`)
> to the **Cerebry topic ingestion platform**. The `.md` is your readable copy
> for reviewing and editing; the platform only takes the `.json`. The platform
> checks the topic again and may fix small formatting issues automatically. If
> it reports a problem or gives you an issue report, bring the report back here
> and I'll fix it. If you edit the `.md` yourself, send it back to me first so I
> can rebuild the `.json`.

If the topic has maths, you can add: "In the `.md`, maths has small formatting
marks around it. They turn into proper maths in the platform's preview."

If the full check couldn't run here (pydantic was missing), replace "I checked
the format of every question" with: "I checked the layout of every question by
hand. The Cerebry platform will run the full check when you upload."

## What to check in the preview

Offer this list once the creator has the preview link, or when they ask what to
look at:

- **Answers:** try a few questions as a learner would. Is the marked answer
  right? Is any wrong choice also right?
- **Maths and symbols** display properly: no stray codes or broken fractions.
- **Pictures** load, and match what the question says.
- **Hints** help without giving the answer away. **Solutions** are clear and at
  the right level.
- **Difficulty** feels right for the grade, and the variants of a set feel
  equally hard.
- **Language:** spelling, wording and tone.
- **Nothing refers to a picture or table that isn't there.**
- **If the platform fixed anything:** look at those questions first. They are
  listed in its fixer report.

## What the platform may say, and what you do

Status names can change. Go by what the report says.

| The platform says | Meaning | What you do |
| --- | --- | --- |
| The topic is valid (`valid`) | It is saved and has a preview link. | Ask the creator to review the preview (list above). |
| It fixed every issue (`fixed`) | The fixer changed some questions, and the platform's copy is now valid. | Ask them to look at the fixed questions in the preview. Offer to copy the same fixes into the `.md` (they share the platform's report) so that their copy matches the platform's before any later edit. No re-upload is needed. |
| Issues remain (`needs_author_fixes`) | Problems the fixer didn't or couldn't fix, sometimes after it fixed others. | Fix them as described below. |
| The fix step failed (`updater_failed`) | The fixer itself failed, so the listed problems are still open. | Fix them as described below. |
| Some checks couldn't run (`validation_incomplete`) | A platform service was unavailable. This is not a problem in the topic. | Change nothing, and ask them to upload the same `.json` again later. |
| The file couldn't be read (`invalid_input`) | The wrong file, an empty file, a non-JSON file, or one larger than 10 MB. | Check that they uploaded `<topic_name>.json`. Re-deliver it if needed. |

## Fixing a platform issue report (Step 7)

An issue report lists problems by **CT key** and **variant number**, usually
under one heading per CT key and one per variant. Each line names the kind of
problem (a code in brackets), the field and a message. Topic-level problems,
such as duplicate CT keys or a missing ID, are listed separately. Warnings are
optional to fix.

1. **Start from the right `.md`:** the one that produced the `.json` they
   uploaded. Use your latest copy, or ask the creator to attach it. If they only
   have the `.json` (the `.md` is lost), run
   `python3 scripts/topic_parser.py to-md <topic_name>.json` first.
2. **Find each issue** in `<topic_name>.md` by its `## CT <n>: <ct_key>`
   heading and `### Variant <n>` heading. Use the field name (`hint`,
   `options`, `subparts[1].solution`, `placeholders[0].value`…) to find the
   exact section.
3. **Fix only the listed items.** Keep every CT key, variant number, the Topic
   ID and every correct answer. Don't touch other questions, and don't
   "improve" anything.
4. **If a fix would change an answer or the meaning,** don't make it on your
   own. Explain the choice to the creator in plain words and ask.
5. **Maths-format findings** come from the platform's extra check, so your
   validator may not reproduce them. Read the message and fix the LaTeX it
   names. Common causes are nested delimiters, unbalanced braces, `\text{}`
   outside maths, a line break inside `\( \)`, or an unusual command. Keep the
   same maths.
   **If you can't find what the report names** (the field, the maths or the
   variant isn't there, or it already looks right), don't guess and don't change
   a correct question. Check that the creator uploaded the latest `.json` you
   gave them, re-share the current pair, and ask them to upload it again. If the
   same issue comes back, ask for the new report and a screenshot of that
   question in the platform's preview, then fix exactly what it shows.
6. **Re-run the parser** to regenerate `<topic_name>.json`, then the validator
   (Step 4, with the same 2-round fix budget), then `check-pair`.
7. **Re-deliver both files** with the same names and the same "upload the
   .json" instruction. Add a short plain list of what you fixed, such as "Set 2
   (Two-step equations), variant 3: a hint ended with a question mark; it's now a
   statement."

## The fixer's report

In the platform's report this is the section **"The platform's automatic
fixes"**. It lists, per question (CT key and variant), what the fixer **fixed**
and what it **did not fix**.

- **Fixed items** are already in the platform's copy. To keep the creator's
  `.md` in step, apply the same changes to the same sections, then rebuild the
  `.json`. If the creator can download the platform's fixed topic `.json`,
  converting that with `to-md` is even more exact. Do this before any further
  edit, or the next upload will send the unfixed questions again.
- **Items it did not fix** are treated like an issue report (above).
