# Variants: the core idea

Read this before you plan or write any CT. It follows the definitions in the
platform's own generation prompts, which are the source of truth.

## What a variant is

A **CT** (configuration type) is a family of **equivalent questions**. The
platform gives different learners different variants of the same CT, so every
learner gets a **unique but equivalent** question. Learners can't copy from each
other, and the assessment is still fair.

- **Variant 1 is the original.** You design it first: it is the sample question
  in the ContentPlan.
- **Every other variant is an equivalent of variant 1.** It tests the exact same
  concept, with the same method, at the same difficulty, with the same cognitive
  load and in the same format. Only surface details change.
- The rule of thumb is **"different on the surface, identical underneath"**.

## In plain words, for the creator

If the creator asks "what's a variant?", say something like:

> A question set has several versions of the same question, which we call
> variants. Each learner gets a different version, so they can't copy, but every
> version is equally fair: same idea, same steps, same difficulty, and only
> things like the numbers, names or setting change. Variant 1 is the original,
> and the others are its look-alikes.

## What must stay the same (the invariants)

| Keep | What it means in practice |
| --- | --- |
| Concept and skill | It tests the same idea, rule or skill as variant 1. |
| Solution method and number of steps | The same method solves it, in the same steps. No shortcut appears, and no extra step is added. |
| Cognitive load and difficulty | It takes the same effort. The numbers are of similar size and kind (whole, decimal, negative), and the words are of similar familiarity. |
| Question type and format | It has the same type and the same layout. Subparts keep the same parts, of the same types, in the same order. |
| Answer structure | It has the same number of options, blanks, matches, parts or answer boxes, and the same kind of answer (a number with the same precision and unit, a word, an expression in the same form). One or several correct MCQ options stays the same. |
| Notation and LaTeX style | If variant 1 writes a term in LaTeX, `\text{}` or `\dfrac`, the variants do too. Units, symbols and variable names follow the same conventions. |
| Hint and solution style | The hint points to the same idea in the same tone. The solution has the same layout and depth. |

## What may change

- Numbers and values.
- Names of people, places and organisations.
- The real-world context or scenario (a shop becomes a school fair).
- Objects and units, where that is equivalent (apples become oranges, metres
  become centimetres, but only if the conversion load doesn't change).
- Wording, while it keeps the same reading level and length.

## Principles

1. **Independently solvable.** Each variant is complete on its own. It never
   refers to another variant or "the previous question".
2. **Realistic values.** A pencil isn't 3 m long, and a ball doesn't weigh
   100 kg. Facts and data must be true.
3. **Not redundant.** No two variants are near duplicates. Swapping two numbers
   that give the same answer, or changing only a name, is not enough. Vary the
   values and, where it fits, the context.
4. **Answers worked out again for every variant.** Recompute the answer, then
   update everything that depends on it: the correct option, the blank values,
   `Value:` lines, tolerance, regex and examples, the solution and the hint. A
   variant whose solution still shows variant 1's numbers is wrong. For numeric
   answers, one quick calculation in code is a good check.
5. **MCQ wrong choices re-derived.** Rebuild each wrong choice from the *same*
   misconception as in variant 1, using the new values. For FIB and DROP_DOWN,
   build the wrong choices from the same kinds of mistake.
6. **No accidental difficulty drift.** Watch for values that make the
   arithmetic much harder (large primes, awkward decimals) or trivially easy
   (multiplying by 1 or 10). Watch for contexts that need knowledge variant 1
   didn't need.
7. **TRUE_FALSE may flip.** Variants of a true/false CT may have different
   answers (True in one, False in another), as long as the concept and the
   reasoning stay the same.

## Examples

**Maths: area of a rectangle (EASY, DECIMAL)**

Variant 1: "A rectangle has length \(12\) m and width \(8\) m. Find its area."

- ✅ "A rectangle has length \(15\) m and width \(6\) m. Find its area." It has
  the same concept and the same single multiplication. Only the values change.
- ✅ "A garden bed is \(10\) m long and \(9\) m wide. Find its area." This is a
  new context with the same method and load.
- ❌ "A rectangle has length \(8\) m and width \(12\) m. Find its area." It is a
  near duplicate, with the same numbers swapped and the same answer.
- ❌ "A rectangle has area \(96\) m² and length \(12\) m. Find its width." It is
  the inverse problem, so the method differs.
- ❌ "A rectangle has length \(12.75\) m and width \(8.36\) m. Find its area."
  This is difficulty drift: the arithmetic is far harder than in variant 1.

**Maths: an MCQ with misconception distractors (MEDIUM)**

Variant 1: "\(35\%\) of \(800\) students walk to school. How many walk?" The
options are \(280\) (correct), \(520\) (the complement), \(28\) (decimal point
misplaced) and \(2800\) (multiplied by \(10\) too many).

- ✅ "\(15\%\) of \(1200\) books are science books. How many?" The options are
  \(180\), \(1020\), \(18\) and \(1800\), so the same three mistakes are rebuilt
  with the new values.
- ❌ The same stem with options \(100\), \(180\), \(250\) and \(300\). These
  wrong choices are random numbers and no longer catch the planned mistakes.

**Science: rate of photosynthesis (MEDIUM, MCQ)**

Variant 1: "A pondweed gives off \(12\) bubbles a minute under a lamp. The lamp
is moved closer. What happens to the bubble rate, and why?"

- ✅ The same reasoning with a different plant (\(\textit{Elodea}\)), a
  different starting rate and "moved further away". It is the same concept (the
  effect of light intensity), the same one-step reasoning, and the same four
  answer shapes.
- ❌ "...The water is warmed instead." This changes the concept tested
  (temperature, not light).
- ❌ "...and calculate the percentage change in rate." This adds a calculation
  step, so the method and the load change.

**Science: half-life (HARD, DECIMAL)**

- ✅ Change the half-life (for example \(4\) to \(12\) hours), the concentration
  and the time span within realistic ranges. Recompute the answer each time.
- ❌ Ask for the decay constant instead of the dose. It is the same topic, but a
  different method and a different answer.

**Language: synonyms (EASY, MCQ)**

Variant 1: "Choose the word closest in meaning to 'brave'."

- ✅ "...closest in meaning to 'happy'." The target word is just as common, and
  the options are four single words of the same part of speech.
- ❌ "...closest in meaning to 'pusillanimous'." The word is far rarer, so the
  difficulty drifts.
- ❌ "...the word *opposite* in meaning to 'happy'." The skill changes from
  synonyms to antonyms.

**Language: past tense of regular verbs (EASY, FIB)**

- ✅ "Yesterday Meena {placeholder1} to the market." The answer is *walked*. A
  variant asks the same with *jumped* or *played*.
- ❌ The same with *went*. An irregular verb is a different skill.

**Humanities: reading a timeline (MEDIUM, DECIMAL)**

Variant 1: "A fort was built in \(1526\) and captured \(31\) years later. In
which year was it captured?"

- ✅ It changes the event, the place and the numbers, and keeps one addition of
  similar size.
- ❌ "...captured in \(1557\). How many years after it was built?" The question
  is reversed, so the method differs. Make that a separate CT if both are wanted.

**Independence and realism**

- ❌ "Using your answer to variant 2, find..." Every variant must stand alone.
- ❌ "A cyclist rides at \(240\) km/h." The value is unrealistic.

## Equivalence check (run it once per variant)

Use this as part of the one-draft mental checklist in SKILL.md. It isn't a
regenerate loop.

1. **Same concept?** It tests what variant 1 tests.
2. **Same method?** Same steps, same number of steps.
3. **Same cognitive load?** It has numbers and words of the same kind and
   difficulty, and no drift.
4. **Same type and answer structure?** It has the same sections, the same count
   of options, blanks or parts, and the same kind of answer.
5. **Answer recomputed?** The answer key, solution and hint match *this*
   variant's values.
6. **Distinct and self-contained?** It is not a near duplicate of any sibling,
   and it doesn't refer to other variants.
7. **Same notation and style?** It follows variant 1's LaTeX, units, hint and
   solution style.

## Where this shows up

- **In the ContentPlan:** every CT section says "What changes between variants"
  and "What stays fixed" (see `content_plan.md`). Base them on the lists above.
- **When writing:** variant 1 is the plan's sample question, finished. Write the
  others from it. In Pragmatic mode (SKILL.md), variant 1 is the base question
  the creator reviewed. The others copy it as it now stands, not the plan's
  first draft.
- **When editing:**
  - "Add variants" means writing new equivalents of variant 1, or of the
    variant the creator names, numbered from the CT's highest number + 1.
  - When the creator changes variant 1's style or method, ask whether every
    variant should follow, so the CT stays equivalent.
  - A request like "make variant 3 harder" would break equivalence. Explain why,
    and offer a new, harder CT instead, or a change to every variant of the CT.
- **When the creator wants something else:** if they want one question per
  sub-case or per concept, that is several CTs, not variants. Explain this
  kindly and propose separate CTs. If they still prefer their way, follow it and
  say so in your summary.
