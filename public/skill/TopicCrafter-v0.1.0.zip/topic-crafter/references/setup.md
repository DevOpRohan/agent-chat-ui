# Setup, fallbacks, long topics and resuming

## What you need

| Capability | Needed for | Required? |
| --- | --- | --- |
| Code execution (Python 3.8+) | Running the parser, which is the only way to make the `.json`, and the validator | **Yes** |
| File creation (files the creator can download) | `ContentPlan.md`, `<topic_name>.md`, `<topic_name>.json` | **Yes** |
| Subagents (parallel helpers) | Writing several CTs at once (path B) | No. It only adds speed. |

How to check, silently: run `python3 <skill folder>/scripts/topic_parser.py --help`
(or `python`). If it prints usage, you have code. Then check whether you can
create a file the creator can download.

## Finding the scripts and choosing a folder

- The **skill folder** is the folder that holds `SKILL.md`. Paths in this skill,
  such as `scripts/topic_parser.py`, are relative to it. Call the scripts by
  their full path.
- If the skill came as a `.zip` attachment instead of an installed skill, unzip
  it into a working folder first.
- **Write your files in your normal working or output folder,** not in the skill
  folder, which may be read-only. Share them from wherever your environment
  makes files downloadable.

## When code execution or file creation is missing

Tell the creator in your first reply, in plain words, and carry on with the
questions and the plan. Don't write any questions until the tools work, or until
the creator tells you they can't turn them on.

> To check your topic and make the file the Cerebry platform needs, I need
> **code execution and file creation**, which seem to be off in this chat.
>
> - **ChatGPT:** turn on *Code Interpreter* (also called *Data analysis*). In a
>   GPT or project, it's a checkbox under Capabilities.
> - **Claude:** go to *Settings → Capabilities* and turn on *Code execution
>   and file creation*.
>
> Then start a new chat and send your request again, with your answers to my
> questions below. If you can't turn it on, tell me and I'll do what I can here.

## Chat-only fallback (path C)

Use this only when the creator confirms they cannot turn the tools on.

- Write the topic exactly as in Step 3, CT by CT, and post each CT in a
  ```` ```markdown ```` code block. Leave out `Topic ID`.
- Check each CT by hand with the checklist below, and say "written, checked by
  hand" in your progress line.
- **Never write JSON yourself,** not even "just this once".
- Say this plainly at delivery:

  > Here is your topic as text. I couldn't run the checks or make the `.json`
  > file in this chat, and **the Cerebry platform only accepts the `.json`**, so
  > it can't be uploaded yet. To get the `.json`, save this text as
  > `<topic_name>.md`. Then open a chat with code execution turned on, attach
  > the file, and ask me to check it and make the `.json`.

## Missing or old pydantic

The validator's full question checks need pydantic 2.x. If the validator
reports that question checks were skipped (it exits with code 3 and prints
`STRUCTURE OK, MODELS NOT CHECKED`):

1. Try once to install it quietly: `pip install "pydantic>=2"`. Then re-run the
   validator.
2. If that fails (often there is no network), keep the parser checks. They still
   catch layout, sections, counts and IDs. Run the hand checklist below on each
   CT, because without pydantic the validator does not check hints, maths
   formatting or blanks at all.
3. At delivery, tell the creator in plain words: "I checked the layout of every
   question by hand. The Cerebry platform will run the full check when you
   upload." Don't mention pydantic.

## Hand checklist (path C, or no pydantic)

Go through it once per CT:

- **Hints:** every question has a hint, and so does every part of a subpart
  question and every MTC match. Each hint is one line, a statement (not a
  question), and ends with the language's full stop.
- **Maths:** every number, formula and unit symbol is inside `\( \)` or `\[ \]`.
  Every delimiter and brace is balanced. Nothing is nested. There is no line
  break inside `\( \)`, and `\text{}` appears only inside maths.
- **Plain text:** no `**bold**`, `*italic*` or headings inside fields, and no
  "A." or "1)" prefixes.
- **MCQ:** it has at least two options, at least one `[x]`, and no repeated
  option.
- **FIB and DROP_DOWN:** every `{placeholderN}` in the Question has a
  `- Placeholder N` item with one `Correct:` line, numbered 1..N. DROP_DOWN
  choices have no LaTeX, no duplicates, and no wrong choice equal to the answer.
- **DECIMAL, MATH_EXPRESSION, PATTERN_MATCH:** tokens appear only in the Answer
  box, once each and in order. A DECIMAL `Value:` is a plain number, and
  Settings has all its lines. A MATH_EXPRESSION `Value:` sits in one delimiter
  pair and has a `Variables:` line. A PATTERN_MATCH regex is valid and has at
  least one `Example:` that matches it fully.
- **Subparts:** the parent has no Solution or Hint, and each part is complete
  for its type.
- **Counts:** `Total variants` and `Total CTs` match what you wrote.

## Long topics and output limits

- Write a CT into the file only when it is complete. The file then always holds
  whole CTs, and `to-json --partial` accepts it.
- Size each batch to your output limit (SKILL.md, Step 3).
- If your reply is cut off in the middle of a CT, don't patch the fragment.
  Remove the unfinished CT or variant, then write it again in smaller batches.
- For topics above about **8 CTs or 40 questions**, share the partial
  `<topic_name>.md` and `<topic_name>.json` with the creator every few CTs,
  after `check-pair --partial`. Say something like: "Here's
  the topic so far, 4 of 10 sets. Keep it in case our chat gets cut off." Files
  in a chat sandbox can disappear when a session ends.

## Resuming after a broken session

1. Ask the creator to attach their latest `<topic_name>.md` and `ContentPlan.md`.
   If they only have the plan, confirm in one line that it still stands, then
   start Step 3 from it.
2. Run `python3 scripts/topic_parser.py to-json <topic_name>.md --partial` to see
   which CTs are complete. A CT that was cut off fails, usually on its
   `Total variants` count or a missing section. Remove it and write it again.
3. Continue with the next CT in the plan. **Never rewrite finished CTs,** and
   keep the Topic ID, CT keys and variant numbers.
   - **Pragmatic mode, with only base questions written:** ask in one line
     whether the creator was happy with them. If yes, add the variants (SKILL.md,
     3c) and follow the plan's Review notes. If not, carry on with the review
     (3b).
4. Tell the creator in plain words where you're picking up: "Sets 1–4 are done.
   I'm continuing with set 5, Factors affecting the rate."
