# OPEN_ENDED_SUBPART — written-answer question in parts

One shared context followed by 2–4 connected written-answer parts (unless the user asks for
another count). Each part is a complete [OPEN_ENDED](OPEN_ENDED.md) question with its own worked solution.

## Sections

```text
#### Question             optional shared context; leave the heading out if there is none
#### Part 1: OPEN_ENDED
##### Question
##### Solution           the full model answer for this part
##### Hint
#### Part 2: OPEN_ENDED   same sections; 2–4 parts in all
```

Parent sections come before `#### Part 1`; parts are numbered 1, 2, 3… and their sections use
`#####`. The parent has no Solution or Hint; parts have no `Difficulty:` (they inherit the CT's
and the topic language). Blank lines after headings are optional; the example omits them in parts.

## Rules the validator enforces

- Every part is OPEN_ENDED. Another type stops the parser: `Part 2: OPEN_ENDED_SUBPART parts
  must be OPEN_ENDED, got MCQ`. For mixed types use [HYBRID_SUBPART](HYBRID_SUBPART.md).
- At least one part: `OPEN_ENDED_SUBPART needs at least one '#### Part <n>: <TYPE>' block`.
- Parent `#### Question` is left out or has text; empty fails: `Main question content cannot be empty`.
- No parent `#### Solution` / `#### Hint`: `Disallowed top-level 'solution' on OPEN_ENDED_SUBPART`.
- No `{placeholderN}` tokens in the parent question: `[SUBPART PLACEHOLDER VISIBILITY]`.
- Display maths `\[ … \]` in the parent question goes on its own line; there it is blocking:
  `display math block '\[' must start on a new line when preceded by text`.
- Every part has a non-empty Question and Solution, and its own one-line `##### Hint` ending
  with the language full stop (`Part 1 (OPEN_ENDED) needs a 'Hint' section`).
- LaTeX in every part must be valid; see [OPEN_ENDED](OPEN_ENDED.md).

## Authoring tips

- Put the formula, data or scenario that every part needs into the shared context.
- Progress from understanding to calculation to interpretation, but keep each part answerable
  without the learner's answer to another part.
- Ask for one clear thing per part ("Explain…", "Find… and show your working"); no "a)"/"(i)" prefixes.
- Solutions are step-by-step model answers without "Step 1:" labels.
- All variants keep the same parts in the same order; change only values and context.
- LaTeX, hints, solutions: [content_guidelines.md](../content_guidelines.md); full stops: [languages.md](../languages.md).

## Example

```markdown
## CT 1: linear_models_ct_001

- Type: OPEN_ENDED_SUBPART
- Difficulty: MEDIUM
- Total variants: 2

### Variant 1

#### Question
A mobile plan charges a fixed monthly fee plus a cost for each gigabyte of data. The monthly bill \(C\), in dollars, for \(g\) gigabytes is

\[ C = 12 + 3g \]

#### Part 1: OPEN_ENDED
##### Question
Explain what the numbers \(12\) and \(3\) mean in this situation.
##### Solution
When \(g = 0\), the bill is \(C = 12\), so \(12\) is the fixed monthly fee in dollars, paid even if no data is used. Each extra gigabyte adds \(3\) to \(C\), so \(3\) is the cost in dollars of one gigabyte.
##### Hint
Compare the bill for no data with the change caused by one more gigabyte.

#### Part 2: OPEN_ENDED
##### Question
One month a customer's bill is \(39\) dollars. Find how many gigabytes they used, showing your working.
##### Solution
Substitute \(C = 39\) into the formula: \(39 = 12 + 3g\). Subtract \(12\) from both sides to get \(3g = 27\), then divide by \(3\): \(g = 9\). The customer used \(9\) gigabytes.
##### Hint
Substitute the bill into the formula and solve for \(g\).

### Variant 2

#### Question
A bike rental shop charges a fixed booking fee plus a cost for each hour of riding. The total charge \(C\), in dollars, for \(h\) hours is

\[ C = 8 + 5h \]

#### Part 1: OPEN_ENDED
##### Question
Explain what the numbers \(8\) and \(5\) mean in this situation.
##### Solution
When \(h = 0\), the charge is \(C = 8\), so \(8\) is the fixed booking fee in dollars, paid however short the ride. Each extra hour adds \(5\) to \(C\), so \(5\) is the cost in dollars of one hour.
##### Hint
Compare the charge for zero hours with the change caused by one more hour.

#### Part 2: OPEN_ENDED
##### Question
A rider is charged \(43\) dollars. Find how many hours they rode, showing your working.
##### Solution
Substitute \(C = 43\) into the formula: \(43 = 8 + 5h\). Subtract \(8\) from both sides to get \(5h = 35\), then divide by \(5\): \(h = 7\). The rider rode for \(7\) hours.
##### Hint
Substitute the charge into the formula and solve for \(h\).
```

## Common errors

| Validator says | Fix |
| --- | --- |
| `OPEN_ENDED_SUBPART parts must be OPEN_ENDED, got …` | Make every part OPEN_ENDED, or change the CT to `HYBRID_SUBPART`. |
| `Disallowed top-level 'solution'` (or `'hint'`) | Delete the parent Solution/Hint; each part has its own. |
| `Part n (OPEN_ENDED) needs a 'Hint' section` | Add `##### Hint` inside that part. |
| `Main question content cannot be empty` | Write the context, or delete the empty `#### Question`. |
| `display math block '\[' must start on a new line` | Put `\[ … \]` on a line of its own in the parent question. |
| `Section '#### …' after a '#### Part' heading` | Move parent sections above Part 1; use `#####` inside parts. |
