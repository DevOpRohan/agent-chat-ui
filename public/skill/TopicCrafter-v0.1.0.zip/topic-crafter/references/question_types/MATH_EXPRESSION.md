# MATH_EXPRESSION — symbolic answer box

Use when the answer is an algebraic or symbolic expression (a factor, an expanded form, a
derivative). The learner types each expression into a box in the Answer box; it is graded
against `Value:` and any `Alternative:`, by written form (`EXACT`) or by equivalence (`EQUIVALENT`).

## Sections

```text
#### Question          required  the stem; no {placeholderN} tokens, no ____ blanks
#### Answer box        required  text and LaTeX around {placeholder1} … {placeholderN}
#### Placeholders      required  one item per token, numbered 1..N
- Placeholder 1
  - Value: \(<LaTeX expression>\)
  - Variables: x, y            (comma list of free symbols, or: none)
  - Alternative: \(<another accepted form>\)    (optional, repeat as needed)
#### Settings          required  exactly these two keys
- Matching: EXACT | EQUIVALENT
- Answers interchangeable: true | false
#### Solution          required
#### Hint              required  one line, ends with the language's full stop
```

## Rules the validator enforces

- **Question** has no `{placeholderN}` tokens and no `____` blanks
  (`question must not contain answer-box placeholder tokens` / `… underscore visual blanks`).
- **Placeholder ids** run 1..N in list order (`placeholder_id must equal its 1-based list position`).
- **Answer box** holds each `{placeholderN}` exactly once, in ascending order
  (`answer_box must contain each placeholder token exactly once in ascending order`).
- **Value** and every **Alternative**: one line of LaTeX wrapped in exactly one delimiter pair
  (`\(...\)`, `\[...\]` or `$$...$$`), nothing outside it, no second pair inside, no `#`, not
  empty (`must be wrapped in exactly one supported LaTeX delimiter pair`, `must use exactly one
  outer LaTeX delimiter pair`, `must not contain '#'`).
- **Alternatives** are unique and never repeat the value (`valid_alternatives must be unique`,
  `valid_alternatives must not repeat value`). Leave the line out when there are none.
- **Variables** is required on every placeholder: distinct symbols, comma-separated, or `none`
  (`missing 'Variables:' line`, `variables must be unique`).
- Placeholder keys are exactly `Value:`, `Variables:`, `Alternative:` (singular). A misspelled
  key line (`Alternatives:`) is silently joined to the previous value, so spell them exactly.
- **Matching** is `EXACT` or `EQUIVALENT` for the whole question (`Input should be 'EXACT' or
  'EQUIVALENT'`). **Answers interchangeable** is `true`/`false`, `false` with one placeholder.
- **Strict type**: no tolerance, `Min decimal places` or `Example:` (`Settings: 'tolerance lower'
  does not apply to MATH_EXPRESSION`, `Extra inputs are not permitted`).
- **Hint** is one line and a statement; LaTeX balances in every text section. Shared rules:
  [content_guidelines.md](../content_guidelines.md), [languages.md](../languages.md).

## Authoring tips

- `EXACT` when the form is assessed ("factorise", "expand and simplify", "write in the form
  \(ax + b\)"); list the other spellings of that same form as alternatives (`\(3+x\)`).
- `EQUIVALENT` only when any equal expression is right ("find the derivative").
- `Variables:` = exactly the free symbols; leave out constants (`\pi`, `e`), functions and units.
- Every alternative must equal the value. Re-derive value and alternatives after any stem change.
- Units and labels go in the Answer box, outside the tokens and outside LaTeX:
  `\(y =\) {placeholder1}`, not `\(y = {placeholder1}\)`.

## Example

```markdown
## CT 1: factorising_quadratics_ct_001

- Type: MATH_EXPRESSION
- Difficulty: MEDIUM
- Total variants: 2

### Variant 1

#### Question

Factorise \(x^2 + 7x + 12\) into two linear factors.

#### Answer box

\(x^2 + 7x + 12 =\) ({placeholder1})({placeholder2})

#### Placeholders

- Placeholder 1
  - Value: \(x+3\)
  - Variables: x
  - Alternative: \(3+x\)
- Placeholder 2
  - Value: \(x+4\)
  - Variables: x
  - Alternative: \(4+x\)

#### Settings

- Matching: EXACT
- Answers interchangeable: true

#### Solution

Look for two numbers whose product is \(12\) and whose sum is \(7\): they are \(3\) and \(4\).
\[
x^2 + 7x + 12 = (x + 3)(x + 4)
\]

#### Hint

Find two numbers that multiply to the constant term and add to the coefficient of \(x\).

### Variant 2

#### Question

Factorise \(x^2 + 2x - 15\) into two linear factors.

#### Answer box

\(x^2 + 2x - 15 =\) ({placeholder1})({placeholder2})

#### Placeholders

- Placeholder 1
  - Value: \(x+5\)
  - Variables: x
  - Alternative: \(5+x\)
- Placeholder 2
  - Value: \(x-3\)
  - Variables: x
  - Alternative: \(-3+x\)

#### Settings

- Matching: EXACT
- Answers interchangeable: true

#### Solution

Look for two numbers whose product is \(-15\) and whose sum is \(2\): they are \(5\) and \(-3\).
\[
x^2 + 2x - 15 = (x + 5)(x - 3)
\]

#### Hint

Find two numbers that multiply to the constant term and add to the coefficient of \(x\).
```

## Common errors

| Validator message (short) | Fix |
| --- | --- |
| `must be wrapped in exactly one supported LaTeX delimiter pair` | `Value: \((x+1)^2\)`, not `(x+1)^2`. |
| `must use exactly one outer LaTeX delimiter pair` | One pair around the whole value: `\(2x + 1\)`, not `\(2x\) + \(1\)`. |
| `valid_alternatives must not repeat value` | Delete the alternative that equals `Value:`. |
| `missing 'Variables:' line` | Add `Variables: x` (or `Variables: none`) to every placeholder. |
| `Settings: 'Matching: EXACT' or 'Matching: EQUIVALENT' is required` | Add the `Matching:` line. |
| `answer_box must contain each placeholder token exactly once in ascending order` | One token per placeholder, `{placeholder1}` first. |
| `answers_interchangeable must be false for one placeholder` | Set `Answers interchangeable: false`. |
