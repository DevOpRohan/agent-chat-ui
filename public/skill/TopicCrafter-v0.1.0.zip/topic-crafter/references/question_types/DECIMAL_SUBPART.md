# DECIMAL_SUBPART — numeric answer boxes in parts

One shared context followed by 2–4 connected parts (unless the user asks for another count),
each a complete [DECIMAL](DECIMAL.md) question with its own answer box, graded numerically.

## Sections

```text
#### Question            required  shared context for every part; no tokens, no ____
#### Part 1: DECIMAL
##### Question           required
##### Answer box         required  {placeholder1} … numbering restarts in every part
##### Placeholders       required  - Placeholder 1 / - Value: / - Min decimal places:
##### Settings           required  Tolerance lower / Tolerance upper / Answers interchangeable
##### Solution           required
##### Hint               required  one line, ends with the language's full stop
#### Part 2: DECIMAL     same sections; 2–4 parts in all
```

Parts have no `Difficulty:` or language lines; they inherit the CT's difficulty and the
topic language.

## Rules the validator enforces

- **Parent**: only `#### Question`, required and non-empty (`DECIMAL_SUBPART needs a
  '#### Question' section`), with no tokens or `____`. A parent Solution, Hint, Answer box or
  Settings fails (`Section 'Hint' is not used by DECIMAL_SUBPART (sections: Question)`).
- **Parts**: at least one, all DECIMAL (`Part 2: DECIMAL_SUBPART parts must be DECIMAL, got
  MCQ`), sections at `#####` level.
- **Each part is a complete [DECIMAL](DECIMAL.md)** with all six sections and every DECIMAL
  rule (`Part 1 (DECIMAL) needs a '##### Settings' section`). Part
  errors from the backend are prefixed `subparts -> 0 -> …`.
- **Placeholder numbering restarts** at `{placeholder1}` / `Placeholder 1` in every part.
- **Non-zero tolerances match across parts**: every part whose tolerance isn't `0`/`0` uses the
  same pair (`All non-zero DECIMAL acceptance_tolerance pairs must be identical`); exact parts
  can sit beside them.
- **Every part has its own one-line hint** ending with the language's full stop
  (`[PUNCTUATION] subparts[0].hint: Make sure the hint ends with '.'.`).

## Authoring tips

- Put the data every part needs in the parent Question; each part asks one thing.
- Order the parts so they build, but don't make a part need another part's typed answer.
- Exact answers get `0`/`0`; rounded parts share one pair, so ask for the same precision.
- Recompute every part's value for each variant, and keep units in each Answer box.

## Example

```markdown
## CT 1: water_tank_ct_001

- Type: DECIMAL_SUBPART
- Difficulty: MEDIUM
- Total variants: 2

### Variant 1

#### Question

A rectangular water tank is \(2.4\) m long, \(1.5\) m wide and \(1.2\) m deep. It starts empty.

#### Part 1: DECIMAL

##### Question

Find the volume of the tank.

##### Answer box

Volume: {placeholder1} \(\text{m}^3\)

##### Placeholders

- Placeholder 1
  - Value: 4.32
  - Min decimal places: 2

##### Settings

- Tolerance lower: 0
- Tolerance upper: 0
- Answers interchangeable: false

##### Solution

Volume \(= 2.4 \times 1.5 \times 1.2 = 4.32\,\text{m}^3\).

##### Hint

Multiply the length, the width and the depth.

#### Part 2: DECIMAL

##### Question

Water flows into the empty tank at \(0.35\,\text{m}^3\) per minute. How long does it take to fill the tank? Give your answer correct to \(1\) decimal place.

##### Answer box

Time: {placeholder1} minutes

##### Placeholders

- Placeholder 1
  - Value: 12.3
  - Min decimal places: 1

##### Settings

- Tolerance lower: 0.05
- Tolerance upper: 0.05
- Answers interchangeable: false

##### Solution

The tank holds \(2.4 \times 1.5 \times 1.2 = 4.32\,\text{m}^3\).
Time \(= \dfrac{4.32}{0.35} = 12.342\ldots \approx 12.3\) minutes.

##### Hint

Divide the volume of the tank by the volume of water that flows in each minute.

### Variant 2

#### Question

A rectangular water tank is \(3\) m long, \(1.6\) m wide and \(1.1\) m deep. It starts empty.

#### Part 1: DECIMAL

##### Question

Find the volume of the tank.

##### Answer box

Volume: {placeholder1} \(\text{m}^3\)

##### Placeholders

- Placeholder 1
  - Value: 5.28
  - Min decimal places: 2

##### Settings

- Tolerance lower: 0
- Tolerance upper: 0
- Answers interchangeable: false

##### Solution

Volume \(= 3 \times 1.6 \times 1.1 = 5.28\,\text{m}^3\).

##### Hint

Multiply the length, the width and the depth.

#### Part 2: DECIMAL

##### Question

Water flows into the empty tank at \(0.45\,\text{m}^3\) per minute. How long does it take to fill the tank? Give your answer correct to \(1\) decimal place.

##### Answer box

Time: {placeholder1} minutes

##### Placeholders

- Placeholder 1
  - Value: 11.7
  - Min decimal places: 1

##### Settings

- Tolerance lower: 0.05
- Tolerance upper: 0.05
- Answers interchangeable: false

##### Solution

The tank holds \(3 \times 1.6 \times 1.1 = 5.28\,\text{m}^3\).
Time \(= \dfrac{5.28}{0.45} = 11.733\ldots \approx 11.7\) minutes.

##### Hint

Divide the volume of the tank by the volume of water that flows in each minute.
```

## Common errors

| Validator message (short) | Fix |
| --- | --- |
| `DECIMAL_SUBPART needs a '#### Question' section` | Add the parent `#### Question` with the shared context. |
| `Section 'Hint' is not used by DECIMAL_SUBPART` | Move the parent hint/solution into the parts (`##### Hint`). |
| `All non-zero DECIMAL acceptance_tolerance pairs must be identical` | One non-zero pair in every rounded part, `0`/`0` elsewhere. |
| `Part 1 (DECIMAL) needs a '##### Settings' section` | Give every part all six sections, each as `##### <Section>`. |
| `answer_box must contain each placeholder token exactly once in ascending order` | Restart at `{placeholder1}` in each part. |
| `Section '#### Question' after a '#### Part' heading` | Part sections use five hashes: `##### Question`. |
