# HYBRID_SUBPART — question in parts of mixed types

One shared context followed by 2–4 connected parts (unless the user asks for another count)
that use at least two different base types, for example a DECIMAL calculation and a
TRUE_FALSE check. Each part is a complete question of its own type.

## Sections

```text
#### Question               optional shared context; leave the heading out if there is none
#### Part 1: <BASE TYPE>    the part's own type, always written after the colon
##### …                     that type's sections, in this order:
    MCQ              Question, Options, Solution, Hint
    OPEN_ENDED       Question, Solution, Hint
    TRUE_FALSE       Question, Answer, Solution, Hint
    FIB, DROP_DOWN   Question, Placeholders, Solution, Hint
    MTC              Question (optional), Matches, Solution (optional), Hint (required here)
    DECIMAL          Question, Answer box, Placeholders, Settings, Solution, Hint
    MATH_EXPRESSION  Question, Answer box, Placeholders, Settings, Solution, Hint
    PATTERN_MATCH    Question, Answer box, Placeholders, Solution, Hint
#### Part 2: <OTHER TYPE>   2–4 parts in all
```

Parent sections come before `#### Part 1`; parts are numbered 1, 2, 3… and their sections use
`#####`. The parent has no Solution or Hint; parts have no `Difficulty:` or `Language:` lines (the
parser copies the topic language into typed parts). Blank lines after headings are optional; the
example omits them in parts.

## Rules the validator enforces

- At least two different part types: `HYBRID_SUBPART should contain at least 2 different
  question types, got: ['OPEN_ENDED']`. With one type, use that type's `_SUBPART` instead.
- Allowed part types: MCQ, OPEN_ENDED, FIB, DROP_DOWN, TRUE_FALSE, MTC, DECIMAL,
  MATH_EXPRESSION, PATTERN_MATCH. Every Part heading names one
  (`Part 2: HYBRID_SUBPART parts need a type, e.g. '#### Part 2: MCQ'`).
- No subpart types inside parts: `Part 2: 'TRUE_FALSE_SUBPART' cannot be nested; parts use base types only`.
- Every part follows its own type's page in full: [MCQ](MCQ.md), [OPEN_ENDED](OPEN_ENDED.md),
  [TRUE_FALSE](TRUE_FALSE.md), [FIB](FIB.md), [DROP_DOWN](DROP_DOWN.md), [MTC](MTC.md),
  [DECIMAL](DECIMAL.md), [MATH_EXPRESSION](MATH_EXPRESSION.md), [PATTERN_MATCH](PATTERN_MATCH.md).
- Every part needs its own one-line `##### Hint`, MTC included (its per-match hints are not
  enough): `[HINT REQUIRED] Missing required field 'subparts[3].hint'`.
- DECIMAL parts: every non-zero tolerance pair is the same across the parts (`0`/`0` parts are
  exempt): `All non-zero DECIMAL acceptance_tolerance pairs must be identical`.
- Typed parts (DECIMAL, MATH_EXPRESSION, PATTERN_MATCH): tokens only in `##### Answer box`,
  never in the part question (`[ANSWER BOX PLACEHOLDER VISIBILITY]`); IDs restart at 1 per part.
- Parent: `#### Question` left out or non-empty (`Main question content cannot be empty`); no
  `{placeholderN}` (`[SUBPART PLACEHOLDER VISIBILITY]`); no Solution/Hint
  (`Disallowed top-level 'solution' on HYBRID_SUBPART`); display `\[ … \]` on its own line (blocking).

## Authoring tips

- Choose each part's type for what it tests: DECIMAL for a number, MATH_EXPRESSION for a
  formula, TRUE_FALSE or MCQ for a judgement, OPEN_ENDED for an explanation.
- Put the data every part needs in the shared context; keep parts independently answerable.
- No "a)"/"(i)" prefixes; each part's solution and hint stand on their own.
- All variants keep the same part types in the same order; change only values and context.
- LaTeX, hints, solutions: [content_guidelines.md](../content_guidelines.md); full stops: [languages.md](../languages.md).

## Example

```markdown
## CT 1: speed_distance_time_ct_001

- Type: HYBRID_SUBPART
- Difficulty: MEDIUM
- Total variants: 2

### Variant 1

#### Question
A cyclist rides along a flat road at a constant speed of \(18\) km/h.

#### Part 1: DECIMAL
##### Question
How far does the cyclist travel in \(2.5\) hours?
##### Answer box
Distance: {placeholder1} km
##### Placeholders
- Placeholder 1
  - Value: 45
  - Min decimal places: 0
##### Settings
- Tolerance lower: 0
- Tolerance upper: 0
- Answers interchangeable: false
##### Solution
Distance \(= \text{speed} \times \text{time} = 18 \times 2.5 = 45\) km.
##### Hint
Multiply the speed by the time taken.

#### Part 2: TRUE_FALSE
##### Question
At this speed, the cyclist needs more than \(3\) hours to ride \(60\) km.
##### Answer
True
##### Solution
Time \(= \dfrac{\text{distance}}{\text{speed}} = \dfrac{60}{18} \approx 3.3\) hours, which is longer than \(3\) hours.
##### Hint
Divide the distance by the speed to find the time.

### Variant 2

#### Question
A train travels along a straight track at a constant speed of \(80\) km/h.

#### Part 1: DECIMAL
##### Question
How far does the train travel in \(1.5\) hours?
##### Answer box
Distance: {placeholder1} km
##### Placeholders
- Placeholder 1
  - Value: 120
  - Min decimal places: 0
##### Settings
- Tolerance lower: 0
- Tolerance upper: 0
- Answers interchangeable: false
##### Solution
Distance \(= \text{speed} \times \text{time} = 80 \times 1.5 = 120\) km.
##### Hint
Multiply the speed by the time taken.

#### Part 2: TRUE_FALSE
##### Question
At this speed, the train needs more than \(3\) hours to travel \(200\) km.
##### Answer
False
##### Solution
Time \(= \dfrac{\text{distance}}{\text{speed}} = \dfrac{200}{80} = 2.5\) hours, which is less than \(3\) hours.
##### Hint
Divide the distance by the speed to find the time.
```

## Common errors

| Validator says | Fix |
| --- | --- |
| `should contain at least 2 different question types` | Change a part's type, or use the single-type `_SUBPART` CT. |
| `HYBRID_SUBPART parts need a type` | Write the type after the colon: `#### Part 2: TRUE_FALSE`. |
| `'…_SUBPART' cannot be nested` | Replace the part with base-type parts. |
| `Missing required field 'subparts[i].hint'` | Add `##### Hint` to part `i + 1` (usually an MTC part). |
| `All non-zero DECIMAL acceptance_tolerance pairs must be identical` | Give every toleranced DECIMAL part the same lower/upper, or `0`/`0`. |
| `[ANSWER BOX PLACEHOLDER VISIBILITY]` | Move `{placeholderN}` from the part question into its `##### Answer box`. |
| `Disallowed top-level 'solution'` (or `'hint'`) | Delete the parent Solution/Hint; each part has its own. |
