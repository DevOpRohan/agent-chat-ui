# PATTERN_MATCH — text answer graded by a regex

Use when the answer is short typed text whose accepted forms you can describe exactly: a
formula, a code, a ratio, standard form. The learner types into each box in the Answer box;
the whole entry must match the placeholder's regular expression (Python `re` full match).

## Sections

```text
#### Question          required  the stem; no {placeholderN} tokens, no ____ blanks
#### Answer box        required  labels around {placeholder1} … {placeholderN}
#### Placeholders      required  one item per token, numbered 1..N
- Placeholder 1
  - Regex: <raw regex, single backslashes, one line>
  - Example: <an answer the regex accepts>      (at least one; repeat for more)
#### Solution          required
#### Hint              required  one line, ends with the language's full stop
(no Settings section)
```

## Rules the validator enforces

- **Question** has no `{placeholderN}` tokens and no `____` blanks
  (`question must not contain answer-box placeholder tokens` / `… underscore visual blanks`).
- **Placeholder ids** run 1..N in list order (`placeholder_id must equal its 1-based list position`).
- **Answer box** holds each `{placeholderN}` exactly once, in ascending order
  (`answer_box must contain each placeholder token exactly once in ascending order`).
- **Regex** is written raw, exactly as Python `re` reads it (`\.` not `\\.`), on one line, at
  most 1000 characters, and must compile (`is not a valid regex: …`). Don't wrap it in
  backticks or LaTeX: a regex that starts with `\(` and ends with `\)` is rejected as
  `must not be LaTeX-delimited`; write `[(]…[)]` or anchor it `^\(…\)$`.
- **Example**: at least one per placeholder (`at least one 'Example:' line is required`), and
  every example must match the whole regex (`Every PATTERN_MATCH valid_examples item must
  fullmatch value`). Examples are accepted answers only; never list wrong ones.
- **Strict type**: no Settings section and no tolerance, `Matching:` or interchangeable keys
  (`Section 'Settings' is not used by PATTERN_MATCH`, `Extra inputs are not permitted`).
- Placeholder keys are exactly `Regex:` and `Example:`; a misspelled key line is joined to the
  previous value, so spell them exactly.
- **Hint** is one line and a statement; LaTeX balances in every text section. Shared rules:
  [content_guidelines.md](../content_guidelines.md), [languages.md](../languages.md).

## Authoring tips

- Decide the accepted language first: which spellings, spaces, cases and symbols are right,
  and which near-misses must fail. Then write the regex and test both lists mentally.
- Anchor with `^…$` for clarity. Avoid catch-alls (`.*`, `.+`); prefer `[0-9]` to `\d` and a
  literal space or ` *` to `\s`. Matching is case-sensitive unless you allow both cases.
- Allow case with character classes (`[Tt]he`, `[Kk]itten`), not inline flags. Keep to syntax
  that every regex engine shares: no `(?i)`, no lookbehind, no named groups. The offline
  check uses Python `re`, but the engine of the learner-side grader is not verified.
- Escape literal punctuation (`\.`, `\^`, `\+`, `\?`) or put it in a class (`[.]`, `[(]`).
- No nested quantifiers like `(a+)*` or overlapping alternatives; they backtrack badly.
- Tell the learner how to type the answer (the symbols to use), and rebuild the regex and
  examples whenever a variant changes the answer.

## Example

```markdown
## CT 1: standard_form_ct_001

- Type: PATTERN_MATCH
- Difficulty: MEDIUM
- Total variants: 2

### Variant 1

#### Question

Write \(0.000045\) in standard form. Type the multiplication sign as x and show the power with ^.

#### Answer box

Standard form: {placeholder1}

#### Placeholders

- Placeholder 1
  - Regex: ^4\.5 *[xX×*] *10 *\^ *(?:-5|[(]-5[)])$
  - Example: 4.5x10^-5
  - Example: 4.5 x 10^-5
  - Example: 4.5*10^(-5)

#### Solution

Move the decimal point \(5\) places to the right to get a number from \(1\) up to \(10\): \(4.5\).
Moving right means the power of ten is negative, so \(0.000045 = 4.5 \times 10^{-5}\).

#### Hint

Count how many places the decimal point moves to give a number from \(1\) up to \(10\).

### Variant 2

#### Question

Write \(0.00032\) in standard form. Type the multiplication sign as x and show the power with ^.

#### Answer box

Standard form: {placeholder1}

#### Placeholders

- Placeholder 1
  - Regex: ^3\.2 *[xX×*] *10 *\^ *(?:-4|[(]-4[)])$
  - Example: 3.2x10^-4
  - Example: 3.2 x 10^-4
  - Example: 3.2*10^(-4)

#### Solution

Move the decimal point \(4\) places to the right to get a number from \(1\) up to \(10\): \(3.2\).
Moving right means the power of ten is negative, so \(0.00032 = 3.2 \times 10^{-4}\).

#### Hint

Count how many places the decimal point moves to give a number from \(1\) up to \(10\).
```

## Common errors

| Validator message (short) | Fix |
| --- | --- |
| `Every PATTERN_MATCH valid_examples item must fullmatch value` | Fix the regex or the example; the whole example must match. Doubled backslashes (`\\.`) cause this. |
| `at least one 'Example:' line is required` | Add `  - Example: <accepted answer>` under the placeholder. |
| `is not a valid regex: …` | Close every `[`, `(` and `{`; escape literal `+ ? * . ( ) [ ]`. |
| `must not be LaTeX-delimited` | Don't wrap the regex in `\( \)`; write `[(]…[)]` or `^\(…\)$`. |
| `Section 'Settings' is not used by PATTERN_MATCH` | Delete the Settings section. |
| `answer_box must contain each placeholder token exactly once in ascending order` | One token per placeholder, `{placeholder1}` first. |
| `question must not contain answer-box placeholder tokens` | Move tokens from the Question to the Answer box. |
