# FIB — Fill in the blanks (drag and drop)

The question text has one or more blanks. The platform shows the keywords (each
blank's correct keyword plus its distractors) and the learner drags them into the
blanks. Each blank is right when it holds its `Correct:` keyword. "DRAG_AND_DROP"
means this type. For a separate dropdown menu per blank, use DROP_DOWN.

## Sections

```text
### Variant <n>

#### Question        required: text with {placeholder1}, {placeholder2}, … where the blanks go
#### Placeholders    required (alias: Blanks): one item per blank
- Placeholder 1
  - Correct: <keyword>
  - Incorrect: <distractor>      (one line each; 3 per blank by default)
#### Solution        required: step-by-step working
#### Hint            required: one line, ends with the language's period
```

## Rules the validator enforces

- Mark each blank with the exact token `{placeholder1}`, `{placeholder2}`, …
  (single braces, lowercase, no spaces). `____`, `{1}` or `{Placeholder1}` give
  `There are 1 placeholders. But we can't find these placeholder syntaxes/phrases`.
- Tokens and `- Placeholder <n>` items match one to one (`Extra blanks found in
  question: {placeholder2}. These blanks have no corresponding placeholder
  definition.`), numbered 1, 2, 3, … in reading order with no gaps
  (`FIB placeholder IDs should be sequential starting from 1, got [2]`).
- Each item has exactly one `Correct:` line (`Placeholder 1: missing 'Correct:'
  line`) and any number of `Incorrect:` lines, indented two spaces.
- Question, Solution and Hint must not be empty; the hint is one line, a
  statement, and ends with the language's period (`[PUNCTUATION] hint`).
- LaTeX is checked in the question, solution, hint and every keyword
  (`LaTeX error in placeholder 1 correct_keyword: ...`).

## Authoring tips

- Write keywords as plain text (`liquid`, `100`); numbers in the question and
  solution still go in `\( \)`.
- Give each blank 3 distractors unless the user asks otherwise: plausible, of the
  same kind as the answer (part of speech, unit, style), distinct, never the answer itself.
- With several blanks, make each blank's answer clear from its own sentence, so
  no keyword fits two blanks.
- Don't start with "Fill in the blanks:" (the platform adds it), and keep tokens
  outside LaTeX: `{placeholder1} \(\text{cm}\)`, not `\({placeholder1}\)`.

## Example

```markdown
## CT 1: changes_of_state_ct_001

- Type: FIB
- Difficulty: EASY
- Total variants: 2

### Variant 1

#### Question

When ice is heated above \(0^\circ\text{C}\), it changes from a solid into a {placeholder1}. This change of state is called {placeholder2}.

#### Placeholders

- Placeholder 1
  - Correct: liquid
  - Incorrect: gas
  - Incorrect: solid
  - Incorrect: plasma
- Placeholder 2
  - Correct: melting
  - Incorrect: freezing
  - Incorrect: boiling
  - Incorrect: condensation

#### Solution

Heating ice above its melting point of \(0^\circ\text{C}\) gives its particles enough energy to leave their fixed positions and slide past one another, so the ice becomes a liquid.
The change from a solid to a liquid is called melting.

#### Hint

Think about what happens to the particles of a solid as it gains heat energy.

### Variant 2

#### Question

When water is heated to \(100^\circ\text{C}\) at sea level, it changes from a liquid into a {placeholder1}. This change of state is called {placeholder2}.

#### Placeholders

- Placeholder 1
  - Correct: gas
  - Incorrect: liquid
  - Incorrect: solid
  - Incorrect: plasma
- Placeholder 2
  - Correct: boiling
  - Incorrect: melting
  - Incorrect: freezing
  - Incorrect: condensation

#### Solution

At sea level, water boils at \(100^\circ\text{C}\): its particles gain enough energy to escape the liquid and move freely, so the water becomes a gas.
The change from a liquid to a gas throughout the liquid at this temperature is called boiling.

#### Hint

Think about what happens to the particles of a liquid as it gains heat energy.
```

## Common errors

| Message (short) | Fix |
| --- | --- |
| `But we can't find these placeholder syntaxes/phrases: - {placeholder1}` | Put the exact token `{placeholder1}` in the Question. |
| `Extra blanks found in question: {placeholder2}` | Add `- Placeholder 2`, or remove the token. |
| `FIB placeholder IDs should be sequential starting from 1` | Renumber the placeholders 1..N, tokens and items together. |
| `Placeholder 1: missing 'Correct:' line` | Add `  - Correct: <keyword>` under the item. |
| `Placeholders: unexpected line ...` | Use `- Placeholder <n>` items with two-space-indented `- Correct:` / `- Incorrect:` lines. |
