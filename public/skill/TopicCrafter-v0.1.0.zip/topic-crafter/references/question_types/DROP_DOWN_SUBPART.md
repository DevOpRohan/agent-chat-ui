# DROP_DOWN_SUBPART — dropdown-blank question in parts

One shared context followed by 2–4 connected parts whose blanks are dropdown menus (unless the
user asks for another count). Each part is a complete [DROP_DOWN](DROP_DOWN.md) question.

## Sections

```text
#### Question             optional shared context, no blanks; leave the heading out if there is none
#### Part 1: DROP_DOWN
##### Question            part text with {placeholder1}, {placeholder2}, …
##### Placeholders        - Placeholder 1 / Correct: / Incorrect: ×3, exactly as for DROP_DOWN
##### Solution
##### Hint
#### Part 2: DROP_DOWN    same sections; 2–4 parts in all
```

Parent sections come before `#### Part 1`; parts are numbered 1, 2, 3… and their sections use
`#####`. The parent has no Solution or Hint; parts have no `Difficulty:` (they inherit the CT's
and the topic language). Blank lines after headings are optional; the example omits them in parts.

## Rules the validator enforces

- Every part is DROP_DOWN. Another type stops the parser: `Part 2: DROP_DOWN_SUBPART parts must
  be DROP_DOWN, got FIB`. For mixed types use [HYBRID_SUBPART](HYBRID_SUBPART.md).
- At least one part: `DROP_DOWN_SUBPART needs at least one '#### Part <n>: <TYPE>' block`.
- Parent `#### Question` is left out or has text; empty fails: `Main question content cannot be empty`.
- Blanks live only in part questions; a token in the parent fails with `[SUBPART PLACEHOLDER VISIBILITY]`.
- Placeholder IDs restart at 1 in every part; each `{placeholderN}` has a `- Placeholder N` item.
- Dropdown choices are plain text: no `\(`, `\[`, `$$` or `\command`
  (`DROP_DOWN placeholder 1 correct_keyword must be plain strings without LaTeX.`). Distractors are
  distinct (`has duplicate distractors`) and never repeat the correct choice.
- No parent `#### Solution` / `#### Hint`: `Disallowed top-level 'solution' on DROP_DOWN_SUBPART`.
- Display maths `\[ … \]` in the parent question goes on its own line; there it is blocking.
- Every part has its own one-line `##### Hint` ending with the language full stop
  (`Part 1 (DROP_DOWN) needs a 'Hint' section`). All other [DROP_DOWN](DROP_DOWN.md) rules apply.

## Authoring tips

- Put the shared scenario in the context and keep the blanks in the parts.
- Give each blank 3 distractors of the same kind as the answer (same part of speech and style).
- Parts build on the context, not on each other's answers; no "a)"/"(i)" prefixes.
- All variants keep the same parts and the same number of blanks; change only values and context.
- LaTeX, hints, solutions: [content_guidelines.md](../content_guidelines.md); full stops: [languages.md](../languages.md).

## Example

```markdown
## CT 1: heat_transfer_ct_001

- Type: DROP_DOWN_SUBPART
- Difficulty: EASY
- Total variants: 2

### Variant 1

#### Question
A metal spoon is left standing in a cup of hot tea. After a minute, the end of the handle feels warm.

#### Part 1: DROP_DOWN
##### Question
Heat travels from the tea to the end of the handle by {placeholder1}.
##### Placeholders
- Placeholder 1
  - Correct: conduction
  - Incorrect: convection
  - Incorrect: radiation
  - Incorrect: evaporation
##### Solution
The particles in the hot part of the spoon vibrate more and pass energy to neighbouring particles along the solid metal. This transfer through a solid is conduction.
##### Hint
Think about how energy moves through a solid without the solid itself moving.

#### Part 2: DROP_DOWN
##### Question
Using a wooden spoon instead would make the handle warm up {placeholder1}, because wood is a good {placeholder2}.
##### Placeholders
- Placeholder 1
  - Correct: more slowly
  - Incorrect: more quickly
  - Incorrect: at the same rate
  - Incorrect: instantly
- Placeholder 2
  - Correct: insulator
  - Incorrect: conductor
  - Incorrect: reflector
  - Incorrect: absorber
##### Solution
Wood conducts heat far less well than metal, so energy passes along a wooden handle much more slowly. A material that conducts heat poorly is called an insulator.
##### Hint
Compare how well wood and metal let heat pass through them.

### Variant 2

#### Question
A steel pan of soup, with a steel handle, is heated from below on a stove. The soup at the top soon becomes hot as well.

#### Part 1: DROP_DOWN
##### Question
Heat spreads through the soup mainly by {placeholder1}.
##### Placeholders
- Placeholder 1
  - Correct: convection
  - Incorrect: conduction
  - Incorrect: radiation
  - Incorrect: insulation
##### Solution
Soup at the bottom warms, expands and becomes less dense, so it rises while cooler soup sinks to take its place. This circulation of a heated liquid is convection.
##### Hint
Think about how warm liquid moves compared with cooler liquid.

#### Part 2: DROP_DOWN
##### Question
Using a plastic handle instead would make the handle warm up {placeholder1}, because plastic is a good {placeholder2}.
##### Placeholders
- Placeholder 1
  - Correct: more slowly
  - Incorrect: more quickly
  - Incorrect: at the same rate
  - Incorrect: instantly
- Placeholder 2
  - Correct: insulator
  - Incorrect: conductor
  - Incorrect: reflector
  - Incorrect: absorber
##### Solution
Plastic conducts heat far less well than steel, so energy passes along a plastic handle much more slowly. A material that conducts heat poorly is called an insulator.
##### Hint
Compare how well plastic and steel let heat pass through them.
```

## Common errors

| Validator says | Fix |
| --- | --- |
| `DROP_DOWN_SUBPART parts must be DROP_DOWN, got …` | Make every part DROP_DOWN, or change the CT to `HYBRID_SUBPART`. |
| `… must be plain strings without LaTeX.` | Write choices as plain text (`24 cm`, not `\(24\)` cm). |
| `has duplicate distractors` / `must not repeat the correct_keyword` | Make every choice in a blank different. |
| `[SUBPART PLACEHOLDER VISIBILITY] root.question …` | Move the blank out of the parent into a part's `##### Question`. |
| `Disallowed top-level 'solution'` (or `'hint'`) | Delete the parent Solution/Hint; each part has its own. |
| `Part n (DROP_DOWN) needs a 'Hint' section` | Add `##### Hint` inside that part. |
