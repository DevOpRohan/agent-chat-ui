# FIB_SUBPART — fill-in-the-blank (drag and drop) question in parts

One shared context followed by 2–4 connected fill-in-the-blank parts (unless the user asks for
another count). Each part is a complete [FIB](FIB.md) with its own blanks and word bank.

## Sections

```text
#### Question          optional shared context, no blanks; leave the heading out if there is none
#### Part 1: FIB
##### Question         part text with {placeholder1}, {placeholder2}, …
##### Placeholders     - Placeholder 1 / Correct: / Incorrect: ×3, exactly as for FIB
##### Solution
##### Hint
#### Part 2: FIB       same sections; 2–4 parts in all
```

Parent sections come before `#### Part 1`; parts are numbered 1, 2, 3… and their sections use
`#####`. The parent has no Solution or Hint; parts have no `Difficulty:` (they inherit the CT's
and the topic language). Blank lines after headings are optional; the example omits them in parts.

## Rules the validator enforces

- Every part is FIB. Another type stops the parser: `Part 2: FIB_SUBPART parts must be FIB,
  got DROP_DOWN`. For mixed types use [HYBRID_SUBPART](HYBRID_SUBPART.md).
- At least one part: `FIB_SUBPART needs at least one '#### Part <n>: <TYPE>' block`.
- Parent `#### Question` is left out or has text; empty fails: `Main question content cannot be empty`.
- Blanks live only in part questions; a token in the parent fails with `[SUBPART PLACEHOLDER VISIBILITY]`.
- Placeholder IDs restart at 1 in every part; each `{placeholderN}` has a `- Placeholder N` item.
- No parent `#### Solution` / `#### Hint`: `Disallowed top-level 'solution' on FIB_SUBPART`.
- Display maths `\[ … \]` in the parent question goes on its own line; there it is blocking.
- Every part has its own one-line `##### Hint` ending with the language full stop
  (`Part 1 (FIB) needs a 'Hint' section`). All other [FIB](FIB.md) rules apply to each part.

## Authoring tips

- Put the shared scenario or values in the context and keep the blanks in the parts.
- Give each blank 3 distractors of the same kind as the answer, built from likely mistakes;
  keyword values are plain text.
- Parts build on the context, not on each other's answers; no "a)"/"(i)" prefixes.
- All variants keep the same parts and the same number of blanks; change only values and context.
- LaTeX, hints, solutions: [content_guidelines.md](../content_guidelines.md); full stops: [languages.md](../languages.md).

## Example

```markdown
## CT 1: rectangle_measures_ct_001

- Type: FIB_SUBPART
- Difficulty: EASY
- Total variants: 2

### Variant 1

#### Question
A rectangle is \(8\) cm long and \(5\) cm wide.

#### Part 1: FIB
##### Question
The perimeter of the rectangle is {placeholder1} cm.
##### Placeholders
- Placeholder 1
  - Correct: 26
  - Incorrect: 13
  - Incorrect: 40
  - Incorrect: 21
##### Solution
The perimeter is the sum of all four sides: \(2 \times (8 + 5) = 2 \times 13 = 26\) cm.
##### Hint
Add the length and the width, then remember there are two of each side.

#### Part 2: FIB
##### Question
If the length is doubled, the perimeter becomes {placeholder1} cm and the area becomes {placeholder2} square centimetres.
##### Placeholders
- Placeholder 1
  - Correct: 42
  - Incorrect: 52
  - Incorrect: 21
  - Incorrect: 26
- Placeholder 2
  - Correct: 80
  - Incorrect: 160
  - Incorrect: 40
  - Incorrect: 42
##### Solution
The new length is \(2 \times 8 = 16\) cm. The perimeter is \(2 \times (16 + 5) = 42\) cm and the area is \(16 \times 5 = 80\) square centimetres.
##### Hint
Find the new length first, then use it in both formulas.

### Variant 2

#### Question
A rectangle is \(7\) cm long and \(3\) cm wide.

#### Part 1: FIB
##### Question
The perimeter of the rectangle is {placeholder1} cm.
##### Placeholders
- Placeholder 1
  - Correct: 20
  - Incorrect: 10
  - Incorrect: 21
  - Incorrect: 17
##### Solution
The perimeter is the sum of all four sides: \(2 \times (7 + 3) = 2 \times 10 = 20\) cm.
##### Hint
Add the length and the width, then remember there are two of each side.

#### Part 2: FIB
##### Question
If the length is doubled, the perimeter becomes {placeholder1} cm and the area becomes {placeholder2} square centimetres.
##### Placeholders
- Placeholder 1
  - Correct: 34
  - Incorrect: 40
  - Incorrect: 17
  - Incorrect: 20
- Placeholder 2
  - Correct: 42
  - Incorrect: 84
  - Incorrect: 21
  - Incorrect: 34
##### Solution
The new length is \(2 \times 7 = 14\) cm. The perimeter is \(2 \times (14 + 3) = 34\) cm and the area is \(14 \times 3 = 42\) square centimetres.
##### Hint
Find the new length first, then use it in both formulas.
```

## Common errors

| Validator says | Fix |
| --- | --- |
| `FIB_SUBPART parts must be FIB, got …` | Make every part FIB, or change the CT to `HYBRID_SUBPART`. |
| `[SUBPART PLACEHOLDER VISIBILITY] root.question …` | Move the blank out of the parent into a part's `##### Question`. |
| `we can't find these placeholder syntaxes/phrases` | Write the exact token `{placeholderN}` in that part's question. |
| `Extra blanks found in question` | Add the missing `- Placeholder N` item, or remove the token. |
| `Disallowed top-level 'solution'` (or `'hint'`) | Delete the parent Solution/Hint; each part has its own. |
| `Part n (FIB) needs a 'Hint' section` | Add `##### Hint` inside that part. |
