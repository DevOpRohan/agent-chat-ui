# MTC — Match the columns

The learner pairs each left-column item with one right-column item. You write
the pairs row by row; the platform shuffles the right column and checks every
pair. It is shown on mobile, so entries are short. "MTC_WITH_CONTEXT" is this
type with a passage in the Question.

## Sections

```text
### Variant <n>

#### Question        optional: the relationship ("Match each … with its …") or a passage
#### Matches         required (alias: Pairs): one item per row, 4–6 rows
- Match 1
  - Left: <2–3 words>
  - Right: <2–3 words>
  - Hint: <one line, ends with the language's period>      (required)
  - Explanation: <why this pair belongs together>           (required: the platform needs it)
#### Solution        optional
#### Hint            optional: one line for the whole question
```

## Rules the validator enforces

- At least one `- Match <n>` item (`MTC question should have at least 1 match`),
  each with a non-empty `Left:` and `Right:` (`Match 1: missing 'Left:' line`).
- **Every match needs its own `Hint:`**, though the parser accepts it missing:
  `[HINT REQUIRED] Missing required field 'matches[0].hint': hint is required`.
  It is one line ending with the language's period (`[PUNCTUATION]
  matches[0].hint: Make sure the hint ends with '.'.`); so is a top-level Hint.
- Left values all differ and Right values all differ, as exact text
  (`MTC left column values should be unique`, `... right column ...`).
- LaTeX is checked in every field, and **in MTC the display-math layout rule is
  an error**: `\[ … \]` inside running text fails with `display math block '\['
  must start on a new line when preceded by text`. Use inline `\( \)` in
  matches; in the Question or Solution put `\[`, the formula and `\]` on their own lines.

## Authoring tips

- Use one relationship for all rows (solid → number of faces, term → definition).
- Make it one-to-one: each Right fits exactly one Left, so no row is solved by elimination alone.
- Keep each entry to 2–3 words, with no `1.`, `A.` or `(i)` prefixes; put the
  reasoning in `Explanation:`. Every match needs one: the platform's preview can't
  create the topic without it (the validator warns with `PLATFORM`).
- A match hint points to the method for that row without naming its Right value.
- State the relationship in the Question, or leave it out; not a bare "Match the following.".

## Example

```markdown
## CT 1: solid_shapes_ct_001

- Type: MTC
- Difficulty: EASY
- Total variants: 2

### Variant 1

#### Question

Match each solid with its number of faces.

#### Matches

- Match 1
  - Left: Cube
  - Right: \(6\)
  - Hint: Count the top, the bottom and the faces around the sides.
  - Explanation: A cube has \(6\) square faces: a top, a bottom and \(4\) sides.
- Match 2
  - Left: Tetrahedron
  - Right: \(4\)
  - Hint: A tetrahedron is a pyramid on a triangular base.
  - Explanation: A tetrahedron has \(1\) triangular base and \(3\) triangular sides, so \(1 + 3 = 4\) faces.
- Match 3
  - Left: Triangular prism
  - Right: \(5\)
  - Hint: Count the two end faces and then the rectangles joining them.
  - Explanation: A triangular prism has \(2\) triangular ends and \(3\) rectangular faces, so \(2 + 3 = 5\) faces.
- Match 4
  - Left: Hexagonal prism
  - Right: \(8\)
  - Hint: A prism has one rectangular face for each side of its end shape.
  - Explanation: A hexagonal prism has \(2\) hexagonal ends and \(6\) rectangular faces, so \(2 + 6 = 8\) faces.

### Variant 2

#### Question

Match each solid with its number of faces.

#### Matches

- Match 1
  - Left: Square-based pyramid
  - Right: \(5\)
  - Hint: Count the square base and the triangles that meet at the top.
  - Explanation: A square-based pyramid has \(1\) square base and \(4\) triangular faces, so \(1 + 4 = 5\) faces.
- Match 2
  - Left: Pentagonal prism
  - Right: \(7\)
  - Hint: Count the two end faces and then the rectangles joining them.
  - Explanation: A pentagonal prism has \(2\) pentagonal ends and \(5\) rectangular faces, so \(2 + 5 = 7\) faces.
- Match 3
  - Left: Octahedron
  - Right: \(8\)
  - Hint: Picture two square-based pyramids joined at their bases.
  - Explanation: Two square-based pyramids joined base to base leave \(4 + 4 = 8\) triangular faces.
- Match 4
  - Left: Pentagonal pyramid
  - Right: \(6\)
  - Hint: A pyramid has one triangular face for each side of its base.
  - Explanation: A pentagonal pyramid has \(1\) pentagonal base and \(5\) triangular faces, so \(1 + 5 = 6\) faces.
```

## Common errors

| Message (short) | Fix |
| --- | --- |
| `[HINT REQUIRED] ... 'matches[0].hint'` / `Missing required hint for match 1` | Add `  - Hint: …` to that match. |
| `[PUNCTUATION] matches[0].hint: Make sure the hint ends with '.'.` | End that match hint with the language's period. |
| `MTC left column values should be unique` | Change the repeated Left (or Right) value. |
| `Match 1: missing 'Left:' line` | Give every match a `Left:` and a `Right:` line, indented two spaces. |
| `display math block '\[' must start on a new line when preceded by text` | Use `\( \)` in matches; put `\[ … \]` on its own lines elsewhere. |
| `Matches: unexpected line ...` | Use `- Match <n>` items with two-space-indented `- Left:` / `- Right:` / `- Hint:` lines. |
