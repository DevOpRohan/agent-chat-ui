# DECIMAL — numeric answer box

Use for any answer that is a plain number, whole numbers included. The learner types each
number into a box in the Answer box; it is graded against `Value:`, exactly or within the tolerance.

## Sections

```text
#### Question          required  the stem; no {placeholderN} tokens, no ____ blanks
#### Answer box        required  labels and units around {placeholder1} … {placeholderN}
#### Placeholders      required  one item per token, numbered 1..N
- Placeholder 1
  - Value: <plain number>
  - Min decimal places: <whole number ≥ 0>
#### Settings          required  exactly these three keys
- Tolerance lower: <number ≥ 0>      (0 = exact)
- Tolerance upper: <number ≥ 0>      (0 = exact)
- Answers interchangeable: true | false
#### Solution          required
#### Hint              required  one line, ends with the language's full stop
```

## Rules the validator enforces

- **Question** has no `{placeholderN}` tokens and no `____` blanks (4+ underscores):
  `question must not contain answer-box placeholder tokens` / `… underscore visual blanks`.
- **Placeholder ids** run 1..N in list order (`placeholder_id must equal its 1-based list position`).
- **Answer box** holds each `{placeholderN}` exactly once, in ascending order
  (`answer_box must contain each placeholder token exactly once in ascending order`).
- **Value** is a plain finite number (`5`, `-3`, `41.8`, `2.5e-3`): no LaTeX, units, `%`,
  commas or spaces (`Value must be a plain number (no LaTeX, units or commas)`).
- **Min decimal places** is a whole number ≥ 0 (`must be a whole number`, `must be non-negative`).
- **Tolerance lower / upper** are both required and ≥ 0 (`acceptance_tolerance.lower must be
  non-negative`). `0`/`0` is exact; otherwise `[Value − lower, Value + upper]` is accepted.
  One pair applies to every placeholder of the question.
- **Answers interchangeable** is `true`/`false`, and `false` with one placeholder
  (`answers_interchangeable must be false for one placeholder`).
- **Strict type**: no other sections or keys (no `Matching:`, `Unit:`, `Variables:`):
  `Section '…' is not used by DECIMAL`, `Settings: unexpected line …`, `Extra inputs are not permitted`.
- **Hint** is one line and a statement (`Hint must be single line`, `Hint should not end with
  question mark`). LaTeX must balance in every text section (`LaTeX error in answer_box: …`).
  Shared rules: [content_guidelines.md](../content_guidelines.md), [languages.md](../languages.md).

## Authoring tips

- Recompute every `Value:` from the finished stem, and again for each variant.
- Tolerance `0`/`0` whenever the maths gives an exact answer. Non-zero only for a rounding or
  measurement rule stated in the stem (1 d.p. → `0.05`); check both ends admit no wrong answer.
- `Min decimal places` = the precision the stem asks for (`0` for whole numbers).
- Units and labels go in the Answer box (`{placeholder1} \(\text{m}^2\)`), never in `Value:`;
  convert the value to the unit shown, and keep tokens outside `\( \)`.
- `Answers interchangeable: true` only for an unordered set (the two roots of a quadratic).

## Example

```markdown
## CT 1: cylinder_measures_ct_001

- Type: DECIMAL
- Difficulty: MEDIUM
- Total variants: 2

### Variant 1

#### Question

A cylindrical water tank has a radius of \(1.2\) m and a height of \(2.5\) m. Using \(\pi \approx 3.14\), find the area of its circular base and its volume. Give each answer correct to \(1\) decimal place.

#### Answer box

Base area: {placeholder1} \(\text{m}^2\)
Volume: {placeholder2} \(\text{m}^3\)

#### Placeholders

- Placeholder 1
  - Value: 4.5
  - Min decimal places: 1
- Placeholder 2
  - Value: 11.3
  - Min decimal places: 1

#### Settings

- Tolerance lower: 0.05
- Tolerance upper: 0.05
- Answers interchangeable: false

#### Solution

Base area \(= \pi r^2 \approx 3.14 \times 1.2^2 = 3.14 \times 1.44 = 4.5216 \approx 4.5\,\text{m}^2\).
Volume \(= \text{base area} \times h \approx 4.5216 \times 2.5 = 11.304 \approx 11.3\,\text{m}^3\).

#### Hint

Find the area of the circular base first, then multiply it by the height.

### Variant 2

#### Question

A cylindrical water tank has a radius of \(1.5\) m and a height of \(2\) m. Using \(\pi \approx 3.14\), find the area of its circular base and its volume. Give each answer correct to \(1\) decimal place.

#### Answer box

Base area: {placeholder1} \(\text{m}^2\)
Volume: {placeholder2} \(\text{m}^3\)

#### Placeholders

- Placeholder 1
  - Value: 7.1
  - Min decimal places: 1
- Placeholder 2
  - Value: 14.1
  - Min decimal places: 1

#### Settings

- Tolerance lower: 0.05
- Tolerance upper: 0.05
- Answers interchangeable: false

#### Solution

Base area \(= \pi r^2 \approx 3.14 \times 1.5^2 = 3.14 \times 2.25 = 7.065 \approx 7.1\,\text{m}^2\).
Volume \(= \text{base area} \times h \approx 7.065 \times 2 = 14.13 \approx 14.1\,\text{m}^3\).

#### Hint

Find the area of the circular base first, then multiply it by the height.
```

## Common errors

| Validator message (short) | Fix |
| --- | --- |
| `question must not contain answer-box placeholder tokens` | Move `{placeholderN}` from the Question to the Answer box. |
| `answer_box must contain each placeholder token exactly once in ascending order` | One token per placeholder, `{placeholder1}` first, same count as Placeholders. |
| `placeholder_id must equal its 1-based list position` | Number the items 1, 2, 3… in order, with no gaps. |
| `Value must be a plain number (no LaTeX, units or commas)` | `Value: 1250`, not `\(1{,}250\)`, `1,250` or `1250 m`. |
| `Settings: 'Tolerance lower: <number>' is required` | Give both tolerance lines, `0` for exact; never negative. |
| `answers_interchangeable must be false for one placeholder` | Set `Answers interchangeable: false`. |
| `Settings: unexpected line …` / `Section '…' is not used by DECIMAL` | Remove the extra key or section. |
