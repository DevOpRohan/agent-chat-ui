# MCQ_SUBPART — multiple-choice question in parts

One shared context followed by 2–4 connected multiple-choice parts (unless the user asks for
another count). Each part is a complete [MCQ](MCQ.md) that can be answered on its own.

## Sections

```text
#### Question          optional shared context; leave the heading out if there is none
#### Part 1: MCQ
##### Question
##### Options          - [x] / - [ ] items, exactly as for MCQ
##### Solution
##### Hint
#### Part 2: MCQ       same sections; 2–4 parts in all
```

Parent sections come before `#### Part 1`; parts are numbered 1, 2, 3… and their sections use
`#####`. The parent has no Solution or Hint; parts have no `Difficulty:` (they inherit the CT's
and the topic language). Blank lines after headings are optional; the example omits them in parts.

## Rules the validator enforces

- Every part is MCQ. Another type stops the parser: `Part 2: MCQ_SUBPART parts must be MCQ,
  got OPEN_ENDED`. For mixed types use [HYBRID_SUBPART](HYBRID_SUBPART.md).
- At least one part: `MCQ_SUBPART needs at least one '#### Part <n>: <TYPE>' block`.
- Parent `#### Question` is left out or has text; empty fails: `Main question content cannot be empty`.
- No parent `#### Solution` / `#### Hint`: `Disallowed top-level 'solution' on MCQ_SUBPART`.
- No `{placeholderN}` tokens in the parent question: `[SUBPART PLACEHOLDER VISIBILITY]`.
- Display maths `\[ … \]` in the parent question goes on its own line; there it is blocking:
  `display math block '\[' must start on a new line when preceded by text`.
- Every part has its own one-line `##### Hint` ending with the language full stop
  (`Part 1 (MCQ) needs a 'Hint' section`, `[PUNCTUATION] subparts[0].hint`).
- Each part obeys every [MCQ](MCQ.md) rule: 2+ options, at least one `[x]`, valid LaTeX.

## Authoring tips

- Put the data, scenario or image that every part needs into the shared context.
- Order parts so they build, but never make one depend on answering another correctly.
- Four options per part, distractors from real mistakes; no "A."/"a)"/"(i)" prefixes anywhere.
- Each part's solution explains its own answer without naming an option letter or position.
- All variants keep the same parts in the same order; change only values and context.
- LaTeX, hints, solutions: [content_guidelines.md](../content_guidelines.md); full stops: [languages.md](../languages.md).

## Example

```markdown
## CT 1: data_averages_ct_001

- Type: MCQ_SUBPART
- Difficulty: EASY
- Total variants: 2

### Variant 1

#### Question
The test scores of \(7\) students are \(4, 8, 6, 9, 8, 5, 10\).

#### Part 1: MCQ
##### Question
What is the median score?
##### Options
- [x] \(8\)
- [ ] \(9\)
- [ ] \(7\)
- [ ] \(6\)
##### Solution
In order, the scores are \(4, 5, 6, 8, 8, 9, 10\). The middle (fourth) value is \(8\), so the median is \(8\).
##### Hint
Write the scores in order before you look for the middle value.

#### Part 2: MCQ
##### Question
What is the range of the scores?
##### Options
- [ ] \(10\)
- [x] \(6\)
- [ ] \(14\)
- [ ] \(7\)
##### Solution
The range is the largest score minus the smallest score: \(10 - 4 = 6\).
##### Hint
Subtract the smallest score from the largest score.

### Variant 2

#### Question
The midday temperatures, in degrees Celsius, on \(7\) days were \(12, 15, 11, 18, 14, 20, 16\).

#### Part 1: MCQ
##### Question
What is the median temperature?
##### Options
- [ ] \(18\)
- [ ] \(14\)
- [x] \(15\)
- [ ] \(16\)
##### Solution
In order, the temperatures are \(11, 12, 14, 15, 16, 18, 20\). The middle (fourth) value is \(15\), so the median is \(15\) degrees Celsius.
##### Hint
Write the temperatures in order before you look for the middle value.

#### Part 2: MCQ
##### Question
What is the range of the temperatures?
##### Options
- [ ] \(20\)
- [ ] \(31\)
- [x] \(9\)
- [ ] \(7\)
##### Solution
The range is the highest temperature minus the lowest: \(20 - 11 = 9\) degrees Celsius.
##### Hint
Subtract the lowest temperature from the highest temperature.
```

## Common errors

| Validator says | Fix |
| --- | --- |
| `MCQ_SUBPART parts must be MCQ, got …` | Make every part MCQ, or change the CT to `HYBRID_SUBPART`. |
| `Disallowed top-level 'solution'` (or `'hint'`) | Delete the parent Solution/Hint; each part has its own. |
| `Part n (MCQ) needs a 'Hint' section` | Add `##### Hint` inside that part. |
| `Main question content cannot be empty` | Write the context, or delete the empty `#### Question`. |
| `Section '#### …' after a '#### Part' heading` | Move parent sections above Part 1; use `#####` inside parts. |
| `Options: no option is marked correct` | Mark the right option `- [x]`; see [MCQ](MCQ.md). |
