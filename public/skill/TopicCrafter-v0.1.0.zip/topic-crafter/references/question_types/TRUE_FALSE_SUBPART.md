# TRUE_FALSE_SUBPART — true-or-false statements in parts

One shared context followed by 2–4 connected statements to judge true or false (unless the user
asks for another count). Each part is a complete [TRUE_FALSE](TRUE_FALSE.md) question.

## Sections

```text
#### Question             optional shared context; leave the heading out if there is none
#### Part 1: TRUE_FALSE
##### Question            a declarative statement
##### Answer              True or False
##### Solution
##### Hint
#### Part 2: TRUE_FALSE   same sections; 2–4 parts in all
```

Parent sections come before `#### Part 1`; parts are numbered 1, 2, 3… and their sections use
`#####`. The parent has no Solution or Hint; parts have no `Difficulty:` (they inherit the CT's
and the topic language). Blank lines after headings are optional; the example omits them in parts.

## Rules the validator enforces

- Every part is TRUE_FALSE. Another type stops the parser: `Part 2: TRUE_FALSE_SUBPART parts
  must be TRUE_FALSE, got MCQ`. For mixed types use [HYBRID_SUBPART](HYBRID_SUBPART.md).
- At least one part: `TRUE_FALSE_SUBPART needs at least one '#### Part <n>: <TYPE>' block`.
- Parent `#### Question` is left out or has text; empty fails: `Main question content cannot be empty`.
- Every part has `##### Answer` with exactly `True` or `False` (`Answer: write 'True' or 'False'`;
  missing: `Part 1 (TRUE_FALSE) needs a 'Answer' section`).
- No parent `#### Solution` / `#### Hint`: `Disallowed top-level 'solution' on TRUE_FALSE_SUBPART`.
- No `{placeholderN}` tokens in the parent question: `[SUBPART PLACEHOLDER VISIBILITY]`.
- Display maths `\[ … \]` in the parent question goes on its own line; there it is blocking:
  `display math block '\[' must start on a new line when preceded by text`.
- Every part has its own one-line `##### Hint` ending with the language full stop
  (`Part 1 (TRUE_FALSE) needs a 'Hint' section`). All other [TRUE_FALSE](TRUE_FALSE.md) rules apply.

## Authoring tips

- The context names the object of study once; each part is one clear, checkable statement about it.
- Mix true and false answers across parts and variants; avoid "always/never" giveaways.
- Solutions explain the reasoning and never say "the statement is true/false"; the platform adds the verdict.
- No "a)"/"(i)" prefixes on parts.
- All variants keep the same parts in the same order; change only values and context.
- LaTeX, hints, solutions: [content_guidelines.md](../content_guidelines.md); full stops: [languages.md](../languages.md).

## Example

```markdown
## CT 1: number_properties_ct_001

- Type: TRUE_FALSE_SUBPART
- Difficulty: EASY
- Total variants: 2

### Variant 1

#### Question
Decide whether each statement about the number \(36\) is true or false.

#### Part 1: TRUE_FALSE
##### Question
\(36\) is a perfect square.
##### Answer
True
##### Solution
\(36 = 6 \times 6 = 6^2\), so \(36\) is the square of the whole number \(6\).
##### Hint
Look for a whole number that multiplies by itself to give the number.

#### Part 2: TRUE_FALSE
##### Question
\(36\) has exactly \(8\) factors.
##### Answer
False
##### Solution
The factors of \(36\) are \(1, 2, 3, 4, 6, 9, 12, 18\) and \(36\). That is \(9\) factors, because the factor \(6\) pairs with itself.
##### Hint
List the factor pairs and check whether any factor pairs with itself.

### Variant 2

#### Question
Decide whether each statement about the number \(100\) is true or false.

#### Part 1: TRUE_FALSE
##### Question
\(100\) is a perfect square.
##### Answer
True
##### Solution
\(100 = 10 \times 10 = 10^2\), so \(100\) is the square of the whole number \(10\).
##### Hint
Look for a whole number that multiplies by itself to give the number.

#### Part 2: TRUE_FALSE
##### Question
\(100\) has exactly \(9\) factors.
##### Answer
True
##### Solution
The factors of \(100\) are \(1, 2, 4, 5, 10, 20, 25, 50\) and \(100\). That makes \(9\) factors, because the factor \(10\) pairs with itself.
##### Hint
List the factor pairs and check whether any factor pairs with itself.
```

## Common errors

| Validator says | Fix |
| --- | --- |
| `TRUE_FALSE_SUBPART parts must be TRUE_FALSE, got …` | Make every part TRUE_FALSE, or change the CT to `HYBRID_SUBPART`. |
| `Part n (TRUE_FALSE) needs a 'Answer' section` | Add `##### Answer` with `True` or `False` inside that part. |
| `Disallowed top-level 'solution'` (or `'hint'`) | Delete the parent Solution/Hint; each part has its own. |
| `Part n (TRUE_FALSE) needs a 'Hint' section` | Add `##### Hint` inside that part. |
| `Main question content cannot be empty` | Write the context, or delete the empty `#### Question`. |
| `Section '#### …' after a '#### Part' heading` | Move parent sections above Part 1; use `#####` inside parts. |
