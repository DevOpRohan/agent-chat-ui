# Choosing a question type

Each CT has one type, set by its `- Type:` line. Pick it from what the learner
does and how the answer is checked, then follow that type's page: its sections,
the rules the validator enforces, and a verified example. Always write the exact
name from the first column.

| Type | Use it when | Answer is checked by | Page |
| --- | --- | --- | --- |
| `MCQ` | The learner picks the answer from given options (4 by default); one or several correct | the option(s) marked `[x]` | [MCQ.md](MCQ.md) |
| `OPEN_ENDED` | The answer is an explanation, proof or extended working | no answer key; the Solution is the model answer | [OPEN_ENDED.md](OPEN_ENDED.md) |
| `TRUE_FALSE` | One statement that is clearly right or wrong | the `True` / `False` Answer | [TRUE_FALSE.md](TRUE_FALSE.md) |
| `FIB` | Blanks in a sentence, filled by dragging keywords (drag and drop) | each blank's `Correct:` keyword | [FIB.md](FIB.md) |
| `DROP_DOWN` | Blanks in a sentence, each with its own menu of plain-text choices | each blank's `Correct:` keyword | [DROP_DOWN.md](DROP_DOWN.md) |
| `MTC` | Pairing 4–6 short items by one relationship | each Left paired with its own Right | [MTC.md](MTC.md) |
| `DECIMAL` | The learner types a number (whole or decimal) | the number vs `Value:`, exactly or within the tolerance | [DECIMAL.md](DECIMAL.md) |
| `MATH_EXPRESSION` | The learner types an expression, an exact fraction, a surd or a term in \(\pi\) | `Value:` / `Alternative:`, by written form (`EXACT`) or equivalence (`EQUIVALENT`) | [MATH_EXPRESSION.md](MATH_EXPRESSION.md) |
| `PATTERN_MATCH` | The learner types short text in a precise format (a word, code, time, ratio) | a full match of the `Regex:` | [PATTERN_MATCH.md](PATTERN_MATCH.md) |
| `OPEN_ENDED_SUBPART` | One context with 2–4 free-response parts | each part as OPEN_ENDED | [OPEN_ENDED_SUBPART.md](OPEN_ENDED_SUBPART.md) |
| `MCQ_SUBPART` | One context with 2–4 multiple-choice parts | each part as MCQ | [MCQ_SUBPART.md](MCQ_SUBPART.md) |
| `FIB_SUBPART` | One context with 2–4 drag-and-drop parts | each part as FIB | [FIB_SUBPART.md](FIB_SUBPART.md) |
| `DROP_DOWN_SUBPART` | One context with 2–4 dropdown parts | each part as DROP_DOWN | [DROP_DOWN_SUBPART.md](DROP_DOWN_SUBPART.md) |
| `TRUE_FALSE_SUBPART` | One context with 2–4 true/false statements | each part as TRUE_FALSE | [TRUE_FALSE_SUBPART.md](TRUE_FALSE_SUBPART.md) |
| `DECIMAL_SUBPART` | One context (required) with 2–4 numeric parts | each part as DECIMAL | [DECIMAL_SUBPART.md](DECIMAL_SUBPART.md) |
| `MATH_EXPRESSION_SUBPART` | One context (required) with 2–4 expression parts | each part as MATH_EXPRESSION | [MATH_EXPRESSION_SUBPART.md](MATH_EXPRESSION_SUBPART.md) |
| `PATTERN_MATCH_SUBPART` | One context (required) with 2–4 formatted-text parts | each part as PATTERN_MATCH | [PATTERN_MATCH_SUBPART.md](PATTERN_MATCH_SUBPART.md) |
| `HYBRID_SUBPART` | One context with parts of at least two different base types | each part by its own type | [HYBRID_SUBPART.md](HYBRID_SUBPART.md) |

## Choosing between similar types

**MCQ or TRUE_FALSE.** Use TRUE_FALSE when the point is whether one claim holds
(a property, a common misconception). Use MCQ when the learner must find the
answer among candidates, or when each wrong choice should catch a specific
mistake. "Which of these statements is true?" is an MCQ, not a TRUE_FALSE.

**FIB (drag and drop) or DROP_DOWN.** Both put `{placeholderN}` tokens in the
Question and use the same Placeholders section. FIB: the learner drags keywords
into the blanks, which suits vocabulary and cloze passages. DROP_DOWN: each blank
is its own menu, which suits blank-specific choices (a number, a unit,
"increases / decreases"). DROP_DOWN choices must be plain text with no LaTeX; if
the choices need math notation, use MCQ. If the learner should type the answer
rather than choose it, use a typed type below.

**DECIMAL, MATH_EXPRESSION, PATTERN_MATCH or OPEN_ENDED.**
- The answer is a number, including whole numbers, money and measurements: **DECIMAL**.
- The answer is symbolic: an expression, an equation, an exact fraction such as
  \(\dfrac{1}{3}\), a surd or a multiple of \(\pi\): **MATH_EXPRESSION**. Use
  `EXACT` when a specific form is assessed (factorised, simplified), `EQUIVALENT` otherwise.
- The answer is short text whose accepted forms you can list exactly (a spelling,
  a time like `3:45`, a ratio, a coordinate pair): **PATTERN_MATCH**.
- The answer is reasoning, several sentences or a proof that can't be checked
  automatically: **OPEN_ENDED**.

These three typed types put `{placeholderN}` tokens only in the Answer box, never in the Question.

## When to use subparts

- Use a `*_SUBPART` type when 2–4 questions share one context (a scenario, a data
  set, an image) and build on each other. Each part must still be answerable on
  its own, and each is checked separately.
- All parts of one type: use that type's `_SUBPART`. Mixed types: use
  `HYBRID_SUBPART`, with at least two different base types among its parts.
- The shared Question is optional, except for DECIMAL_SUBPART,
  MATH_EXPRESSION_SUBPART and PATTERN_MATCH_SUBPART, which require it.
- The parent has no Solution or Hint; every part has its own.
- Unrelated questions don't belong in one subpart question; make separate CTs.

## Names that are not types

| Name you may hear | Write this |
| --- | --- |
| MSQ (multiple select) | `MCQ` with several `[x]` options and "Select all that apply." in the Question |
| DRAG_AND_DROP | `FIB` |
| MTC_WITH_CONTEXT | `MTC` with the passage in `#### Question` |
