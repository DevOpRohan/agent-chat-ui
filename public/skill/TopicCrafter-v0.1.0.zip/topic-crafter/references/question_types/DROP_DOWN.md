# DROP_DOWN — Dropdown blanks

Like FIB, the question text has blanks, but each blank is its own dropdown menu
holding that blank's correct keyword and its distractors. Each blank is right
when the learner picks its `Correct:` keyword. Choices are plain text.

## Sections

```text
### Variant <n>

#### Question        required: text with {placeholder1}, {placeholder2}, … where the dropdowns go
#### Placeholders    required (alias: Blanks): one item per dropdown
- Placeholder 1
  - Correct: <plain-text keyword>
  - Incorrect: <plain-text distractor>      (one line each; 3 per dropdown by default)
#### Solution        required: step-by-step working
#### Hint            required: one line, ends with the language's period
```

## Rules the validator enforces

All [FIB](FIB.md) rules apply: exact `{placeholderN}` tokens in the Question, one
`- Placeholder <n>` item per token numbered 1..N, one `Correct:` line each. Plus:

- Keywords are **plain text only**: no `\(`, `\)`, `\[`, `\]`, `$$`, `\command`
  or images (`DROP_DOWN placeholder 1 correct_keyword must be plain strings
  without LaTeX.`). Write `0.75`, `75%`, `CO2`, `x squared`.
- No keyword is blank (`DROP_DOWN placeholder 1 incorrect_keyword 2 cannot be empty.`).
- A dropdown's distractors are distinct after trimming spaces (`DROP_DOWN
  placeholder 1 has duplicate distractors.`) and never repeat the correct keyword
  (`DROP_DOWN placeholder 1 incorrect_keywords must not repeat the correct_keyword.`).
- Question, Solution and Hint must not be empty; the hint is one line, a
  statement, and ends with the language's period. LaTeX is checked in all three.

## Authoring tips

- Use DROP_DOWN when each blank has its own small set of choices (a number, a
  unit, "increases/decreases"); use FIB when the learner should drag words into place.
- Give each dropdown 3 distractors unless the user asks otherwise, each from a
  realistic mistake and in the answer's format (same unit, notation, precision).
- Only the choices are plain: the question, solution and hint still put every
  number in `\( \)`.
- Make each dropdown's answer decidable from its own sentence, keep tokens
  outside LaTeX, and don't start with "Choose the correct option:".

## Example

```markdown
## CT 1: fraction_conversions_ct_001

- Type: DROP_DOWN
- Difficulty: EASY
- Total variants: 2

### Variant 1

#### Question

Written as a decimal, the fraction \(\dfrac{3}{4}\) is {placeholder1}. Written as a percentage, it is {placeholder2}.

#### Placeholders

- Placeholder 1
  - Correct: 0.75
  - Incorrect: 0.34
  - Incorrect: 1.33
  - Incorrect: 7.5
- Placeholder 2
  - Correct: 75%
  - Incorrect: 7.5%
  - Incorrect: 0.75%
  - Incorrect: 34%

#### Solution

Divide the numerator by the denominator: \(3 \div 4 = 0.75\).
To write a decimal as a percentage, multiply it by \(100\): \(0.75 \times 100 = 75\), so \(\dfrac{3}{4} = 75\%\).

#### Hint

Divide the numerator by the denominator, then scale the result to a total of one hundred.

### Variant 2

#### Question

Written as a decimal, the fraction \(\dfrac{2}{5}\) is {placeholder1}. Written as a percentage, it is {placeholder2}.

#### Placeholders

- Placeholder 1
  - Correct: 0.4
  - Incorrect: 0.25
  - Incorrect: 2.5
  - Incorrect: 4.0
- Placeholder 2
  - Correct: 40%
  - Incorrect: 4%
  - Incorrect: 0.4%
  - Incorrect: 25%

#### Solution

Divide the numerator by the denominator: \(2 \div 5 = 0.4\).
To write a decimal as a percentage, multiply it by \(100\): \(0.4 \times 100 = 40\), so \(\dfrac{2}{5} = 40\%\).

#### Hint

Divide the numerator by the denominator, then scale the result to a total of one hundred.
```

## Common errors

| Message (short) | Fix |
| --- | --- |
| `correct_keyword must be plain strings without LaTeX` | Remove `\( \)` and `\commands` from the choice: `CO2`, not `\(\text{CO}_2\)`. |
| `has duplicate distractors` | Make every `Incorrect:` value in that item different. |
| `incorrect_keywords must not repeat the correct_keyword` | Replace the distractor that equals the answer. |
| `But we can't find these placeholder syntaxes/phrases: - {placeholder1}` | Put the exact token `{placeholder1}` in the Question. |
| `Extra blanks found in question: {placeholder2}` | Add `- Placeholder 2`, or remove the token. |
| `Placeholder 1: missing 'Correct:' line` | Add `  - Correct: <keyword>` under the item. |
