# PATTERN_MATCH_SUBPART — regex-graded text answers in parts

One shared context followed by 2–4 connected parts (unless the user asks for another count),
each a complete [PATTERN_MATCH](PATTERN_MATCH.md) question whose typed text must fully match
its regex.

## Sections

```text
#### Question               required  shared context for every part; no tokens, no ____
#### Part 1: PATTERN_MATCH
##### Question              required
##### Answer box            required  {placeholder1} … numbering restarts in every part
##### Placeholders          required  - Placeholder 1 / - Regex: / - Example: (one or more)
##### Solution              required
##### Hint                  required  one line, ends with the language's full stop
#### Part 2: PATTERN_MATCH  same sections; 2–4 parts in all (no Settings anywhere)
```

Parts have no `Difficulty:` or language lines; they inherit the CT's difficulty and the
topic language.

## Rules the validator enforces

- **Parent**: only `#### Question`, required and non-empty (`PATTERN_MATCH_SUBPART needs a
  '#### Question' section`), with no tokens or `____` (`question must not contain underscore
  visual blanks`). A parent Solution or Hint fails (`Section 'Hint' is not used by
  PATTERN_MATCH_SUBPART (sections: Question)`).
- **Parts**: at least one, all PATTERN_MATCH (`Part 2: PATTERN_MATCH_SUBPART parts must be
  PATTERN_MATCH, got …`), sections at `#####` level.
- **Each part is a complete [PATTERN_MATCH](PATTERN_MATCH.md)** with all five sections and
  every rule there: raw regex with single backslashes, compilable, at most 1000 characters,
  not wrapped in `\( \)`; at least one `Example:`, each fully matching
  (`subparts -> 0 -> placeholders -> 0: … Every PATTERN_MATCH valid_examples item must
  fullmatch value`).
- **No Settings** in any part (`Section 'Settings' is not used by Part 1 (PATTERN_MATCH)`);
  the backend rejects interchangeable/matching keys (`Extra inputs are not permitted`).
- **Placeholder numbering restarts** at `{placeholder1}` / `Placeholder 1` in every part.
- **Every part has its own one-line hint** ending with the language's full stop
  (`[PUNCTUATION] subparts[0].hint: Make sure the hint ends with '.'.`).

## Authoring tips

- Put the shared rule or data in the parent, including how to type answers (symbols, case).
- For each part, list the accepted forms and the near-misses that must fail, then write the
  regex. Matching is case-sensitive, which suits formulas and codes.
- Order the parts so they build, but don't make a part need another part's typed answer.
- Rebuild every regex and its examples for each variant.

## Example

```markdown
## CT 1: ionic_formulas_ct_001

- Type: PATTERN_MATCH_SUBPART
- Difficulty: MEDIUM
- Total variants: 2

### Variant 1

#### Question

In an ionic compound, the total positive charge of the metal ions equals the total negative charge of the non-metal ions. Write each formula with the metal first, and type subscripts as ordinary digits.

#### Part 1: PATTERN_MATCH

##### Question

Write the formula of magnesium chloride, which contains \(\text{Mg}^{2+}\) and \(\text{Cl}^{-}\) ions.

##### Answer box

Formula: {placeholder1}

##### Placeholders

- Placeholder 1
  - Regex: ^MgCl[2₂]$
  - Example: MgCl2
  - Example: MgCl₂

##### Solution

One \(\text{Mg}^{2+}\) ion has a charge of \(+2\), so it needs two \(\text{Cl}^{-}\) ions. The formula is \(\text{MgCl}_2\).

##### Hint

Work out how many chloride ions balance the charge on one magnesium ion.

#### Part 2: PATTERN_MATCH

##### Question

Write the formula of aluminium oxide, which contains \(\text{Al}^{3+}\) and \(\text{O}^{2-}\) ions.

##### Answer box

Formula: {placeholder1}

##### Placeholders

- Placeholder 1
  - Regex: ^Al[2₂]O[3₃]$
  - Example: Al2O3
  - Example: Al₂O₃

##### Solution

The lowest common multiple of \(3\) and \(2\) is \(6\). Two \(\text{Al}^{3+}\) ions give \(+6\) and three \(\text{O}^{2-}\) ions give \(-6\), so the formula is \(\text{Al}_2\text{O}_3\).

##### Hint

Use the lowest common multiple of the two charges to balance them.

### Variant 2

#### Question

In an ionic compound, the total positive charge of the metal ions equals the total negative charge of the non-metal ions. Write each formula with the metal first, and type subscripts as ordinary digits.

#### Part 1: PATTERN_MATCH

##### Question

Write the formula of calcium bromide, which contains \(\text{Ca}^{2+}\) and \(\text{Br}^{-}\) ions.

##### Answer box

Formula: {placeholder1}

##### Placeholders

- Placeholder 1
  - Regex: ^CaBr[2₂]$
  - Example: CaBr2
  - Example: CaBr₂

##### Solution

One \(\text{Ca}^{2+}\) ion has a charge of \(+2\), so it needs two \(\text{Br}^{-}\) ions. The formula is \(\text{CaBr}_2\).

##### Hint

Work out how many bromide ions balance the charge on one calcium ion.

#### Part 2: PATTERN_MATCH

##### Question

Write the formula of aluminium sulfide, which contains \(\text{Al}^{3+}\) and \(\text{S}^{2-}\) ions.

##### Answer box

Formula: {placeholder1}

##### Placeholders

- Placeholder 1
  - Regex: ^Al[2₂]S[3₃]$
  - Example: Al2S3
  - Example: Al₂S₃

##### Solution

The lowest common multiple of \(3\) and \(2\) is \(6\). Two \(\text{Al}^{3+}\) ions give \(+6\) and three \(\text{S}^{2-}\) ions give \(-6\), so the formula is \(\text{Al}_2\text{S}_3\).

##### Hint

Use the lowest common multiple of the two charges to balance them.
```

## Common errors

| Validator message (short) | Fix |
| --- | --- |
| `PATTERN_MATCH_SUBPART needs a '#### Question' section` | Add the parent `#### Question` with the shared context. |
| `Section 'Settings' is not used by Part 1 (PATTERN_MATCH)` | Delete the part's Settings; PATTERN_MATCH has none. |
| `Every PATTERN_MATCH valid_examples item must fullmatch value` | Fix the regex or the example (check case and single backslashes). |
| `at least one 'Example:' line is required` | Add `  - Example: <accepted answer>` to each placeholder. |
| `answer_box must contain each placeholder token exactly once in ascending order` | Restart at `{placeholder1}` in each part. |
| `Section '#### Question' after a '#### Part' heading` | Part sections use five hashes: `##### Question`. |
