# TRUE_FALSE — True or false

The learner sees one statement and chooses True or False. The platform shows
the two choices in a shuffled order and appends the verdict to your solution.
Use it for a single claim that is clearly right or wrong; for picking one claim
out of several, use MCQ.

## Sections

```text
### Variant <n>

#### Question        required: a declarative statement, not a question
#### Answer          required: True or False (alias: Correct answer)
#### Solution        required: the reasoning that settles the statement
#### Hint            required: one line, ends with the language's period
```

## Rules the validator enforces

- The Answer section holds exactly `True` or `False`; anything else stops the
  parser with `Answer: write 'True' or 'False'`.
- Question and Solution must not be empty (`Question content cannot be empty`,
  `Solution content cannot be empty`).
- The hint is required, one line (`Hint must be single line (no newline characters)`),
  a statement (`Hint should not end with question mark`) and ends with the
  language's period (`[PUNCTUATION] hint: Make sure the hint ends with '.'.`).
- LaTeX is checked in the question, solution and hint: balanced `\(`/`\)` and
  `\[`/`\]`, no nesting, no line break inside `\( \)`, `\text{}` only inside math.

## Authoring tips

- Write the Question as a statement ("The number \(2457\) is divisible by \(9\)."),
  never as "True or false: …?" and never as "The statement is …".
- Make the statement unambiguous: one claim, no "always/never" traps unless the
  concept is exactly that.
- The solution shows why the claim holds or fails. Never write "the statement is
  true", "hence false" or "the first option is correct": the platform adds the verdict.
- Variants may differ in their answer (True in one, False in another) as long as
  the concept and the reasoning stay the same, as in the example below.

## Example

```markdown
## CT 1: divisibility_rules_ct_001

- Type: TRUE_FALSE
- Difficulty: EASY
- Total variants: 2

### Variant 1

#### Question

The number \(2457\) is divisible by \(9\).

#### Answer

True

#### Solution

A whole number is divisible by \(9\) exactly when the sum of its digits is divisible by \(9\).
The digit sum of \(2457\) is \(2 + 4 + 5 + 7 = 18\), and \(18 = 9 \times 2\).
So \(2457\) is divisible by \(9\); indeed \(2457 = 9 \times 273\).

#### Hint

Add the digits of the number and test that sum instead.

### Variant 2

#### Question

The number \(4728\) is divisible by \(9\).

#### Answer

False

#### Solution

A whole number is divisible by \(9\) exactly when the sum of its digits is divisible by \(9\).
The digit sum of \(4728\) is \(4 + 7 + 2 + 8 = 21\), and \(21\) is not a multiple of \(9\).
So \(4728\) is not divisible by \(9\); dividing gives \(4728 = 9 \times 525 + 3\), a remainder of \(3\).

#### Hint

Add the digits of the number and test that sum instead.
```

## Common errors

| Message (short) | Fix |
| --- | --- |
| `TRUE_FALSE needs a 'Answer' section` | Add `#### Answer` with `True` or `False`. |
| `Answer: write 'True' or 'False'` | Put only the word `True` or `False` in the Answer section. |
| `Section 'Options' is not used by TRUE_FALSE` | Remove the options; the platform supplies True/False. |
| `Hint should not end with question mark` | Rewrite the hint as a statement ending with the language's period. |
| `[PUNCTUATION] hint: Make sure the hint ends with '.'.` | Add the period (or `।` / `。`, see `languages.md`). |
