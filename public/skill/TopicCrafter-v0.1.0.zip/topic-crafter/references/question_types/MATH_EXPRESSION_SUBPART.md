# MATH_EXPRESSION_SUBPART — symbolic answer boxes in parts

One shared context followed by 2–4 connected parts (unless the user asks for another count),
each a complete [MATH_EXPRESSION](MATH_EXPRESSION.md) question with its own answer box and
its own `EXACT` / `EQUIVALENT` matching.

## Sections

```text
#### Question                 required  shared context for every part; no tokens, no ____
#### Part 1: MATH_EXPRESSION
##### Question                required
##### Answer box              required  {placeholder1} … numbering restarts in every part
##### Placeholders            required  - Placeholder 1 / - Value: / - Variables: / - Alternative:
##### Settings                required  Matching / Answers interchangeable
##### Solution                required
##### Hint                    required  one line, ends with the language's full stop
#### Part 2: MATH_EXPRESSION  same sections; 2–4 parts in all
```

Parts have no `Difficulty:` or language lines; they inherit the CT's difficulty and the
topic language.

## Rules the validator enforces

- **Parent**: only `#### Question`, required and non-empty (`MATH_EXPRESSION_SUBPART needs a
  '#### Question' section`), with no tokens or `____`. A parent Solution, Hint, Answer box or
  Settings fails (`Section 'Hint' is not used by MATH_EXPRESSION_SUBPART (sections: Question)`).
- **Parts**: at least one, all MATH_EXPRESSION (`Part 2: MATH_EXPRESSION_SUBPART parts must be
  MATH_EXPRESSION, got …`), sections at `#####` level.
- **Each part is a complete [MATH_EXPRESSION](MATH_EXPRESSION.md)** with all six sections and
  every rule there: value and alternatives in one LaTeX delimiter pair with no `#`, a
  `Variables:` line on each placeholder, unique alternatives that differ from the value, its own
  `Matching:` (`Part 1 (MATH_EXPRESSION) needs a '##### Settings' section`). Part errors from the backend are prefixed `subparts -> 0 -> …`.
- **Placeholder numbering restarts** at `{placeholder1}` / `Placeholder 1` in every part, and
  `Answers interchangeable` is `false` in any part with one placeholder.
- **Every part has its own one-line hint** ending with the language's full stop
  (`[PUNCTUATION] subparts[1].hint: Make sure the hint ends with '.'.`).

## Authoring tips

- Put the shared definitions (shape, function, variables and their domain) in the parent.
- Choose `Matching` per part: `EXACT` where a form is asked for ("simplify fully"),
  `EQUIVALENT` where any equal expression is right.
- Order the parts so they build, but don't make a part need another part's typed answer.
- Re-derive every value and alternative for each variant.

## Example

```markdown
## CT 1: rectangle_expressions_ct_001

- Type: MATH_EXPRESSION_SUBPART
- Difficulty: MEDIUM
- Total variants: 2

### Variant 1

#### Question

A rectangle has a length of \((x + 5)\) cm and a width of \((x - 2)\) cm, where \(x > 2\).

#### Part 1: MATH_EXPRESSION

##### Question

Write an expression for the perimeter of the rectangle. Simplify it fully.

##### Answer box

Perimeter: {placeholder1} \(\text{cm}\)

##### Placeholders

- Placeholder 1
  - Value: \(4x+6\)
  - Variables: x
  - Alternative: \(6+4x\)

##### Settings

- Matching: EXACT
- Answers interchangeable: false

##### Solution

Perimeter \(= 2[(x + 5) + (x - 2)] = 2(2x + 3) = 4x + 6\) cm.

##### Hint

Add the lengths of all four sides, then collect the like terms.

#### Part 2: MATH_EXPRESSION

##### Question

Write an expression for the area of the rectangle.

##### Answer box

Area: {placeholder1} \(\text{cm}^2\)

##### Placeholders

- Placeholder 1
  - Value: \((x+5)(x-2)\)
  - Variables: x

##### Settings

- Matching: EQUIVALENT
- Answers interchangeable: false

##### Solution

Area \(= \text{length} \times \text{width} = (x + 5)(x - 2) = x^2 + 3x - 10\) square centimetres.

##### Hint

Multiply the length of the rectangle by its width.

### Variant 2

#### Question

A rectangle has a length of \((x + 7)\) cm and a width of \((x - 3)\) cm, where \(x > 3\).

#### Part 1: MATH_EXPRESSION

##### Question

Write an expression for the perimeter of the rectangle. Simplify it fully.

##### Answer box

Perimeter: {placeholder1} \(\text{cm}\)

##### Placeholders

- Placeholder 1
  - Value: \(4x+8\)
  - Variables: x
  - Alternative: \(8+4x\)

##### Settings

- Matching: EXACT
- Answers interchangeable: false

##### Solution

Perimeter \(= 2[(x + 7) + (x - 3)] = 2(2x + 4) = 4x + 8\) cm.

##### Hint

Add the lengths of all four sides, then collect the like terms.

#### Part 2: MATH_EXPRESSION

##### Question

Write an expression for the area of the rectangle.

##### Answer box

Area: {placeholder1} \(\text{cm}^2\)

##### Placeholders

- Placeholder 1
  - Value: \((x+7)(x-3)\)
  - Variables: x

##### Settings

- Matching: EQUIVALENT
- Answers interchangeable: false

##### Solution

Area \(= \text{length} \times \text{width} = (x + 7)(x - 3) = x^2 + 4x - 21\) square centimetres.

##### Hint

Multiply the length of the rectangle by its width.
```

## Common errors

| Validator message (short) | Fix |
| --- | --- |
| `MATH_EXPRESSION_SUBPART needs a '#### Question' section` | Add the parent `#### Question` with the shared context. |
| `Section 'Solution' is not used by MATH_EXPRESSION_SUBPART` | Move the parent solution/hint into the parts. |
| `must be wrapped in exactly one supported LaTeX delimiter pair` | Write `Value: \(4x+6\)`, not `4x+6`. |
| `missing 'Variables:' line` | Add `Variables: x` (or `none`) to every placeholder of every part. |
| `answer_box must contain each placeholder token exactly once in ascending order` | Restart at `{placeholder1}` in each part. |
| `Section '#### Question' after a '#### Part' heading` | Part sections use five hashes: `##### Question`. |
