# MCQ — Multiple choice

The learner picks from a list of options. The platform shuffles the options,
numbers them itself and marks the question right when the learner picks the
option(s) you marked `[x]`. Mark several `[x]` for a multiple-select question (MSQ).

## Sections

```text
### Variant <n>

#### Question        required: the stem (MSQ: add "Select all that apply.")
#### Options         required: one "- [x] …" or "- [ ] …" line per option, usually 4
#### Solution        required: step-by-step working
#### Hint            required: one line, ends with the language's period
```

## Rules the validator enforces

- Give at least 2 options (`MCQ should have at least 2 options`), none empty
  (`Option 2: content cannot be empty`); write 4 unless the user asks otherwise.
- Mark at least one option `- [x]` (`Options: no option is marked correct with
  '- [x]'`). Every line starts `- [ ] ` or `- [x] `; a long option may continue
  on an indented line.
- The parser copies each `[x]` option's text into the answer key, so the key
  always matches an option exactly. The key stores text, not position, so never
  repeat an option: two equal options can't be told apart.
- Question, Solution and Hint must not be empty. The hint is one line, a
  statement (`Hint should not end with question mark`) and ends with the
  language's period (`[PUNCTUATION] hint: Make sure the hint ends with '.'.`).
- LaTeX is checked in the question, solution, hint and every option
  (`LaTeX error in option 3: ...`): balanced `\(`/`\)` and `\[`/`\]`, no nesting,
  no line break inside `\( \)`, `\text{}` only inside math.

## Authoring tips

- Build each distractor from a realistic mistake (wrong operation, complement,
  misplaced decimal point), with the same form and a similar length as the answer.
- No `A.`, `1)` or `(a)` prefixes in options, and no "All/None of the above" unless asked.
- The solution never refers to options by letter or position ("option B") and
  never ends with "Hence option B is correct"; the platform appends that line.
- MSQ: say so in the stem ("Select all that apply.") and mark every correct option `[x]`.
- Variants keep the same skill and the same mistake pattern behind each distractor;
  only the numbers and context change.

## Example

```markdown
## CT 1: percentages_ct_001

- Type: MCQ
- Difficulty: MEDIUM
- Total variants: 2

### Variant 1

#### Question

A school has \(800\) students. \(35\%\) of them walk to school. How many students walk to school?

#### Options

- [x] \(280\)
- [ ] \(520\)
- [ ] \(28\)
- [ ] \(2800\)

#### Solution

Write the percentage as a decimal: \(35\% = \dfrac{35}{100} = 0.35\).
Multiply by the total number of students: \(0.35 \times 800 = 280\).
So \(280\) students walk to school. The remaining \(800 - 280 = 520\) students do not walk.

#### Hint

Convert the percentage to a decimal before multiplying by the total.

### Variant 2

#### Question

A library has \(1200\) books. \(15\%\) of them are science books. How many science books does the library have?

#### Options

- [x] \(180\)
- [ ] \(1020\)
- [ ] \(18\)
- [ ] \(1800\)

#### Solution

Write the percentage as a decimal: \(15\% = \dfrac{15}{100} = 0.15\).
Multiply by the total number of books: \(0.15 \times 1200 = 180\).
So the library has \(180\) science books. The remaining \(1200 - 180 = 1020\) books are not science books.

#### Hint

Convert the percentage to a decimal before multiplying by the total.
```

## Common errors

| Message (short) | Fix |
| --- | --- |
| `MCQ needs a 'Options' section` | Add `#### Options` (alias `Choices`) with checkbox lines. |
| `Options: no option is marked correct with '- [x]'` | Mark the correct option(s) `- [x]`. |
| `Options: expected '- [x] correct option' or '- [ ] other option'` | Remove prose, blank-label lines or `A.` labels from the section. |
| `MCQ should have at least 2 options` | Add distractors; aim for 4. |
| `Option 2: content cannot be empty` | Fill in or delete the empty `- [ ]` line. |
| `Hint should not end with question mark` / `[PUNCTUATION] hint` | Rewrite the hint as one statement ending with the language's period. |
| `LaTeX error in option 2: unbalanced inline math delimiters` | Close every `\(` with `\)` in that option. |
| `over-escaped LaTeX delimiter '\\('` | Use single backslashes: `\(5\)`, not `\\(5\\)`. |

LaTeX errors are reported only once the field errors (options, hint) are fixed,
so a second run can show new ones.
