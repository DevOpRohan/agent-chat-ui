# OPEN_ENDED — Free-response question

The learner writes their own answer: an explanation, a proof, a derivation or a
worked calculation. There is no answer key; the Solution is the model
answer. If the answer is a single number,
expression or short code that should be checked automatically, use DECIMAL,
MATH_EXPRESSION or PATTERN_MATCH instead (see `README.md`).

## Sections

```text
### Variant <n>

#### Question        required: the task ("Show that…", "Explain why…", "Find… and justify…")
#### Solution        required: the complete model answer, step by step
#### Hint            required: one line, ends with the language's period
```

No other sections: an `#### Answer` or `#### Options` section is rejected with
`Section 'Answer' is not used by OPEN_ENDED (sections: Question, Solution, Hint)`.

## Rules the validator enforces

- Question and Solution must not be empty (`Question content cannot be empty`,
  `Solution content cannot be empty`).
- A Hint section is required (`OPEN_ENDED needs a 'Hint' section`). It is one
  line (`Hint must be single line (no newline characters)`), a statement
  (`Hint should not end with question mark`) and ends with the language's period
  (`[PUNCTUATION] hint: Make sure the hint ends with '.'.`).
- LaTeX is checked in the question, solution and hint: balanced `\(`/`\)` and
  `\[`/`\]`, no nesting, no line break inside `\( \)`, and `\text{}` only inside
  math (`text command '\text' used outside math delimiters`).

## Authoring tips

- Ask for one clear piece of work, and say what a complete answer contains
  ("Show that…", "Give a reason").
- Write the solution like a textbook answer: every step on its own line, at the
  grade's level, with no "Step 1:" labels. Put display math `\[ … \]` on its own lines.
- The hint points to the method ("Write the integers in terms of the smallest one.")
  without doing the first step for the learner.
- Variants keep the same reasoning and length of argument; change the numbers or
  the context, not the method.

## Example

```markdown
## CT 1: number_proofs_ct_001

- Type: OPEN_ENDED
- Difficulty: MEDIUM
- Total variants: 2

### Variant 1

#### Question

Show that the sum of any three consecutive integers is divisible by \(3\).

#### Solution

Let the three consecutive integers be \(n\), \(n + 1\) and \(n + 2\), where \(n\) is an integer.
Add them and collect like terms:
\[
n + (n + 1) + (n + 2) = 3n + 3
\]
Take out the common factor: \(3n + 3 = 3(n + 1)\).
Since \(n + 1\) is an integer, the sum is \(3\) times an integer, so it is divisible by \(3\).

#### Hint

Write all three integers in terms of the smallest one and add them.

### Variant 2

#### Question

Show that the sum of any five consecutive integers is divisible by \(5\).

#### Solution

Let the five consecutive integers be \(n\), \(n + 1\), \(n + 2\), \(n + 3\) and \(n + 4\), where \(n\) is an integer.
Add them and collect like terms:
\[
n + (n + 1) + (n + 2) + (n + 3) + (n + 4) = 5n + 10
\]
Take out the common factor: \(5n + 10 = 5(n + 2)\).
Since \(n + 2\) is an integer, the sum is \(5\) times an integer, so it is divisible by \(5\).

#### Hint

Write all five integers in terms of the smallest one and add them.
```

## Common errors

| Message (short) | Fix |
| --- | --- |
| `OPEN_ENDED needs a 'Hint' section` | Add `#### Hint` with one line. |
| `Unknown section '#### Solutions'` | Spell the heading exactly: `#### Solution`. |
| `Section 'Answer' is not used by OPEN_ENDED` | Fold the answer into `#### Solution`, or pick a typed type. |
| `Hint must be single line (no newline characters)` | Join the hint into one sentence. |
| `[PUNCTUATION] hint: Make sure the hint ends with '.'.` | End the hint with the language's period (`languages.md`). |
| `text command '\text' used outside math delimiters` | Wrap it: `\(\text{km}\)`. |
| `newline inside math environment` | Close `\( … \)` on the same line, or use `\[ … \]` on its own lines. |
