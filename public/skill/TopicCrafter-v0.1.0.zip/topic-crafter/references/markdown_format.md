# topic-md format, version 1

This page is the full contract for topic-md 1. Here "topic.md" means any file in
this format. The file you deliver is named `<topic_name>.md` (see SKILL.md), and
`scripts/topic_parser.py to-json` turns it into `<topic_name>.json`. Never write
the JSON by hand: the Cerebry platform accepts only the parser-made `.json`. The
per-type pages in `question_types/` show each type's sections with an example.

## Shape at a glance

```markdown
# Topic: Linear equations in one variable

- Topic ID: 6f1c2d3e-...        (leave out for a new topic; the parser adds it)
- Language: English
- Total CTs: 2
- Format: topic-md 1

## CT 1: linear_equations_ct_001

- Type: MCQ
- Difficulty: EASY
- Total variants: 2
- Concept: one-step equations with addition   (optional, Markdown-only note)

### Variant 1

#### Question

Solve \(x + 7 = 12\).

#### Options

- [ ] \(4\)
- [x] \(5\)
- [ ] \(7\)
- [ ] \(19\)

#### Solution

Subtract \(7\) from both sides: \(x = 12 - 7 = 5\).

#### Hint

Undo the addition by doing the inverse operation on both sides.

### Variant 2

...

## CT 2: linear_equations_ct_002

...
```

## Headings: the only structure

| Level | Heading | Meaning |
| --- | --- | --- |
| `#` | `# Topic: <topic name>` | Exactly one, first line. The name becomes `topic_name`. |
| `##` | `## CT <n>: <ct_key>` | One per CT. `<n>` counts 1, 2, 3… (display only); `<ct_key>` is the CT's identity. |
| `###` | `### Variant <question_no>` | One per question. The number IS the question's ID (`question_no`). |
| `####` | `#### <Section>` | A field of the question (Question, Options, Solution, …). |
| `####` | `#### Part <n>: <TYPE>` | One child of a subpart question (subpart types only). |
| `#####` | `##### <Section>` | A field of a part. |

- Every heading outside a code fence must be one of these. An unknown or
  misspelled section (`#### Solutions`) is an error, never silently absorbed.
- Section headings are case-insensitive. Accepted aliases: `Stem`/`Context` →
  Question, `Choices` → Options, `Correct answer` → Answer, `Blanks`/`Answers`
  → Placeholders, `Pairs` → Matches, `Grading` → Settings.
- Don't put headings or Markdown emphasis (`**bold**`, `*italic*`) inside question text;
  fields are plain text plus LaTeX (see `content_guidelines.md`).

## Metadata lines

Metadata sits under the `#` and `##` headings as `- Key: value` lines (the
bullet and `**bold**` are optional).

Topic header:

| Line | Required | Notes |
| --- | --- | --- |
| `Topic ID:` | for existing topics | Keep it exactly. For a new topic leave it out: `to-json` creates a UUID and writes the line back into your file. |
| `Language:` | yes | One of the 22 names in `languages.md`. Applies to every question (v1: one language per topic). |
| `Total CTs:` | yes | Must equal the number of `## CT` sections. This catches truncated output. |
| `Format:` | yes | `topic-md 1` |

CT header:

| Line | Required | Notes |
| --- | --- | --- |
| `Type:` | yes | One of the 18 types, e.g. `MCQ`, `DECIMAL`, `HYBRID_SUBPART`. One type per CT. |
| `Difficulty:` | yes | `EASY`, `MEDIUM` or `HARD`. One difficulty per CT. |
| `Total variants:` | yes | Must equal the number of `### Variant` sections in the CT. |
| `Concept:` | no | A note for humans. It stays in the Markdown and is not stored in JSON. |
| `Question IDs: positional` | rare | Only for legacy topics whose JSON has no `question_no`. `to-md` writes it; don't add it yourself. |
| `Extra JSON:` | rare | One-line JSON object of extra CT fields, written by `to-md`. Leave it unchanged. |

The topic header can also carry an `Extra JSON:` line, written by `to-md` for unknown topic fields.

## IDs and numbering

- **CT keys** are unique, contain no spaces, and follow `<descriptive_name>_ct_<number>`,
  for example `photosynthesis_ct_003`. Keep existing keys exactly.
- **Variant numbers** are question IDs. They must be positive and unique within the CT.
  For a new CT, number variants 1, 2, 3, … in order.
- When editing, **never renumber**. A deleted variant leaves a gap, and that's fine.
  Reordering sections keeps each variant's number. A new variant takes the CT's highest
  number + 1. Update `Total variants:` / `Total CTs:` to match.
- The parser copies the CT key into every question's `ct_key` and the variant number
  into `question_no`.

## Sections by type

The question type comes from the CT `Type:` line. Each type has a fixed set of
sections; required ones must be present, and others are rejected.

| Type | Sections, in order |
| --- | --- |
| OPEN_ENDED | Question, Solution, Hint |
| MCQ | Question, Options, Solution, Hint |
| TRUE_FALSE | Question, Answer, Solution, Hint |
| FIB, DROP_DOWN | Question, Placeholders, Solution, Hint |
| MTC | Question (optional), Matches, Solution (optional), Hint (optional) |
| DECIMAL | Question, Answer box, Placeholders, Settings, Solution, Hint |
| MATH_EXPRESSION | Question, Answer box, Placeholders, Settings, Solution, Hint |
| PATTERN_MATCH | Question, Answer box, Placeholders, Solution, Hint |
| *_SUBPART (OPEN_ENDED, MCQ, FIB, DROP_DOWN, TRUE_FALSE) | Question (optional context), then `#### Part <n>: <TYPE>` blocks |
| DECIMAL_SUBPART, MATH_EXPRESSION_SUBPART, PATTERN_MATCH_SUBPART | Question (required context), then Part blocks |
| HYBRID_SUBPART | Question (optional context), then Part blocks of at least two different base types |

## Section bodies

**Text sections** (Question, Solution, Hint, Answer box): everything up to the
next heading, trimmed. Write LaTeX exactly as it should appear, with single
backslashes: `\(x^2\)`, `\[\dfrac{a}{b}\]`. This is plain text, not JSON, so
**never double the backslashes**. Hints are one line.

**Images**: `![description](https://url)` anywhere in a text value makes that
value interleaved text + image. The description says what the picture shows.

- **Images are the only media allowed in Cerebry topics.** Never link video,
  audio, PDFs or other files. The title form `![clip](https://url "video")`,
  which the parser maps to another media type, is **not allowed**.
- **Use only Cerebry image links.** Use a link only after the creator has given
  you the actual link **and** confirmed it was created on the Cerebry platform.
  Never invent, search for or generate links: no stock or web images, and no
  placeholders such as `example.com`. The links in `examples/` only show the
  syntax.
- Without a confirmed link, write the question so it needs no picture. Never
  refer to a figure that isn't there. Full rule: `content_guidelines.md` → Images.

**Options** (MCQ): one checkbox item per option; `[x]` marks each correct one.

```markdown
- [ ] Mitochondria
- [x] Chloroplast
```

No "A." or "1)" prefixes; the platform numbers and shuffles options. Mark several
`[x]` for a multiple-select question, and say so in the question ("Select all that apply").

**Answer** (TRUE_FALSE): `True` or `False`.

**Placeholders**: one `- Placeholder <id>` item per `{placeholder<id>}` token,
with `  - Key: value` lines indented by two spaces. The keys depend on the type:

| Type | Keys |
| --- | --- |
| FIB, DROP_DOWN | `Correct:` (once), `Incorrect:` (repeat, usually 3 times) |
| DECIMAL | `Value:` (plain number), `Min decimal places:` (whole number) |
| MATH_EXPRESSION | `Value:` (LaTeX in one delimiter pair), `Variables:` (comma list or `none`), `Alternative:` (repeat; optional) |
| PATTERN_MATCH | `Regex:` (raw regex, single backslashes), `Example:` (repeat; at least one) |

**Matches** (MTC): one `- Match <n>` item per row with `Left:`, `Right:`,
`Hint:` and `Explanation:` lines. Write both a hint and an explanation for every
match; the platform needs the explanation to create the topic.

**Settings** (DECIMAL, MATH_EXPRESSION):

| Key | Types | Value |
| --- | --- | --- |
| `Tolerance lower:` / `Tolerance upper:` | DECIMAL | plain numbers, `0` for exact |
| `Answers interchangeable:` | DECIMAL, MATH_EXPRESSION | `true` or `false` |
| `Matching:` | MATH_EXPRESSION | `EXACT` or `EQUIVALENT` |

A list value can continue on following lines indented deeper than its bullet;
those lines join with a newline. Prefer one line.

## Parts (subpart types)

```markdown
### Variant 1

#### Question

A tank holds \(120\) litres of water.

#### Part 1: DECIMAL

##### Question

Water drains at \(8\) litres per minute. How many minutes until it is empty?

##### Answer box

{placeholder1} minutes

##### Placeholders

- Placeholder 1
  - Value: 15
  - Min decimal places: 0

##### Settings

- Tolerance lower: 0
- Tolerance upper: 0
- Answers interchangeable: false

##### Solution

\(120 \div 8 = 15\) minutes.

##### Hint

Divide the capacity by the drain rate.

#### Part 2: TRUE_FALSE

##### Question
...
```

- Parent sections (`#### Question`) come before the first `#### Part`.
- Parts are numbered 1, 2, 3… and keep their order. Their type follows the colon.
  For non-hybrid parents it must equal the parent's base type (MCQ_SUBPART → MCQ).
- Parts have no difficulty, ID or language lines; they inherit them.

## Raw JSON (written by `to-md` only)

When an existing topic JSON has a question that Markdown can't hold exactly (an
unknown field, a null, unusual whitespace), `to-md` writes it verbatim:

````markdown
### Variant 4

#### Raw JSON

```json
{ "question_type": "MCQ", ... }
```
````

This prevents data loss on round trips. Leave such blocks alone unless asked to
edit that question; then either edit the JSON carefully or rewrite the variant
as normal sections. Never write Raw JSON for new content.

## Commands

```bash
python3 scripts/topic_parser.py to-json <topic_name>.md            # writes <topic_name>.json next to it
python3 scripts/topic_parser.py to-json <topic_name>.md --partial  # while CTs are still being added
python3 scripts/topic_validator.py <topic_name>.json               # full offline validation
python3 scripts/topic_parser.py to-md <topic_name>.json            # existing JSON -> editable Markdown
python3 scripts/topic_parser.py roundtrip <topic_name>.json        # check json -> md -> json is lossless
python3 scripts/topic_parser.py check-pair <topic_name>.md <topic_name>.json   # before sharing: the two files match
```

`to-json` names the output after the input (`x.md` → `x.json`; use `-o` for
another name). The first time, it also saves the new `Topic ID` into the `.md`.
Parser errors name the line, the CT and the variant. Validator errors name the
CT and the variant; pass the `.md` instead of the `.json` to get line numbers
too. Fix only what they report.
