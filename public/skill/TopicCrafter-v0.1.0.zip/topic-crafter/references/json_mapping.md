# Markdown → topic JSON mapping

This page is for reviewers and for code that imports topics. Authors don't need
it: the parser does this mapping, and topic JSON is never written by hand.

## Topic

```json
{
  "topic_id": "6f1c2d3e-…",          // "- Topic ID:" (a new UUID4 when absent)
  "topic_name": "Linear equations",  // "# Topic: …"
  "cts": [ … ]                       // one per "## CT" section, in file order
}
```

`Language`, `Total CTs` and `Format` are checks and defaults only; they are not stored.
An `- Extra JSON: {…}` line adds its keys to the topic object.

## CT

```json
{"key": "linear_equations_ct_001",    // "## CT <n>: <key>"
 "difficulty_level": "EASY",          // "- Difficulty:"
 "variations": [ … ]}                 // one per "### Variant", in file order
```

`Type` is copied into every question. `Total variants` is a check only, and
`Concept` stays in the Markdown.

## Question envelope

Every top-level question gets:

| JSON field | Source |
| --- | --- |
| `question_type` | CT `Type:` |
| `difficulty_level` | CT `Difficulty:` |
| `language` | topic `Language:` |
| `ct_key` | CT key |
| `question_no` | `### Variant <n>` |

With `- Question IDs: positional` (legacy only), `ct_key` and `question_no` are
left out and questions are addressed by list position.

Parts inside `subparts` get `question_type` from the part heading and never get
`difficulty_level`, `ct_key` or `question_no`. Typed parts (DECIMAL,
MATH_EXPRESSION, PATTERN_MATCH) also get `language`, which their model requires.

## Sections → fields

| Section | JSON |
| --- | --- |
| Question / Solution / Hint / Answer box | `question` / `solution` / `hint` / `answer_box`: a string, or a list of `{"type":"text","text":…}` and `{"type":"media","media_type":"image","url":…,"description":…}` segments when the text contains `![description](url)` |
| Options | `options`: every item's text, in order. `correct_options`: the `[x]` items, in order |
| Answer | `correct_answer`: `true` / `false` |
| Placeholders (FIB, DROP_DOWN) | `placeholders: [{"placeholder_id": n, "correct_keyword": …, "incorrect_keywords": [ … ]}]` (plus `placeholder_type` for a `Type:` line) |
| Placeholders (DECIMAL) | `placeholders: [{"placeholder_id": n, "value": <number>, "min_decimal_places": <int>}]` |
| Placeholders (MATH_EXPRESSION) | `placeholders: [{"placeholder_id": n, "value": "\\(…\\)", "variables": [ … ], "valid_alternatives": [ … ]}]` |
| Placeholders (PATTERN_MATCH) | `placeholders: [{"placeholder_id": n, "value": "<regex>", "valid_examples": [ … ]}]` |
| Matches | `matches: [{"left": …, "right": …, "hint": …, "explanation": …}]` |
| Settings | `acceptance_tolerance: {"lower": x, "upper": y}`, `answers_interchangeable`, `matching` |
| Part n: TYPE | `subparts[n-1]` with that type's fields |
| Raw JSON | the whole question object, verbatim |

Numbers: `5` becomes an integer and `5.0` or `0.05` become floats, exactly as written.

## Round trips

- **md → json → md**: `to-md` rewrites the canonical layout. Content and IDs are
  kept; `Concept:` lines and free text are not, because JSON has no place for them.
- **json → md → json** is lossless. `to-md` writes any question it can't express
  exactly (unknown fields, nulls, unusual whitespace, mixed language or type) as a
  `#### Raw JSON` block, and warns. `roundtrip` checks this.
- The parser never renumbers, reorders, invents or drops IDs.

## Validation

`topic_validator.py` runs:
- the topic-identity checks (unique CT keys, no mixed or duplicate `question_no`,
  matching `ct_key`);
- the canonical rules (CT difficulty, one language, question difficulty equal to
  the CT difficulty, parts without difficulty);
- the platform's deterministic question verifier on every question. This includes
  the pydantic models, required hints, placeholder visibility, hint punctuation
  and local LaTeX delimiter checks.

All of these are vendored from the backend (`qc_models/`). The remote LaTeX parser is not included.
On top of them the skill adds `STYLE` **warnings**, which never change validity:
Markdown emphasis inside a field, and regex syntax that not every engine supports.

Findings carry a `code` (`PYDANTIC`, `HINT REQUIRED`, `PUNCTUATION`, `IDENTITY`, …),
a `field` path, the `ct_key` / `question_no` and the Markdown `line`. Use
`--json` for machine-readable output.
