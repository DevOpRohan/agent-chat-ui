"""Vendored QuestionCrafter question-model validators (offline, pydantic only).

Generated from the backend by scripts/sync_skill_models.py; only this file and
_compat.py are hand-maintained. See VENDOR_MANIFEST.json for the source hashes.
"""
