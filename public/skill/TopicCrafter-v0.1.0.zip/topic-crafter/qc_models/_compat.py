"""Pydantic-version shim for the ``MISSING`` sentinel (hand-maintained, not synced).

Native path (pydantic >= 2.14): ``Omittable[X]`` is ``X | MISSING`` and
``omitted()`` is ``MISSING`` -- byte-for-byte the upstream declaration.

Fallback (pydantic 2.0 - 2.13): the field is validated as plain ``X`` (so a
supplied ``None``/wrong type fails with exactly the same error as upstream),
defaults to a private ``MISSING`` singleton via ``default_factory`` (no default
in the JSON schema, no non-serializable-default warning), serializes that
singleton as ``None`` at field level (no serializer warnings, JSON-safe) and
``OmitMissingBase``'s wrap model-serializer then drops every key whose value is
``MISSING`` -- matching upstream "omitted from model_dump/model_dump_json".
"""
from __future__ import annotations

from typing import Annotated, Any, Union

from pydantic import BaseModel, Field, WrapSerializer, model_serializer

import os

# Native only where pydantic exposes pydantic.MISSING (>= 2.14). 2.12/2.13's
# experimental sentinel reports union-branch errors (loc ('x','constrained-int')
# + an extra missing_sentinel_error) that differ from 2.14, and importing
# pydantic.experimental warns on 2.8+, so those versions use the fallback.
try:
    from pydantic import MISSING  # type: ignore[attr-defined]
    NATIVE_MISSING = os.environ.get("QC_MODELS_FORCE_MISSING_FALLBACK") != "1"
except ImportError:
    NATIVE_MISSING = False

if NATIVE_MISSING:
    class Omittable:
        def __class_getitem__(cls, item: Any) -> Any:
            return Union[item, MISSING]

    def omitted() -> Any:
        return MISSING

    OmitMissingBase = BaseModel

else:
    class _MissingType:
        _instance = None

        def __new__(cls):
            if cls._instance is None:
                cls._instance = super().__new__(cls)
            return cls._instance

        def __repr__(self) -> str:
            return "MISSING"

        def __reduce__(self) -> str:
            return "MISSING"

        def __copy__(self):
            return self

        def __deepcopy__(self, memo):
            return self

    MISSING = _MissingType()  # type: ignore[assignment]

    def _serialize_missing(value, handler):  # no return annotation: keeps X in serialization JSON schema
        return None if value is MISSING else handler(value)

    class Omittable:  # type: ignore[no-redef]
        def __class_getitem__(cls, item: Any) -> Any:
            return Annotated[item, WrapSerializer(_serialize_missing)]

    def omitted() -> Any:  # type: ignore[no-redef]
        return Field(default_factory=lambda: MISSING)

    class OmitMissingBase(BaseModel):  # type: ignore[no-redef]
        @model_serializer(mode="wrap")
        def omit_missing_fields(self, handler):
            data = handler(self)
            if isinstance(data, dict):
                for name in type(self).model_fields:
                    if name in data and self.__dict__.get(name) is MISSING:
                        del data[name]
            return data


__all__ = ["MISSING", "NATIVE_MISSING", "Omittable", "OmitMissingBase", "omitted"]
