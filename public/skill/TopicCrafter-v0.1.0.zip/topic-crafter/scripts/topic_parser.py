#!/usr/bin/env python3
"""TopicCrafter converter: topic Markdown (topic-md v1) <-> canonical topic JSON.

Standard library only, offline, no credentials. Used by the TopicCrafter skill,
and importable unchanged by a server-side importer.

    python topic_parser.py to-json topic.md -o topic.json
    python topic_parser.py to-md topic.json -o topic.md
    python topic_parser.py roundtrip topic.json      # json -> md -> json must be equal
    python topic_parser.py check-pair topic.md topic.json   # before sharing: each file converts to the other

The Markdown contract is documented in references/markdown_format.md.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

FORMAT_LABEL = "topic-md 1"
FORMAT_VERSION = 1

SUPPORTED_LANGUAGES = [
    "English", "Arabic", "Hindi", "Traditional Chinese", "Vietnamese", "Bahasa",
    "Japanese", "Filipino", "Uzbek", "Russian", "Azerbaijani", "Kyrgyzstan",
    "Korean", "Malay", "Cebuano", "Hiligaynon", "Ilocano", "Waray", "Spanish",
    "Portuguese (Portugal)", "French", "Tamil",
]
DIFFICULTIES = ("EASY", "MEDIUM", "HARD")

BASE_TYPES = (
    "MCQ", "OPEN_ENDED", "TRUE_FALSE", "FIB", "DROP_DOWN", "MTC",
    "DECIMAL", "MATH_EXPRESSION", "PATTERN_MATCH",
)
# Subpart parent type -> required child type (None: any base type, HYBRID).
SUBPART_TYPES: Dict[str, Optional[str]] = {
    "OPEN_ENDED_SUBPART": "OPEN_ENDED",
    "MCQ_SUBPART": "MCQ",
    "FIB_SUBPART": "FIB",
    "DROP_DOWN_SUBPART": "DROP_DOWN",
    "TRUE_FALSE_SUBPART": "TRUE_FALSE",
    "DECIMAL_SUBPART": "DECIMAL",
    "MATH_EXPRESSION_SUBPART": "MATH_EXPRESSION",
    "PATTERN_MATCH_SUBPART": "PATTERN_MATCH",
    "HYBRID_SUBPART": None,
}
ALL_TYPES = BASE_TYPES + tuple(SUBPART_TYPES)
# CT "Question IDs:" modes. explicit (default): question_no + ct_key on every question;
# no-ct-key: question_no only (how the platform's generator stores topics);
# positional: neither (legacy; questions are addressed by list position).
IDENTITY_MODES = ("explicit", "no-ct-key", "positional")
TYPED_ANSWER_BOX_TYPES = ("DECIMAL", "MATH_EXPRESSION", "PATTERN_MATCH")
STRICT_SUBPART_TYPES = ("DECIMAL_SUBPART", "MATH_EXPRESSION_SUBPART", "PATTERN_MATCH_SUBPART")

# Section kinds per base type, in canonical order. (heading, kind, required)
_Q = ("Question", "rich", True)
_S = ("Solution", "rich", True)
_H = ("Hint", "rich", True)
BASE_SECTIONS: Dict[str, List[Tuple[str, str, bool]]] = {
    "OPEN_ENDED": [_Q, _S, _H],
    "MCQ": [_Q, ("Options", "options", True), _S, _H],
    "TRUE_FALSE": [_Q, ("Answer", "bool", True), _S, _H],
    "FIB": [_Q, ("Placeholders", "keyword_placeholders", True), _S, _H],
    "DROP_DOWN": [_Q, ("Placeholders", "keyword_placeholders", True), _S, _H],
    "MTC": [("Question", "rich", False), ("Matches", "matches", True),
            ("Solution", "rich", False), ("Hint", "rich", False)],
    "DECIMAL": [_Q, ("Answer box", "rich", True), ("Placeholders", "decimal_placeholders", True),
                ("Settings", "settings", True), _S, _H],
    "MATH_EXPRESSION": [_Q, ("Answer box", "rich", True),
                        ("Placeholders", "expression_placeholders", True),
                        ("Settings", "settings", True), _S, _H],
    "PATTERN_MATCH": [_Q, ("Answer box", "rich", True),
                      ("Placeholders", "pattern_placeholders", True), _S, _H],
}
SUBPART_PARENT_SECTIONS = [("Question", "rich", False), ("Solution", "rich", False),
                           ("Hint", "rich", False)]
STRICT_SUBPART_PARENT_SECTIONS = [("Question", "rich", True)]

SECTION_ALIASES = {
    "question": "Question", "stem": "Question", "context": "Question",
    "options": "Options", "choices": "Options",
    "answer": "Answer", "correct answer": "Answer",
    "placeholders": "Placeholders", "blanks": "Placeholders", "answers": "Placeholders",
    "matches": "Matches", "pairs": "Matches",
    "answer box": "Answer box", "answerbox": "Answer box",
    "settings": "Settings", "grading": "Settings",
    "solution": "Solution", "hint": "Hint",
    "raw json": "Raw JSON",
}

SETTINGS_KEYS = {
    "tolerance lower": "tolerance_lower", "lower tolerance": "tolerance_lower",
    "tolerance upper": "tolerance_upper", "upper tolerance": "tolerance_upper",
    "answers interchangeable": "answers_interchangeable", "interchangeable": "answers_interchangeable",
    "matching": "matching",
}
PLACEHOLDER_KEYS = {
    "keyword_placeholders": {"correct": "correct", "incorrect": "incorrect",
                             "distractor": "incorrect", "type": "type"},
    "decimal_placeholders": {"value": "value", "min decimal places": "min_decimal_places"},
    "expression_placeholders": {"value": "value", "variables": "variables",
                                "alternative": "alternative", "valid alternative": "alternative"},
    "pattern_placeholders": {"regex": "value", "value": "value", "example": "example",
                             "valid example": "example"},
}
MATCH_KEYS = {"left": "left", "right": "right", "hint": "hint", "explanation": "explanation"}

IMAGE_RE = re.compile(r'!\[([^\]\n]*)\]\(([^()\s"]+)(?:\s+"([^"\n]*)")?\)')
HEADING_RE = re.compile(r"^(#{1,6})[ \t]+(.*?)[ \t]*$")
HEADING_LIKE_RE = re.compile(r"^[ \t]{0,3}#{1,6}([ \t]|$)")
FENCE_RE = re.compile(r"^[ \t]{0,3}(`{3,}|~{3,})(.*)$")
META_RE = re.compile(r"^[ \t]*(?:[-*+][ \t]+)?(?:\*\*)?([A-Za-z][A-Za-z ]*?)(?:\*\*)?[ \t]*:(?:\*\*)?[ \t]*(.*?)[ \t]*$")
CT_HEADING_RE = re.compile(r"^CT(?:[ \t]*#?(\d+))?[ \t]*(?:[:.\-–—][ \t]*(.*))?$", re.I)
VARIANT_HEADING_RE = re.compile(r"^(?:Variant|Variation|Question)[ \t]*#?(\d+)[ \t]*:?$", re.I)
PART_HEADING_RE = re.compile(r"^Part[ \t]*#?(\d+)[ \t]*(?:[:.\-–—(][ \t]*([A-Za-z_ \-]+?)\)?)?[ \t]*$", re.I)
OPTION_RE = re.compile(r"^[-*+][ \t]+\[([ xX])\][ \t]?(.*)$")
ITEM_RE = re.compile(r"^[-*+][ \t]+(Placeholder|Blank|Match|Pair)[ \t]*#?\{?(?:placeholder)?(\d+)\}?[ \t]*:?[ \t]*$", re.I)
CHILD_RE = re.compile(r"^([ \t]+)[-*+][ \t]+([A-Za-z][A-Za-z ]*?)[ \t]*:[ \t]?(.*)$")
INT_RE = re.compile(r"^[+-]?\d+$")
FLOAT_RE = re.compile(r"^[+-]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?$")


# --------------------------------------------------------------------------- issues

@dataclass
class Issue:
    severity: str  # "error" | "warning"
    message: str
    line: Optional[int] = None
    ct_key: Optional[str] = None
    question_no: Optional[int] = None

    def where(self) -> str:
        parts = []
        if self.line is not None:
            parts.append(f"line {self.line}")
        if self.ct_key is not None:
            parts.append(f"CT {self.ct_key}")
        if self.question_no is not None:
            parts.append(f"variant {self.question_no}")
        return ", ".join(parts)

    def format(self) -> str:
        where = self.where()
        return f"{self.severity.upper()}: {where + ': ' if where else ''}{self.message}"

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if v is not None}


class ConversionError(Exception):
    def __init__(self, issues: List[Issue]):
        self.issues = issues
        super().__init__("\n".join(i.format() for i in issues if i.severity == "error"))


# --------------------------------------------------------------------------- normalisers

def canonical_language(value: str) -> Optional[str]:
    v = value.strip().lower()
    for lang in SUPPORTED_LANGUAGES:
        if lang.lower() == v:
            return lang
    return None


def canonical_type(value: str) -> Optional[str]:
    v = re.sub(r"[\s\-]+", "_", value.strip().strip("`").upper())
    aliases = {"TF": "TRUE_FALSE", "TRUEFALSE": "TRUE_FALSE", "DROPDOWN": "DROP_DOWN",
               "OPENENDED": "OPEN_ENDED", "HYBRID": "HYBRID_SUBPART", "MSQ": "MCQ",
               "FILL_IN_THE_BLANK": "FIB", "MATCH_THE_COLUMNS": "MTC"}
    v = aliases.get(v, v)
    return v if v in ALL_TYPES else None


def parse_bool(value: str) -> Optional[bool]:
    v = value.strip().strip("`*").lower()
    if v in ("true", "yes", "y", "t"):
        return True
    if v in ("false", "no", "n", "f"):
        return False
    return None


def parse_number(value: str) -> Optional[Any]:
    v = value.strip().strip("`")
    if INT_RE.match(v):
        return int(v)
    if FLOAT_RE.match(v):
        return float(v)
    return None


def parse_rich(text: str) -> Any:
    """Plain string, or a list of text/media segments when it contains images."""
    if not IMAGE_RE.search(text):
        return text
    segments: List[Dict[str, Any]] = []
    pos = 0
    for m in IMAGE_RE.finditer(text):
        if m.start() > pos:
            segments.append({"type": "text", "text": text[pos:m.start()]})
        seg: Dict[str, Any] = {"type": "media", "media_type": m.group(3) or "image", "url": m.group(2)}
        if m.group(1):
            seg["description"] = m.group(1)
        segments.append(seg)
        pos = m.end()
    if pos < len(text):
        segments.append({"type": "text", "text": text[pos:]})
    return segments


# --------------------------------------------------------------------------- markdown tree

@dataclass
class Section:
    name: str
    line: int
    body: List[Tuple[int, str]] = field(default_factory=list)

    def text(self) -> str:
        return "\n".join(t for _, t in self.body).strip()


@dataclass
class Part:
    ordinal: int
    type_label: Optional[str]
    line: int
    meta: List[Tuple[int, str]] = field(default_factory=list)
    sections: List[Section] = field(default_factory=list)


@dataclass
class VariantNode:
    number: int
    line: int
    meta: List[Tuple[int, str]] = field(default_factory=list)
    sections: List[Section] = field(default_factory=list)
    parts: List[Part] = field(default_factory=list)


@dataclass
class CTNode:
    ordinal: Optional[int]
    key: Optional[str]
    line: int
    meta: List[Tuple[int, str]] = field(default_factory=list)
    variants: List[VariantNode] = field(default_factory=list)


@dataclass
class TopicNode:
    name: Optional[str] = None
    line: int = 0
    meta: List[Tuple[int, str]] = field(default_factory=list)
    cts: List[CTNode] = field(default_factory=list)


def _section_name(text: str) -> Optional[str]:
    return SECTION_ALIASES.get(re.sub(r"\s+", " ", text.strip().rstrip(":").lower()))


def build_tree(md: str, issues: List[Issue]) -> TopicNode:
    topic = TopicNode()
    lines = md.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    fence: Optional[str] = None
    ct: Optional[CTNode] = None
    variant: Optional[VariantNode] = None
    part: Optional[Part] = None
    section: Optional[Section] = None
    seen_topic = False

    def sink(lineno: int, text: str) -> None:
        if section is not None:
            section.body.append((lineno, text))
        elif part is not None:
            part.meta.append((lineno, text))
        elif variant is not None:
            variant.meta.append((lineno, text))
        elif ct is not None:
            ct.meta.append((lineno, text))
        else:
            topic.meta.append((lineno, text))

    for idx, raw in enumerate(lines, start=1):
        if fence is not None:
            sink(idx, raw)
            stripped = raw.strip()
            if stripped.startswith(fence[0] * len(fence)) and set(stripped) <= {fence[0]}:
                fence = None
            continue
        fm = FENCE_RE.match(raw)
        if fm:
            fence = fm.group(1)
            sink(idx, raw)
            continue
        hm = HEADING_RE.match(raw)
        if not hm:
            if HEADING_LIKE_RE.match(raw) and raw.strip().strip("#").strip() == "":
                issues.append(Issue("error", "Empty heading", idx))
                continue
            sink(idx, raw)
            continue
        level, text = len(hm.group(1)), hm.group(2).strip()
        if level == 1:
            if seen_topic:
                issues.append(Issue("error", "Only one '# Topic: <name>' heading is allowed", idx))
                continue
            seen_topic = True
            name = re.sub(r"^Topic[ \t]*[:\-–—][ \t]*", "", text, flags=re.I).strip()
            topic.name, topic.line = name, idx
            ct = variant = part = section = None
            continue
        if level == 2:
            m = CT_HEADING_RE.match(text)
            if not m:
                issues.append(Issue("error", f"Unexpected level-2 heading '{text}'; expected '## CT <n>: <ct key>'", idx))
                continue
            ct = CTNode(ordinal=int(m.group(1)) if m.group(1) else None,
                        key=(m.group(2) or "").strip().strip("`") or None, line=idx)
            topic.cts.append(ct)
            variant = part = section = None
            continue
        if level == 3:
            m = VARIANT_HEADING_RE.match(text)
            if not m or ct is None:
                issues.append(Issue("error", f"Unexpected level-3 heading '{text}'; expected '### Variant <n>' inside a CT", idx))
                continue
            variant = VariantNode(number=int(m.group(1)), line=idx)
            ct.variants.append(variant)
            part = section = None
            continue
        if level == 4:
            if variant is None:
                issues.append(Issue("error", f"Section heading '{text}' outside a variant", idx))
                continue
            pm = PART_HEADING_RE.match(text)
            if pm:
                part = Part(ordinal=int(pm.group(1)), type_label=(pm.group(2) or "").strip() or None, line=idx)
                variant.parts.append(part)
                section = None
                continue
            name = _section_name(text)
            if name is None:
                issues.append(Issue("error", f"Unknown section '#### {text}'", idx, ct.key if ct else None, variant.number))
                section = Section("?", idx)  # swallow its body so it cannot leak into another field
                continue
            if variant.parts:
                issues.append(Issue("error", f"Section '#### {text}' after a '#### Part' heading; parent sections must come before the parts and part sections use '#####'", idx, ct.key if ct else None, variant.number))
                section = Section("?", idx)
                continue
            section = Section(name, idx)
            variant.sections.append(section)
            continue
        if level == 5:
            name = _section_name(text)
            if part is None or name is None:
                issues.append(Issue("error", f"Unexpected level-5 heading '{text}'; '##### <Section>' is only valid inside '#### Part <n>'", idx, ct.key if ct else None, variant.number if variant else None))
                section = Section("?", idx)
                continue
            section = Section(name, idx)
            part.sections.append(section)
            continue
        issues.append(Issue("error", f"Unexpected level-6 heading '{text}'", idx))
    if fence is not None:
        issues.append(Issue("error", "Unclosed code fence at end of file"))
    if not seen_topic:
        issues.append(Issue("error", "Missing '# Topic: <name>' heading", 1))
    return topic


# --------------------------------------------------------------------------- metadata

def _read_meta(lines: List[Tuple[int, str]], known: Dict[str, str], issues: List[Issue],
               scope: str, ct_key: Optional[str] = None, qno: Optional[int] = None) -> Dict[str, Tuple[int, str]]:
    out: Dict[str, Tuple[int, str]] = {}
    for lineno, text in lines:
        if not text.strip():
            continue
        m = META_RE.match(text)
        key = m.group(1).strip().lower() if m else None
        if m and key in known:
            canon = known[key]
            if canon in out:
                issues.append(Issue("error", f"Duplicate '{m.group(1)}' line in {scope}", lineno, ct_key, qno))
            out[canon] = (lineno, m.group(2).strip())
        elif m and text.lstrip().startswith(("-", "*", "+")):
            issues.append(Issue("warning", f"Ignored unknown {scope} field '{m.group(1)}'", lineno, ct_key, qno))
        else:
            issues.append(Issue("warning", f"Ignored free text in {scope}: {text.strip()[:60]!r}", lineno, ct_key, qno))
    return out


TOPIC_META = {"topic id": "topic_id", "id": "topic_id", "language": "language",
              "total cts": "total_cts", "cts": "total_cts", "format": "format",
              "extra json": "extra_json"}
CT_META = {"key": "key", "ct key": "key", "type": "type", "question type": "type",
           "difficulty": "difficulty", "difficulty level": "difficulty",
           "total variants": "total_variants", "variants": "total_variants",
           "concept": "concept", "question ids": "question_ids", "extra json": "extra_json"}
PART_META = {"type": "type", "language": "language"}


def _extra_json(entry: Optional[Tuple[int, str]], issues: List[Issue], ct_key=None) -> Dict[str, Any]:
    if entry is None:
        return {}
    lineno, text = entry
    try:
        value = json.loads(text.strip().strip("`"))
    except json.JSONDecodeError as exc:
        issues.append(Issue("error", f"'Extra JSON' is not valid JSON: {exc}", lineno, ct_key))
        return {}
    if not isinstance(value, dict):
        issues.append(Issue("error", "'Extra JSON' must be a JSON object", lineno, ct_key))
        return {}
    return value


# --------------------------------------------------------------------------- section parsers

class _Ctx:
    def __init__(self, issues: List[Issue], ct_key: Optional[str], qno: Optional[int]):
        self.issues, self.ct_key, self.qno = issues, ct_key, qno

    def err(self, msg: str, line: Optional[int]) -> None:
        self.issues.append(Issue("error", msg, line, self.ct_key, self.qno))

    def warn(self, msg: str, line: Optional[int]) -> None:
        self.issues.append(Issue("warning", msg, line, self.ct_key, self.qno))


def _nonblank(section: Section) -> List[Tuple[int, str]]:
    return [(n, t) for n, t in section.body if t.strip()]


def parse_options(section: Section, ctx: _Ctx) -> Tuple[List[Any], List[Any]]:
    options: List[List[Any]] = []  # [text, correct, line]
    for lineno, text in _nonblank(section):
        m = OPTION_RE.match(text)
        if m and not text[:1].isspace():
            options.append([m.group(2).strip(), m.group(1).lower() == "x", lineno])
        elif text[:1].isspace() and options:
            options[-1][0] += "\n" + text.strip()
        else:
            ctx.err(f"Options: expected '- [x] correct option' or '- [ ] other option', got {text.strip()[:60]!r}", lineno)
    if not options:
        ctx.err("Options: no options found", section.line)
    elif not any(o[1] for o in options):
        ctx.err("Options: no option is marked correct with '- [x]'", section.line)
    values = [parse_rich(o[0]) for o in options]
    return values, [v for v, o in zip(values, options) if o[1]]


def _parse_keyed_items(section: Section, keys: Dict[str, str], ctx: _Ctx, what: str) -> List[Dict[str, Any]]:
    """`- Placeholder 1` items with `  - Key: value` children (repeatable keys -> lists)."""
    items: List[Dict[str, Any]] = []
    last: Optional[List[Any]] = None  # [key, value] pair inside current item
    for lineno, text in _nonblank(section):
        m = ITEM_RE.match(text)
        if m:
            items.append({"_id": int(m.group(2)), "_line": lineno, "_pairs": []})
            last = None
            continue
        c = CHILD_RE.match(text)
        if c and items and c.group(2).strip().lower() in keys:
            last = [keys[c.group(2).strip().lower()], c.group(3).strip(), lineno]
            items[-1]["_pairs"].append(last)
            continue
        if c and items:
            known = ", ".join(dict.fromkeys(k.title() for k in keys))
            ctx.err(f"{what}: unknown key '{c.group(2).strip()}:' (keys for this type: {known})", lineno)
            last = None
            continue
        if text[:1].isspace() and last is not None and not re.match(r"^\s+[-*+]\s", text):
            last[1] += "\n" + text.strip()
            continue
        expected = ", ".join(sorted({k.title() for k in keys}))
        item = {"Matches": "Match", "Placeholders": "Placeholder"}.get(what, what)
        ctx.err(f"{what}: unexpected line {text.strip()[:60]!r} (expected '- {item} <n>' items with '  - <Key>: value' lines; keys: {expected})", lineno)
    return items


def _single(item: Dict[str, Any], key: str, ctx: _Ctx, what: str, required: bool = True) -> Optional[str]:
    values = [p for p in item["_pairs"] if p[0] == key]
    if len(values) > 1:
        ctx.err(f"{what} {item['_id']}: '{key}' given more than once", values[1][2])
    if not values:
        if required:
            ctx.err(f"{what} {item['_id']}: missing '{key.replace('_', ' ').title()}:' line", item["_line"])
        return None
    return values[0][1]


def _multi(item: Dict[str, Any], key: str) -> List[str]:
    return [p[1] for p in item["_pairs"] if p[0] == key]


def parse_keyword_placeholders(section: Section, ctx: _Ctx) -> List[Dict[str, Any]]:
    out = []
    for item in _parse_keyed_items(section, PLACEHOLDER_KEYS["keyword_placeholders"], ctx, "Placeholders"):
        ph: Dict[str, Any] = {"placeholder_id": item["_id"]}
        ptype = _single(item, "type", ctx, "Placeholder", required=False)
        if ptype is not None:
            ph["placeholder_type"] = ptype
        correct = _single(item, "correct", ctx, "Placeholder")
        ph["correct_keyword"] = parse_rich(correct) if correct is not None else ""
        ph["incorrect_keywords"] = [parse_rich(v) for v in _multi(item, "incorrect")]
        out.append(ph)
    if not out:
        ctx.err("Placeholders: no '- Placeholder <n>' items found", section.line)
    return out


def parse_decimal_placeholders(section: Section, ctx: _Ctx) -> List[Dict[str, Any]]:
    out = []
    for item in _parse_keyed_items(section, PLACEHOLDER_KEYS["decimal_placeholders"], ctx, "Placeholders"):
        ph: Dict[str, Any] = {"placeholder_id": item["_id"]}
        raw = _single(item, "value", ctx, "Placeholder")
        if raw is not None:
            num = parse_number(raw)
            if num is None:
                ctx.err(f"Placeholder {item['_id']}: Value must be a plain number (no LaTeX, units or commas), got {raw!r}", item["_line"])
            ph["value"] = num if num is not None else raw
        raw = _single(item, "min_decimal_places", ctx, "Placeholder")
        if raw is not None:
            num = parse_number(raw)
            if not isinstance(num, int):
                ctx.err(f"Placeholder {item['_id']}: Min decimal places must be a whole number, got {raw!r}", item["_line"])
            ph["min_decimal_places"] = num if isinstance(num, int) else raw
        out.append(ph)
    if not out:
        ctx.err("Placeholders: no '- Placeholder <n>' items found", section.line)
    return out


def _split_variables(raw: str) -> List[str]:
    if raw.strip().lower() in ("", "none", "-", "[]"):
        return []
    return [v.strip() for v in raw.split(",") if v.strip()]


def parse_expression_placeholders(section: Section, ctx: _Ctx) -> List[Dict[str, Any]]:
    out = []
    for item in _parse_keyed_items(section, PLACEHOLDER_KEYS["expression_placeholders"], ctx, "Placeholders"):
        ph: Dict[str, Any] = {"placeholder_id": item["_id"]}
        value = _single(item, "value", ctx, "Placeholder")
        ph["value"] = value if value is not None else ""
        variables = _single(item, "variables", ctx, "Placeholder")
        ph["variables"] = _split_variables(variables) if variables is not None else []
        ph["valid_alternatives"] = [v for v in _multi(item, "alternative") if v.strip().lower() != "none"]
        out.append(ph)
    if not out:
        ctx.err("Placeholders: no '- Placeholder <n>' items found", section.line)
    return out


def parse_pattern_placeholders(section: Section, ctx: _Ctx) -> List[Dict[str, Any]]:
    out = []
    for item in _parse_keyed_items(section, PLACEHOLDER_KEYS["pattern_placeholders"], ctx, "Placeholders"):
        ph: Dict[str, Any] = {"placeholder_id": item["_id"]}
        value = _single(item, "value", ctx, "Placeholder")
        if value is not None and len(value) >= 2 and value[0] == value[-1] == "`":
            value = value[1:-1]
        ph["value"] = value if value is not None else ""
        ph["valid_examples"] = _multi(item, "example")
        if not ph["valid_examples"]:
            ctx.err(f"Placeholder {item['_id']}: at least one 'Example:' line is required", item["_line"])
        out.append(ph)
    if not out:
        ctx.err("Placeholders: no '- Placeholder <n>' items found", section.line)
    return out


def parse_matches(section: Section, ctx: _Ctx) -> List[Dict[str, Any]]:
    out = []
    for item in _parse_keyed_items(section, MATCH_KEYS, ctx, "Matches"):
        match: Dict[str, Any] = {}
        for key in ("left", "right", "hint", "explanation"):
            value = _single(item, key, ctx, "Match", required=key in ("left", "right"))
            if value is not None:
                match[key] = parse_rich(value)
        out.append(match)
    if not out:
        ctx.err("Matches: no '- Match <n>' items found", section.line)
    return out


def parse_settings(section: Section, qtype: str, ctx: _Ctx) -> Dict[str, Any]:
    values: Dict[str, Tuple[int, str]] = {}
    for lineno, text in _nonblank(section):
        m = META_RE.match(text)
        key = m.group(1).strip().lower() if m else None
        if not m or key not in SETTINGS_KEYS:
            ctx.err(f"Settings: unexpected line {text.strip()[:60]!r} (keys: Tolerance lower, Tolerance upper, Answers interchangeable, Matching)", lineno)
            continue
        canon = SETTINGS_KEYS[key]
        if canon in values:
            ctx.err(f"Settings: '{m.group(1).strip()}' is given more than once", lineno)
        values[canon] = (lineno, m.group(2).strip())
    out: Dict[str, Any] = {}
    if qtype == "MATH_EXPRESSION":
        if "matching" in values:
            out["matching"] = values["matching"][1].strip("`").upper()
        else:
            ctx.err("Settings: 'Matching: EXACT' or 'Matching: EQUIVALENT' is required", section.line)
    if qtype == "DECIMAL":
        tol: Dict[str, Any] = {}
        for k in ("lower", "upper"):
            entry = values.get(f"tolerance_{k}")
            if entry is None:
                ctx.err(f"Settings: 'Tolerance {k}: <number>' is required (use 0 for exact answers)", section.line)
                continue
            num = parse_number(entry[1])
            if num is None:
                ctx.err(f"Settings: Tolerance {k} must be a plain number, got {entry[1]!r}", entry[0])
            tol[k] = num if num is not None else entry[1]
        out["acceptance_tolerance"] = tol
    if qtype in ("DECIMAL", "MATH_EXPRESSION"):
        entry = values.get("answers_interchangeable")
        if entry is None:
            ctx.err("Settings: 'Answers interchangeable: true|false' is required", section.line)
        else:
            b = parse_bool(entry[1])
            if b is None:
                ctx.err(f"Settings: Answers interchangeable must be true or false, got {entry[1]!r}", entry[0])
            out["answers_interchangeable"] = b if b is not None else entry[1]
    allowed = {"DECIMAL": {"tolerance_lower", "tolerance_upper", "answers_interchangeable"},
               "MATH_EXPRESSION": {"matching", "answers_interchangeable"}}.get(qtype, set())
    for k in sorted(set(values) - allowed):
        ctx.err(f"Settings: '{k.replace('_', ' ')}' does not apply to {qtype}", values[k][0])
    return out


# --------------------------------------------------------------------------- question assembly

def _sections_by_name(sections: List[Section], allowed: List[Tuple[str, str, bool]], ctx: _Ctx,
                      qtype: str, level: str = "####") -> Dict[str, Section]:
    allowed_names = {s[0] for s in allowed}
    out: Dict[str, Section] = {}
    for s in sections:
        if s.name == "?":
            continue
        if s.name not in allowed_names:
            ctx.err(f"Section '{s.name}' is not used by {qtype} (sections: {', '.join(a[0] for a in allowed)})", s.line)
            continue
        if s.name in out:
            ctx.err(f"Section '{s.name}' appears twice", s.line)
            continue
        out[s.name] = s
    for name, _, required in allowed:
        if required and name not in out:
            ctx.err(f"{qtype} needs a '{level} {name}' section", None)
    return out


def _fill_base(qtype: str, sections: Dict[str, Section], ctx: _Ctx) -> Dict[str, Any]:
    """Type-specific fields of a base question, in canonical JSON order (no envelope)."""
    out: Dict[str, Any] = {}

    def rich(name: str, key: str) -> None:
        if name in sections:
            out[key] = parse_rich(sections[name].text())

    if qtype == "MTC":
        rich("Question", "question")
        if "Matches" in sections:
            out["matches"] = parse_matches(sections["Matches"], ctx)
        rich("Solution", "solution")
        rich("Hint", "hint")
        return out
    rich("Question", "question")
    if qtype == "MCQ" and "Options" in sections:
        out["options"], out["correct_options"] = parse_options(sections["Options"], ctx)
    if qtype == "TRUE_FALSE" and "Answer" in sections:
        b = parse_bool(sections["Answer"].text().split("\n")[0] if sections["Answer"].text() else "")
        if b is None:
            ctx.err("Answer: write 'True' or 'False'", sections["Answer"].line)
        out["correct_answer"] = b if b is not None else sections["Answer"].text()
    if qtype in ("FIB", "DROP_DOWN") and "Placeholders" in sections:
        out["placeholders"] = parse_keyword_placeholders(sections["Placeholders"], ctx)
    if qtype in TYPED_ANSWER_BOX_TYPES:
        settings = parse_settings(sections["Settings"], qtype, ctx) if "Settings" in sections else {}
        if qtype == "MATH_EXPRESSION" and "matching" in settings:
            out["matching"] = settings["matching"]
        if "Placeholders" in sections:
            parser = {"DECIMAL": parse_decimal_placeholders, "MATH_EXPRESSION": parse_expression_placeholders,
                      "PATTERN_MATCH": parse_pattern_placeholders}[qtype]
            out["placeholders"] = parser(sections["Placeholders"], ctx)
        if "acceptance_tolerance" in settings:
            out["acceptance_tolerance"] = settings["acceptance_tolerance"]
        if "answers_interchangeable" in settings:
            out["answers_interchangeable"] = settings["answers_interchangeable"]
        rich("Answer box", "answer_box")
    rich("Solution", "solution")
    rich("Hint", "hint")
    return out


def _raw_json(section: Section, ctx: _Ctx) -> Optional[Dict[str, Any]]:
    text = section.text()
    m = re.match(r"^(`{3,}|~{3,})[^\n]*\n(.*)\n\1[ \t]*$", text, re.S)
    if not m:
        ctx.err("Raw JSON: body must be a single ```json fenced block", section.line)
        return None
    try:
        value = json.loads(m.group(2))
    except json.JSONDecodeError as exc:
        ctx.err(f"Raw JSON: invalid JSON ({exc})", section.line)
        return None
    if not isinstance(value, dict):
        ctx.err("Raw JSON: must be a JSON object (one question)", section.line)
        return None
    return value


def build_question(variant: VariantNode, ct_type: str, difficulty: Optional[str], language: str,
                   ct_key: str, identity: str, ctx: _Ctx) -> Optional[Dict[str, Any]]:
    raw = [s for s in variant.sections if s.name == "Raw JSON"]
    if raw:
        if len(variant.sections) > 1 or variant.parts:
            ctx.err("A variant with a 'Raw JSON' section cannot have other sections", raw[0].line)
        q = _raw_json(raw[0], ctx)
        if q is None:
            return None
        if "question_no" in q and q["question_no"] != variant.number:
            ctx.err(f"Raw JSON question_no {q['question_no']!r} differs from the heading 'Variant {variant.number}'", raw[0].line)
        if "ct_key" in q and q["ct_key"] != ct_key:
            ctx.err(f"Raw JSON ct_key {q['ct_key']!r} differs from the CT key '{ct_key}'", raw[0].line)
        return q
    for lineno, text in variant.meta:
        if text.strip():
            ctx.warn(f"Ignored text before the first section: {text.strip()[:60]!r}", lineno)

    q: Dict[str, Any] = {"question_type": ct_type}
    if ct_type in SUBPART_TYPES:
        allowed = STRICT_SUBPART_PARENT_SECTIONS if ct_type in STRICT_SUBPART_TYPES else SUBPART_PARENT_SECTIONS
        sections = _sections_by_name(variant.sections, allowed, ctx, ct_type)
        if "Question" in sections:
            q["question"] = parse_rich(sections["Question"].text())
        if difficulty:
            q["difficulty_level"] = difficulty
        q["subparts"] = build_subparts(variant, ct_type, language, ctx)
        for name, key in (("Solution", "solution"), ("Hint", "hint")):
            if name in sections:
                q[key] = parse_rich(sections[name].text())
    else:
        if variant.parts:
            ctx.err(f"'#### Part' headings are only used by subpart types, not {ct_type}", variant.parts[0].line)
        sections = _sections_by_name(variant.sections, BASE_SECTIONS[ct_type], ctx, ct_type)
        body = _fill_base(ct_type, sections, ctx)
        q["question"] = body.pop("question") if "question" in body else None
        if q["question"] is None:
            del q["question"]
        if difficulty:
            q["difficulty_level"] = difficulty
        q.update(body)
    q["language"] = language
    if identity == "explicit":
        q["ct_key"] = ct_key
    if identity in ("explicit", "no-ct-key"):
        q["question_no"] = variant.number
    return q


def build_subparts(variant: VariantNode, parent_type: str, language: str, ctx: _Ctx) -> List[Dict[str, Any]]:
    required_child = SUBPART_TYPES[parent_type]
    children = []
    if not variant.parts:
        ctx.err(f"{parent_type} needs at least one '#### Part <n>: <TYPE>' block", variant.line)
    for expected, part in enumerate(variant.parts, start=1):
        if part.ordinal != expected:
            ctx.warn(f"Part numbers should run 1, 2, 3…; found 'Part {part.ordinal}' at position {expected}", part.line)
        meta = _read_meta(part.meta, PART_META, ctx.issues, "part", ctx.ct_key, ctx.qno)
        label = part.type_label or (meta["type"][1] if "type" in meta else None)
        child_type = canonical_type(label) if label else required_child
        if label and child_type is None:
            ctx.err(f"Part {part.ordinal}: unknown type '{label}'", part.line)
            continue
        if child_type is None:
            ctx.err(f"Part {part.ordinal}: HYBRID_SUBPART parts need a type, e.g. '#### Part {part.ordinal}: MCQ'", part.line)
            continue
        if child_type not in BASE_TYPES:
            ctx.err(f"Part {part.ordinal}: '{child_type}' cannot be nested; parts use base types only", part.line)
            continue
        if required_child and child_type != required_child:
            ctx.err(f"Part {part.ordinal}: {parent_type} parts must be {required_child}, got {child_type}", part.line)
            continue
        sub_ctx = _Ctx(ctx.issues, ctx.ct_key, ctx.qno)
        sections = _sections_by_name(part.sections, BASE_SECTIONS[child_type], sub_ctx,
                                     f"Part {part.ordinal} ({child_type})", level="#####")
        child: Dict[str, Any] = {"question_type": child_type}
        child.update(_fill_base(child_type, sections, sub_ctx))
        child_language = meta.get("language")
        if child_language is not None:
            lang = canonical_language(child_language[1])
            if lang is None:
                ctx.err(f"Part {part.ordinal}: unsupported language '{child_language[1]}'", child_language[0])
            child["language"] = lang or child_language[1]
        elif child_type in TYPED_ANSWER_BOX_TYPES:
            child["language"] = language
        children.append(child)
    return children


# --------------------------------------------------------------------------- md -> json

def md_to_topic(md: str, *, allocate_topic_id: bool = True, partial: bool = False
                ) -> Tuple[Dict[str, Any], List[Issue], Dict[str, Any]]:
    """Convert topic Markdown to canonical topic JSON.

    Returns (topic, issues, info). Raises ConversionError when any error is found.
    partial=True (a topic still being written) downgrades a 'Total CTs' shortfall to a warning.
    info carries {"allocated_topic_id": bool, "source_lines": {(ct_key, qno): line}}.
    """
    issues: List[Issue] = []
    tree = build_tree(md, issues)
    meta = _read_meta(tree.meta, TOPIC_META, issues, "topic header")
    info: Dict[str, Any] = {"allocated_topic_id": False, "source_lines": {}}

    fmt = meta.get("format")
    if fmt is None:
        issues.append(Issue("warning", f"No 'Format: {FORMAT_LABEL}' line; assuming version {FORMAT_VERSION}", tree.line or None))
    else:
        m = re.search(r"(\d+)", fmt[1])
        if not m or int(m.group(1)) != FORMAT_VERSION:
            issues.append(Issue("error", f"Unsupported format '{fmt[1]}'; this parser reads '{FORMAT_LABEL}'", fmt[0]))

    language = "English"
    if "language" not in meta:
        issues.append(Issue("error", "Topic header needs a 'Language: <language>' line", tree.line or None))
    else:
        lang = canonical_language(meta["language"][1])
        if lang is None:
            issues.append(Issue("error", f"Unsupported language '{meta['language'][1]}'. Supported: {', '.join(SUPPORTED_LANGUAGES)}", meta["language"][0]))
        else:
            language = lang

    topic: Dict[str, Any] = {}
    if "topic_id" in meta and meta["topic_id"][1]:
        topic["topic_id"] = meta["topic_id"][1].strip("`")
    elif allocate_topic_id:
        topic["topic_id"] = str(uuid.uuid4())
        info["allocated_topic_id"] = True
    if tree.name:
        topic["topic_name"] = tree.name
    elif tree.line:
        issues.append(Issue("error", "Topic heading needs a name: '# Topic: <name>'", tree.line))
    topic["cts"] = []
    topic.update({k: v for k, v in _extra_json(meta.get("extra_json"), issues).items() if k not in topic})

    if "total_cts" not in meta:
        issues.append(Issue("error", "Topic header needs a 'Total CTs: <n>' line", tree.line or None))
    else:
        n = parse_number(meta["total_cts"][1])
        if n != len(tree.cts):
            short = partial and isinstance(n, int) and len(tree.cts) < n
            issues.append(Issue("warning" if short else "error",
                                f"'Total CTs: {meta['total_cts'][1]}' but the file has {len(tree.cts)} CT section(s)"
                                + ("; partial check, remaining CTs not written yet" if short else
                                   "; the file may be truncated or a CT is missing"), meta["total_cts"][0]))

    seen_keys: Dict[str, int] = {}
    for position, ct in enumerate(tree.cts, start=1):
        cmeta = _read_meta(ct.meta, CT_META, issues, "CT header", ct.key)
        key = ct.key or (cmeta["key"][1].strip("`") if "key" in cmeta else None)
        if ct.key and "key" in cmeta and cmeta["key"][1].strip("`") != ct.key:
            issues.append(Issue("error", f"CT heading key '{ct.key}' differs from 'Key: {cmeta['key'][1]}'", cmeta["key"][0], ct.key))
        if not key:
            issues.append(Issue("error", "CT needs a key: '## CT <n>: <ct_key>'", ct.line))
            key = f"__missing_key_{position}"
        if ct.ordinal is not None and ct.ordinal != position:
            issues.append(Issue("warning", f"CT numbers should run 1, 2, 3…; found 'CT {ct.ordinal}' at position {position}", ct.line, key))
        if key in seen_keys:
            issues.append(Issue("error", f"Duplicate CT key '{key}' (also at line {seen_keys[key]})", ct.line, key))
        seen_keys[key] = ct.line
        if key != key.strip() or re.search(r"\s", key):
            issues.append(Issue("error", f"CT key '{key}' must not contain spaces", ct.line, key))

        ct_type = None
        if "type" not in cmeta:
            issues.append(Issue("error", "CT header needs a 'Type: <QUESTION_TYPE>' line", ct.line, key))
        else:
            ct_type = canonical_type(cmeta["type"][1])
            if ct_type is None:
                issues.append(Issue("error", f"Unknown question type '{cmeta['type'][1]}'. Types: {', '.join(ALL_TYPES)}", cmeta["type"][0], key))
        difficulty = None
        if "difficulty" not in cmeta:
            issues.append(Issue("error", "CT header needs a 'Difficulty: EASY|MEDIUM|HARD' line", ct.line, key))
        else:
            difficulty = cmeta["difficulty"][1].strip("`*").upper()
            if difficulty not in DIFFICULTIES:
                issues.append(Issue("error", f"Difficulty must be EASY, MEDIUM or HARD, got '{cmeta['difficulty'][1]}'", cmeta["difficulty"][0], key))
        identity = "explicit"
        if "question_ids" in cmeta:
            identity = re.sub(r"[\s_]+", "-", cmeta["question_ids"][1].strip().lower())
            if identity not in IDENTITY_MODES:
                issues.append(Issue("error", "'Question IDs' must be 'explicit', 'no-ct-key' or 'positional'", cmeta["question_ids"][0], key))
                identity = "explicit"
        if "total_variants" not in cmeta:
            issues.append(Issue("error", "CT header needs a 'Total variants: <n>' line", ct.line, key))
        else:
            n = parse_number(cmeta["total_variants"][1])
            if n != len(ct.variants):
                issues.append(Issue("error", f"'Total variants: {cmeta['total_variants'][1]}' but the CT has {len(ct.variants)} variant(s); the file may be truncated or a variant is missing", cmeta["total_variants"][0], key))

        ct_json: Dict[str, Any] = {"key": key}
        if difficulty in DIFFICULTIES:
            ct_json["difficulty_level"] = difficulty
        ct_json["variations"] = []
        for k, v in _extra_json(cmeta.get("extra_json"), issues, key).items():
            ct_json.setdefault(k, v)

        seen_nos: Dict[int, int] = {}
        for position_v, variant in enumerate(ct.variants, start=1):
            if variant.number < 1:
                issues.append(Issue("error", "Variant numbers must be positive integers", variant.line, key))
            if variant.number in seen_nos:
                issues.append(Issue("error", f"Duplicate 'Variant {variant.number}' (also at line {seen_nos[variant.number]}); variant numbers are question IDs and must be unique in a CT", variant.line, key, variant.number))
            seen_nos[variant.number] = variant.line
            if identity == "positional" and variant.number != position_v:  # IDs are positions
                issues.append(Issue("error", f"With 'Question IDs: positional' variants must be numbered 1, 2, 3… in order; found {variant.number} at position {position_v}", variant.line, key))
            info["source_lines"][(key, variant.number)] = variant.line
            if ct_type is None:
                continue
            ctx = _Ctx(issues, key, variant.number)
            q = build_question(variant, ct_type, difficulty if difficulty in DIFFICULTIES else None,
                               language, key, identity, ctx)
            if q is not None:
                ct_json["variations"].append(q)
        topic["cts"].append(ct_json)

    if any(i.severity == "error" for i in issues):
        raise ConversionError(issues)
    return topic, issues, info


# --------------------------------------------------------------------------- json -> md

class Unrepresentable(Exception):
    pass


def _check_media(seg: Dict[str, Any]) -> str:
    if set(seg) - {"type", "media_type", "url", "description"}:
        raise Unrepresentable(f"media segment has extra fields {sorted(set(seg) - {'type', 'media_type', 'url', 'description'})}")
    url, desc, mtype = seg.get("url"), seg.get("description"), seg.get("media_type")
    if not isinstance(url, str) or not url or re.search(r'[\s()"]', url):
        raise Unrepresentable("media url is empty or contains spaces, quotes or parentheses")
    if desc is not None and (not isinstance(desc, str) or desc == "" or re.search(r"[\]\n]", desc)):
        raise Unrepresentable("media description is empty or contains ']' or a newline")
    if not isinstance(mtype, str) or not mtype or '"' in mtype or "\n" in mtype:
        raise Unrepresentable("media_type missing or not a simple string")
    title = "" if mtype == "image" else f' "{mtype}"'
    return f"![{desc or ''}]({url}{title})"


def render_rich(value: Any, *, inline: bool = False) -> str:
    """Render a string or segment list; raise Unrepresentable when parse_rich would differ."""
    if isinstance(value, str):
        text = value
        if IMAGE_RE.search(text):
            raise Unrepresentable("plain text contains Markdown image syntax")
    elif isinstance(value, list) and value:
        out, prev_text = [], False
        for seg in value:
            if not isinstance(seg, dict) or seg.get("type") not in ("text", "media"):
                raise Unrepresentable("unknown content segment")
            if seg["type"] == "text":
                if set(seg) != {"type", "text"} or not isinstance(seg["text"], str) or seg["text"] == "":
                    raise Unrepresentable("text segment with extra fields or empty text")
                if prev_text:
                    raise Unrepresentable("two adjacent text segments")
                if IMAGE_RE.search(seg["text"]):
                    raise Unrepresentable("text segment contains Markdown image syntax")
                out.append(seg["text"])
                prev_text = True
            else:
                out.append(_check_media(seg))
                prev_text = False
        if not any(seg["type"] == "media" for seg in value):
            raise Unrepresentable("segment list without media")
        text = "".join(out)
    else:
        raise Unrepresentable(f"unsupported content value {type(value).__name__}")
    if text != text.strip():
        raise Unrepresentable("leading or trailing whitespace")
    if inline:
        lines = text.split("\n")
        if any(l == "" or l != l.lstrip() for l in lines[1:]):
            raise Unrepresentable("multi-line value with blank or indented lines")
        if lines and OPTION_RE.match(lines[0]):
            raise Unrepresentable("value looks like a checkbox item")
    else:
        if any(HEADING_LIKE_RE.match(l) or FENCE_RE.match(l) for l in text.split("\n")):
            raise Unrepresentable("text contains heading-like or code-fence lines")
    if parse_rich(text) != value:
        raise Unrepresentable("content would not parse back identically")
    return text


def _inline(text: str, indent: str) -> str:
    return text.replace("\n", "\n" + indent + "  ")


def _fmt_number(value: Any) -> str:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise Unrepresentable(f"expected a number, got {value!r}")
    text = repr(value)
    if parse_number(text) != value or type(parse_number(text)) is not type(value):
        raise Unrepresentable(f"number {value!r} does not round-trip")
    return text


def _plain_inline(value: Any) -> str:
    if not isinstance(value, str) or value != value.strip() or "\n" in value or value == "":
        raise Unrepresentable(f"value {value!r} is not a non-empty single-line string")
    return value


def _render_base_body(q: Dict[str, Any], qtype: str, level: str) -> List[str]:
    """Sections for a base question; raises Unrepresentable."""
    allowed = {"question_type", "question", "solution", "hint"}
    out: List[str] = []

    def section(name: str, body: str) -> None:
        out.extend([f"{level} {name}", "", body, ""])

    def rich_section(name: str, key: str, required: bool) -> None:
        if key in q:
            if q[key] is None:
                raise Unrepresentable(f"'{key}' is null")
            section(name, render_rich(q[key]))
        elif required:
            raise Unrepresentable(f"missing '{key}'")

    required_main = qtype != "MTC"
    rich_section("Question", "question", required_main)
    if qtype == "MCQ":
        allowed |= {"options", "correct_options"}
        options, correct = q.get("options"), q.get("correct_options")
        if not isinstance(options, list) or not isinstance(correct, list) or not options:
            raise Unrepresentable("options/correct_options missing")
        if len({json.dumps(o, sort_keys=True) for o in options}) != len(options):
            raise Unrepresentable("duplicate options")
        marked = [o for o in options if o in correct]
        if marked != correct:
            raise Unrepresentable("correct_options are not an in-order subset of options")
        lines = []
        for o in options:
            lines.append(f"- [{'x' if o in correct else ' '}] {_inline(render_rich(o, inline=True), '')}")
        section("Options", "\n".join(lines))
    if qtype == "TRUE_FALSE":
        allowed.add("correct_answer")
        if not isinstance(q.get("correct_answer"), bool):
            raise Unrepresentable("correct_answer is not a boolean")
        section("Answer", "True" if q["correct_answer"] else "False")
    if qtype in ("FIB", "DROP_DOWN"):
        allowed.add("placeholders")
        lines = []
        for ph in _list(q, "placeholders"):
            if set(ph) - {"placeholder_id", "placeholder_type", "correct_keyword", "incorrect_keywords"}:
                raise Unrepresentable("placeholder has extra fields")
            lines.append(f"- Placeholder {_pid(ph)}")
            if "placeholder_type" in ph:
                if ph["placeholder_type"] is None:
                    raise Unrepresentable("placeholder_type is null")
                lines.append(f"  - Type: {_plain_inline(ph['placeholder_type'])}")
            lines.append(f"  - Correct: {_inline(render_rich(ph.get('correct_keyword'), inline=True), '  ')}")
            if not isinstance(ph.get("incorrect_keywords"), list):
                raise Unrepresentable("incorrect_keywords missing")
            for kw in ph["incorrect_keywords"]:
                lines.append(f"  - Incorrect: {_inline(render_rich(kw, inline=True), '  ')}")
        section("Placeholders", "\n".join(lines))
    if qtype == "MTC":
        allowed.add("matches")
        lines = []
        for i, m in enumerate(_list(q, "matches"), start=1):
            if set(m) - {"left", "right", "hint", "explanation"}:
                raise Unrepresentable("match has extra fields")
            lines.append(f"- Match {i}")
            for key in ("left", "right", "hint", "explanation"):
                if key in m:
                    if m[key] is None:
                        raise Unrepresentable(f"match {key} is null")
                    lines.append(f"  - {key.title()}: {_inline(render_rich(m[key], inline=True), '  ')}")
                elif key in ("left", "right"):
                    raise Unrepresentable(f"match missing {key}")
        section("Matches", "\n".join(lines))
    if qtype in TYPED_ANSWER_BOX_TYPES:
        allowed |= {"answer_box", "placeholders"}
        rich_section("Answer box", "answer_box", True)
        lines = []
        for ph in _list(q, "placeholders"):
            lines.append(f"- Placeholder {_pid(ph)}")
            if qtype == "DECIMAL":
                if set(ph) != {"placeholder_id", "value", "min_decimal_places"}:
                    raise Unrepresentable("DECIMAL placeholder fields differ from the contract")
                lines.append(f"  - Value: {_fmt_number(ph['value'])}")
                if not isinstance(ph["min_decimal_places"], int) or isinstance(ph["min_decimal_places"], bool):
                    raise Unrepresentable("min_decimal_places is not an integer")
                lines.append(f"  - Min decimal places: {ph['min_decimal_places']}")
            elif qtype == "MATH_EXPRESSION":
                if set(ph) != {"placeholder_id", "value", "variables", "valid_alternatives"}:
                    raise Unrepresentable("MATH_EXPRESSION placeholder fields differ from the contract")
                lines.append(f"  - Value: {_plain_inline(ph['value'])}")
                variables = ph["variables"]
                if not isinstance(variables, list) or any(
                        not isinstance(v, str) or "," in v or v != v.strip() or not v or v.lower() == "none" for v in variables):
                    raise Unrepresentable("variables are not simple comma-free strings")
                lines.append(f"  - Variables: {', '.join(variables) if variables else 'none'}")
                if not isinstance(ph["valid_alternatives"], list):
                    raise Unrepresentable("valid_alternatives is not a list")
                for alt in ph["valid_alternatives"]:
                    if isinstance(alt, str) and alt.strip().lower() == "none":
                        raise Unrepresentable("alternative literally 'none'")
                    lines.append(f"  - Alternative: {_plain_inline(alt)}")
            else:
                if set(ph) != {"placeholder_id", "value", "valid_examples"}:
                    raise Unrepresentable("PATTERN_MATCH placeholder fields differ from the contract")
                value = _plain_inline(ph["value"])
                if len(value) >= 2 and value[0] == value[-1] == "`":
                    raise Unrepresentable("regex wrapped in backticks")
                lines.append(f"  - Regex: {value}")
                if not isinstance(ph["valid_examples"], list) or not ph["valid_examples"]:
                    raise Unrepresentable("valid_examples missing or empty")
                for ex in ph["valid_examples"]:
                    lines.append(f"  - Example: {_plain_inline(ex)}")
        section("Placeholders", "\n".join(lines))
        settings = []
        if qtype == "MATH_EXPRESSION":
            allowed.add("matching")
            if q.get("matching") not in ("EXACT", "EQUIVALENT"):
                raise Unrepresentable("matching is not EXACT/EQUIVALENT")
            settings.append(f"- Matching: {q['matching']}")
        if qtype == "DECIMAL":
            allowed.add("acceptance_tolerance")
            tol = q.get("acceptance_tolerance")
            if not isinstance(tol, dict) or set(tol) != {"lower", "upper"}:
                raise Unrepresentable("acceptance_tolerance is not {lower, upper}")
            settings.append(f"- Tolerance lower: {_fmt_number(tol['lower'])}")
            settings.append(f"- Tolerance upper: {_fmt_number(tol['upper'])}")
        if qtype in ("DECIMAL", "MATH_EXPRESSION"):
            allowed.add("answers_interchangeable")
            if not isinstance(q.get("answers_interchangeable"), bool):
                raise Unrepresentable("answers_interchangeable is not a boolean")
            settings.append(f"- Answers interchangeable: {'true' if q['answers_interchangeable'] else 'false'}")
        if settings:
            section("Settings", "\n".join(settings))
    rich_section("Solution", "solution", required_main)
    rich_section("Hint", "hint", required_main)
    return out, allowed


def _list(q: Dict[str, Any], key: str) -> List[Dict[str, Any]]:
    value = q.get(key)
    if not isinstance(value, list) or not value or not all(isinstance(v, dict) for v in value):
        raise Unrepresentable(f"'{key}' is not a non-empty list of objects")
    return value


def _pid(ph: Dict[str, Any]) -> int:
    pid = ph.get("placeholder_id")
    if isinstance(pid, bool) or not isinstance(pid, int) or pid < 1:
        raise Unrepresentable("placeholder_id is not a positive integer")
    return pid


def render_question(q: Dict[str, Any], ct_type: str, difficulty: Optional[str], language: str,
                    ct_key: str, number: int, identity: str) -> List[str]:
    """Markdown lines for one variant body; raises Unrepresentable."""
    if q.get("question_type") != ct_type:
        raise Unrepresentable(f"question_type {q.get('question_type')!r} differs from the CT type {ct_type}")
    envelope = {"question_type", "difficulty_level", "language", "ct_key", "question_no"}
    if difficulty is None or q.get("difficulty_level") != difficulty:
        raise Unrepresentable("difficulty_level missing or differs from the CT difficulty")
    if q.get("language") != language:
        raise Unrepresentable("language missing or differs from the topic language")
    has_key, has_no = "ct_key" in q, "question_no" in q
    expected = {"explicit": (True, True), "no-ct-key": (False, True), "positional": (False, False)}[identity]
    if (has_key, has_no) != expected:
        raise Unrepresentable(f"identity fields differ from the CT's 'Question IDs: {identity}' mode")
    if (has_key and q["ct_key"] != ct_key) or (has_no and q["question_no"] != number):
        raise Unrepresentable("ct_key/question_no inconsistent with the CT")
    if ct_type in SUBPART_TYPES:
        lines: List[str] = []
        allowed = set(envelope) | {"subparts", "question", "solution", "hint"}
        if ct_type in STRICT_SUBPART_TYPES:
            allowed = set(envelope) | {"subparts", "question"}
        if set(q) - allowed:
            raise Unrepresentable(f"unexpected fields {sorted(set(q) - allowed)}")
        if "question" in q:
            if q["question"] is None:
                raise Unrepresentable("'question' is null")
            lines += ["#### Question", "", render_rich(q["question"]), ""]
        for key, name in (("solution", "Solution"), ("hint", "Hint")):
            if key in q:
                if q[key] is None:
                    raise Unrepresentable(f"'{key}' is null")
                lines += [f"#### {name}", "", render_rich(q[key]), ""]
        required_child = SUBPART_TYPES[ct_type]
        for i, child in enumerate(_list(q, "subparts"), start=1):
            ctype = child.get("question_type")
            if ctype not in BASE_TYPES or (required_child and ctype != required_child):
                raise Unrepresentable(f"subpart {i} has type {ctype!r}")
            if "difficulty_level" in child or "ct_key" in child or "question_no" in child:
                raise Unrepresentable(f"subpart {i} carries difficulty/identity fields")
            body, allowed_child = _render_base_body(child, ctype, "#####")
            allowed_child.add("language")
            if set(child) - allowed_child:
                raise Unrepresentable(f"subpart {i} has unexpected fields {sorted(set(child) - allowed_child)}")
            lines += [f"#### Part {i}: {ctype}", ""]
            default_lang = ctype in TYPED_ANSWER_BOX_TYPES
            if "language" in child:
                if not isinstance(child["language"], str) or canonical_language(child["language"]) != child["language"]:
                    raise Unrepresentable(f"subpart {i} language is not a supported language name")
                if not (default_lang and child["language"] == language):
                    lines += [f"- Language: {child['language']}", ""]
            elif default_lang:
                raise Unrepresentable(f"typed subpart {i} has no language")
            lines += body
        return lines
    body, allowed = _render_base_body(q, ct_type, "####")
    allowed |= envelope
    if set(q) - allowed:
        raise Unrepresentable(f"unexpected fields {sorted(set(q) - allowed)}")
    return body


def _raw_block(q: Dict[str, Any]) -> List[str]:
    text = json.dumps(q, ensure_ascii=False, indent=2)
    fence = "```"
    while fence in text:
        fence += "`"
    return ["#### Raw JSON", "", f"{fence}json", text, fence, ""]


def topic_to_md(topic: Dict[str, Any]) -> Tuple[str, List[Issue]]:
    """Render canonical topic JSON as Markdown. Content that Markdown cannot hold exactly
    is kept verbatim in a '#### Raw JSON' block and reported as a warning (never dropped)."""
    issues: List[Issue] = []
    if not isinstance(topic, dict) or not isinstance(topic.get("cts"), list):
        raise ConversionError([Issue("error", "Invalid topic JSON: expected an object with a 'cts' list")])
    cts = topic["cts"]
    languages = [q.get("language") for ct in cts if isinstance(ct, dict)
                 for q in (ct.get("variations") or []) if isinstance(q, dict) and isinstance(q.get("language"), str)]
    language = max(set(languages), key=languages.count) if languages else "English"
    if canonical_language(language) != language:
        issues.append(Issue("warning", f"Topic language {language!r} is not a supported language name"))

    name = topic.get("topic_name")
    lines = [f"# Topic: {name if isinstance(name, str) and name.strip() else 'Untitled topic'}", ""]
    if not (isinstance(name, str) and name.strip()):
        issues.append(Issue("warning", "topic_name missing; wrote 'Untitled topic' (converting back will add topic_name)"))
    if "topic_id" in topic:
        if not isinstance(topic["topic_id"], str) or topic["topic_id"] != topic["topic_id"].strip() or not topic["topic_id"]:
            raise ConversionError([Issue("error", "topic_id must be a non-empty string without padding")])
        lines.append(f"- Topic ID: {topic['topic_id']}")
    lines.append(f"- Language: {language}")
    lines.append(f"- Total CTs: {len(cts)}")
    lines.append(f"- Format: {FORMAT_LABEL}")
    extra = {k: v for k, v in topic.items() if k not in ("topic_id", "topic_name", "cts")}
    if extra:
        lines.append(f"- Extra JSON: {json.dumps(extra, ensure_ascii=False)}")
    lines.append("")

    for position, ct in enumerate(cts, start=1):
        if not isinstance(ct, dict):
            raise ConversionError([Issue("error", f"CT at index {position - 1} is not an object")])
        key = ct.get("key")
        if not isinstance(key, str) or not key or re.search(r"\s", key):
            raise ConversionError([Issue("error", f"CT at index {position - 1} has an invalid key {key!r}")])
        variations = ct.get("variations")
        if not isinstance(variations, list):
            raise ConversionError([Issue("error", f"CT '{key}' has no variations list")])
        types = [q.get("question_type") for q in variations if isinstance(q, dict)]
        ct_type = max(set(types), key=types.count) if types else None
        if ct_type not in ALL_TYPES:
            ct_type = next((t for t in types if t in ALL_TYPES), "OPEN_ENDED")
        difficulty = ct.get("difficulty_level")
        numbered = [isinstance(q, dict) and "question_no" in q for q in variations]
        if any(numbered) and not all(numbered):
            raise ConversionError([Issue("error", f"CT '{key}' mixes questions with and without question_no; fix the topic identity first", ct_key=key)])
        keyed = sum(1 for q in variations if isinstance(q, dict) and "ct_key" in q)
        if variations and not any(numbered):
            identity = "positional"
        elif keyed * 2 >= len(variations):
            identity = "explicit"
        else:
            identity = "no-ct-key"
        lines.append(f"## CT {position}: {key}")
        lines.append("")
        lines.append(f"- Type: {ct_type}")
        if difficulty is not None:
            lines.append(f"- Difficulty: {difficulty}")
        lines.append(f"- Total variants: {len(variations)}")
        if identity != "explicit":
            lines.append(f"- Question IDs: {identity}")
        ct_extra = {k: v for k, v in ct.items() if k not in ("key", "difficulty_level", "variations")}
        if ct_extra:
            lines.append(f"- Extra JSON: {json.dumps(ct_extra, ensure_ascii=False)}")
        if difficulty is not None and difficulty not in DIFFICULTIES:
            issues.append(Issue("warning", f"CT difficulty {difficulty!r} is not EASY/MEDIUM/HARD", ct_key=key))
        lines.append("")
        for index, q in enumerate(variations):
            if not isinstance(q, dict):
                raise ConversionError([Issue("error", f"Variation {index} of CT '{key}' is not an object")])
            number = q["question_no"] if identity != "positional" else index + 1
            if isinstance(number, bool) or not isinstance(number, int) or number < 1:
                raise ConversionError([Issue("error", f"Variation {index} of CT '{key}' has invalid question_no {number!r}")])
            lines.append(f"### Variant {number}")
            lines.append("")
            try:
                lines += render_question(q, ct_type, difficulty if difficulty in DIFFICULTIES else None,
                                         language, key, number, identity)
            except Unrepresentable as exc:
                issues.append(Issue("warning", f"kept as Raw JSON: {exc}", ct_key=key, question_no=number))
                lines += _raw_block(q)
    text = "\n".join(lines).rstrip("\n") + "\n"
    return text, issues


# --------------------------------------------------------------------------- source-map helpers

def insert_topic_id(md: str, topic_id: str) -> str:
    """Insert a '- Topic ID:' line right after the '# Topic:' heading."""
    lines = md.split("\n")
    for i, line in enumerate(lines):
        if HEADING_RE.match(line) and line.startswith("# "):
            insert_at = i + 1
            while insert_at < len(lines) and not lines[insert_at].strip():
                insert_at += 1
            lines.insert(insert_at, f"- Topic ID: {topic_id}")
            if insert_at == i + 1:
                lines.insert(insert_at, "")
            return "\n".join(lines)
    return md


def load_topic_file(path: str, *, partial: bool = False) -> Tuple[Dict[str, Any], List[Issue], Dict[str, Any]]:
    """Load .json or .md into canonical topic JSON (no topic_id allocation)."""
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    if path.lower().endswith(".json") or text.lstrip().startswith("{"):
        try:
            data = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ConversionError([Issue("error", f"Invalid JSON: {exc}", exc.lineno)])
        return data, [], {"source_lines": {}}
    return md_to_topic(text, allocate_topic_id=False, partial=partial)


# --------------------------------------------------------------------------- CLI

def _print_issues(issues: List[Issue], stream=sys.stderr, limit: int = 200) -> None:
    for issue in issues[:limit]:
        print(issue.format(), file=stream)
    if len(issues) > limit:
        print(f"... {len(issues) - limit} more", file=stream)


def _cmd_to_json(args: argparse.Namespace) -> int:
    with open(args.input, encoding="utf-8") as fh:
        md = fh.read()
    try:
        topic, issues, info = md_to_topic(md, partial=args.partial)
    except ConversionError as exc:
        _print_issues(exc.issues)
        errors = sum(1 for i in exc.issues if i.severity == "error")
        print(f"FAILED: {errors} error(s); no JSON written. Fix the Markdown and re-run.", file=sys.stderr)
        return 1
    _print_issues(issues)
    if info["allocated_topic_id"] and not args.no_write_back:
        with open(args.input, "w", encoding="utf-8") as fh:
            fh.write(insert_topic_id(md, topic["topic_id"]))
        print(f"Assigned new topic_id {topic['topic_id']} and saved it into {args.input} (keep it for future edits).", file=sys.stderr)
    out = args.output or re.sub(r"\.(md|markdown)$", "", args.input, flags=re.IGNORECASE) + ".json"
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(topic, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    n = sum(len(ct["variations"]) for ct in topic["cts"])
    validator = os.path.join(os.path.dirname(os.path.abspath(__file__)), "topic_validator.py")
    print(f"OK: wrote {out} ({len(topic['cts'])} CTs, {n} questions). Next: python3 {validator} {out}"
          + (" --partial" if args.partial else ""))
    return 0


def _cmd_to_md(args: argparse.Namespace) -> int:
    with open(args.input, encoding="utf-8") as fh:
        try:
            topic = json.load(fh)
        except json.JSONDecodeError as exc:
            print(f"ERROR: invalid JSON: {exc}", file=sys.stderr)
            return 1
    try:
        md, issues = topic_to_md(topic)
    except ConversionError as exc:
        _print_issues(exc.issues)
        return 1
    _print_issues(issues)
    out = args.output or re.sub(r"\.json$", "", args.input, flags=re.IGNORECASE) + ".md"
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(md)
    raw = sum(1 for i in issues if "Raw JSON" in i.message)
    print(f"OK: wrote {out}" + (f" ({raw} question(s) kept as Raw JSON; see warnings)" if raw else ""))
    return 0


def _round_trip(topic: Dict[str, Any]) -> Tuple[Optional[str], List[Issue]]:
    """json -> md -> json. Returns (failure message or None, to-md issues)."""
    md, issues = topic_to_md(topic)
    try:
        back, _, _ = md_to_topic(md, allocate_topic_id=False)
    except ConversionError as exc:
        _print_issues(exc.issues)
        return "generated Markdown did not parse", issues
    if "topic_name" not in topic:
        back.pop("topic_name", None)
    return (None if back == topic else "json -> md -> json changed the topic"), issues


def _cmd_roundtrip(args: argparse.Namespace) -> int:
    with open(args.input, encoding="utf-8") as fh:
        topic = json.load(fh)
    failure, issues = _round_trip(topic)
    if failure:
        print(f"FAILED: {failure}", file=sys.stderr)
        return 1
    raw = sum(1 for i in issues if "Raw JSON" in i.message)
    print(f"OK: lossless round trip ({raw} question(s) via Raw JSON)")
    return 0


def _cmd_check_pair(args: argparse.Namespace) -> int:
    """The pair is shareable only if the .json is exactly what to-json makes from the .md, and back."""
    with open(args.markdown, encoding="utf-8") as fh:
        md = fh.read()
    try:
        from_md, _, _ = md_to_topic(md, allocate_topic_id=False, partial=args.partial)
    except ConversionError as exc:
        _print_issues(exc.issues)
        print(f"FAILED: {args.markdown} does not convert. Fix it, then run to-json.", file=sys.stderr)
        return 1
    with open(args.json, encoding="utf-8") as fh:
        try:
            topic = json.load(fh)
        except json.JSONDecodeError as exc:
            print(f"FAILED: invalid JSON in {args.json}: {exc}", file=sys.stderr)
            return 1
    if "topic_id" not in from_md:
        print(f"FAILED: {args.markdown} has no Topic ID yet. Run: to-json {args.markdown}", file=sys.stderr)
        return 1
    if from_md != topic:
        print(f"FAILED: {args.json} was not made from the current {args.markdown}. Run: to-json {args.markdown}",
              file=sys.stderr)
        return 1
    failure, _ = _round_trip(topic)
    if failure:
        print(f"FAILED: {failure}", file=sys.stderr)
        return 1
    print(f"OK: {args.markdown} and {args.json} match; each converts to the other")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Convert topic Markdown <-> topic JSON (topic-md v1).")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("to-json", help="topic.md -> topic.json")
    p.add_argument("input")
    p.add_argument("-o", "--output")
    p.add_argument("--no-write-back", action="store_true",
                   help="do not save a newly assigned Topic ID into the Markdown file")
    p.add_argument("--partial", action="store_true",
                   help="topic still being written: fewer CTs than 'Total CTs' is a warning, not an error")
    p.set_defaults(func=_cmd_to_json)
    p = sub.add_parser("to-md", help="topic.json -> topic.md")
    p.add_argument("input")
    p.add_argument("-o", "--output")
    p.set_defaults(func=_cmd_to_md)
    p = sub.add_parser("roundtrip", help="check json -> md -> json is lossless")
    p.add_argument("input")
    p.set_defaults(func=_cmd_roundtrip)
    p = sub.add_parser("check-pair", help="check topic.md and topic.json match, before sharing them")
    p.add_argument("markdown")
    p.add_argument("json")
    p.add_argument("--partial", action="store_true", help="topic still being written (as for to-json)")
    p.set_defaults(func=_cmd_check_pair)
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
