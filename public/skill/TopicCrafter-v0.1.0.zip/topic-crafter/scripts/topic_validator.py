#!/usr/bin/env python3
"""TopicCrafter validator: checks a topic (.md or .json) against the platform rules.

Offline, Python + pydantic only. Runs the vendored copies of the backend question
models and deterministic verifier (qc_models/), plus topic-level identity and
canonical-format checks. The platform's remote LaTeX parser is NOT run here, so a
topic that passes locally can still get a LaTeX finding when it is imported.

    python topic_validator.py topic.json          # or topic.md
    python topic_validator.py topic.json --json   # machine-readable report

Exit code 0 = valid, 1 = errors found, 2 = could not read the input,
3 = structure valid but question models not checked (pydantic 2.x unavailable).

A server-side importer can call validate_topic_async() with the backend's own
verifier (which adds the remote LaTeX parser), so local and server results agree
on everything except that parser.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import re
import sys
from dataclasses import asdict, dataclass
from typing import Any, Awaitable, Callable, Dict, List, Optional, Sequence, Tuple

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import topic_parser as tp  # noqa: E402

# A per-question verifier returns the backend's issue strings ("[PYDANTIC] ...").
QuestionVerifier = Callable[[Dict[str, Any]], Awaitable[List[str]]]


@dataclass
class Finding:
    message: str
    code: str
    severity: str = "error"  # "error" | "warning"
    ct_key: Optional[str] = None
    question_no: Optional[int] = None
    field: Optional[str] = None
    line: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class Report:
    findings: List[Finding]
    cts: int = 0
    questions: int = 0
    model_checks: bool = True

    @property
    def errors(self) -> List[Finding]:
        return [f for f in self.findings if f.severity == "error"]

    @property
    def valid(self) -> bool:
        return not self.errors

    def invalid_questions(self) -> List[Tuple[str, int]]:
        seen: Dict[Tuple[str, int], None] = {}
        for f in self.errors:
            if f.ct_key is not None and f.question_no is not None:
                seen[(f.ct_key, f.question_no)] = None
        return list(seen)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "valid": self.valid,
            "model_checks": self.model_checks,
            "cts": self.cts,
            "questions": self.questions,
            "error_count": len(self.errors),
            "warning_count": len(self.findings) - len(self.errors),
            "invalid_questions": [{"ct_key": k, "question_no": n} for k, n in self.invalid_questions()],
            "findings": [f.to_dict() for f in self.findings],
        }


# --------------------------------------------------------------------------- issue parsing

_CODE_RE = re.compile(r"^\[([A-Z][A-Z ]+)\]")


def _field_from_issue(issue: str) -> Optional[str]:
    m = re.search(r"Field '([^']+)'", issue)
    if m:
        parts = [p.strip() for p in m.group(1).split("->")]
        out = ""
        for p in parts:
            if p.isdigit():
                out += f"[{p}]"
            elif p in tp.ALL_TYPES and out.endswith("]"):
                continue  # discriminator tag in a union path
            else:
                out += ("." if out else "") + p
        return out or None
    m = re.search(r"^\[PARSER LATEX\]\s*\nField:\s*([^\s\[]+(?:\[[^\]]*\])*)", issue)
    if m:
        return re.sub(r"\['[^']*'\]$", "", m.group(1))
    m = re.search(r"Missing required field[: ]+'([^']+)'", issue)
    if m:
        return m.group(1)
    m = re.search(r"^\[[A-Z ]+\]\s+(root\.)?([A-Za-z_][\w\[\].]*)\s*(:|contains)", issue)
    if m:
        return m.group(2)
    m = re.search(r"(?:LaTeX errors? in|error in) ([a-z_]+)", issue)
    if m:
        return m.group(1)
    return None


def finding_from_issue(issue: str, ct_key: str, question_no: int, line: Optional[int] = None) -> Finding:
    m = _CODE_RE.match(issue)
    code = m.group(1).strip() if m else "CHECK"
    field = _field_from_issue(issue)
    if field == "root":
        field = None
    text = issue[m.end():].strip() if m else issue.strip()
    text = re.sub(r"^Field '[^']*':\s*", "", text)
    text = re.sub(r"^(?:root\.)?[A-Za-z_][\w\[\].]*:\s+(?=Make sure)", "", text)
    text = re.sub(r"^Value error,\s*", "", text)
    return Finding(message=text, code=code, ct_key=ct_key, question_no=question_no,
                   field=field, line=line)


# --------------------------------------------------------------------------- local verifier

def pydantic_problem() -> Optional[str]:
    """None when the vendored models can run, else a short reason."""
    try:
        import pydantic  # noqa: F401
    except ImportError:
        return "pydantic is not installed"
    version = getattr(pydantic, "VERSION", getattr(pydantic, "__version__", "?"))
    if not str(version).startswith("2."):
        return f"pydantic {version} is installed but 2.x is required"
    return None


def local_question_verifier() -> QuestionVerifier:
    """Vendored backend AlgorithmicVerifier, remote LaTeX parser disabled."""
    skill_root = os.path.dirname(_HERE)
    if skill_root not in sys.path:
        sys.path.insert(0, skill_root)
    from qc_models.algorithmic_verifier import AlgorithmicVerifier  # type: ignore
    from qc_models.contract_utils import prepare_question_for_algorithmic_verification  # type: ignore

    verifier = AlgorithmicVerifier(parser_latex_validation_enabled=False)

    async def verify(question: Dict[str, Any]) -> List[str]:
        result = await verifier.verify(prepare_question_for_algorithmic_verification(question))
        return list(result.get("issues", []))

    return verify


# --------------------------------------------------------------------------- topic checks

def check_topic_structure(topic: Any, source_lines: Optional[Dict[Tuple[str, int], int]] = None
                          ) -> Tuple[List[Finding], List[Tuple[str, int, Dict[str, Any], Optional[int]]]]:
    """Topic-level identity and canonical-format checks.

    Returns (findings, questions) where questions lists (ct_key, question_no, payload, line)
    for every addressable question, for per-question verification.
    """
    findings: List[Finding] = []
    questions: List[Tuple[str, int, Dict[str, Any], Optional[int]]] = []
    source_lines = source_lines or {}

    def topic_error(msg: str, code: str = "TOPIC", **kw: Any) -> None:
        findings.append(Finding(message=msg, code=code, **kw))

    if not isinstance(topic, dict) or not isinstance(topic.get("cts"), list):
        topic_error("Topic JSON must be an object with a 'cts' list")
        return findings, questions
    topic_id = topic.get("topic_id")
    if not isinstance(topic_id, str) or not topic_id.strip():
        topic_error("Missing 'topic_id' (non-empty string). The parser assigns one for new topics.")
    if not isinstance(topic.get("topic_name"), str) or not topic.get("topic_name", "").strip():
        findings.append(Finding("Missing 'topic_name'", "TOPIC", severity="warning"))
    try:
        index = tp_identity().build_ct_index(topic)
    except ValueError as exc:
        topic_error(str(exc), "IDENTITY")
        return findings, questions

    languages: Dict[str, int] = {}
    for ct_key, ct in index.items():
        difficulty = ct.get("difficulty_level")
        if difficulty not in tp.DIFFICULTIES:
            topic_error(f"CT difficulty_level must be EASY, MEDIUM or HARD (got {difficulty!r})", "CT", ct_key=ct_key)
        try:
            resolved = tp_identity().list_resolved_questions(ct, ct_key=ct_key)
        except ValueError as exc:
            topic_error(str(exc), "IDENTITY", ct_key=ct_key)
            continue
        if not resolved:
            topic_error("CT has no variations", "CT", ct_key=ct_key)
        explicit = bool(resolved) and "question_no" in resolved[0].payload
        if resolved and not explicit:
            findings.append(Finding("Legacy positional CT: questions have no question_no; IDs follow list order",
                                    "IDENTITY", severity="warning", ct_key=ct_key))
        types = set()
        for rq in resolved:
            q, qno = rq.payload, rq.question_no
            line = source_lines.get((ct_key, qno))
            types.add(q.get("question_type"))
            if "ct_key" in q and q["ct_key"] != ct_key:
                topic_error(f"ct_key {q['ct_key']!r} does not match its CT", "IDENTITY", ct_key=ct_key, question_no=qno, line=line)
            elif explicit and "ct_key" not in q:
                findings.append(Finding("Question has question_no but no ct_key", "IDENTITY",
                                        severity="warning", ct_key=ct_key, question_no=qno, line=line))
            qd = q.get("difficulty_level")
            if qd is not None and difficulty in tp.DIFFICULTIES and qd != difficulty:
                findings.append(Finding(f"difficulty_level {qd!r} differs from the CT difficulty {difficulty!r}",
                                        "SYSTEM FIELDS", ct_key=ct_key, question_no=qno, field="difficulty_level", line=line))
            lang = q.get("language")
            if isinstance(lang, str):
                if tp.canonical_language(lang) != lang:
                    findings.append(Finding(f"Unsupported language {lang!r}. Supported: {', '.join(tp.SUPPORTED_LANGUAGES)}",
                                            "LANGUAGE", ct_key=ct_key, question_no=qno, field="language", line=line))
                languages[lang] = languages.get(lang, 0) + 1
            for i, child in enumerate(q.get("subparts") or []):
                if isinstance(child, dict) and "difficulty_level" in child:
                    findings.append(Finding("Subparts must omit difficulty_level (it comes from the parent)",
                                            "SYSTEM FIELDS", severity="warning", ct_key=ct_key,
                                            question_no=qno, field=f"subparts[{i}].difficulty_level", line=line))
            questions.append((ct_key, qno, q, line))
        if len(types) > 1:
            findings.append(Finding(f"CT mixes question types {sorted(map(str, types))}; v1 expects one type per CT",
                                    "CT", severity="warning", ct_key=ct_key))
    if len(languages) > 1:
        findings.append(Finding(f"Topic mixes languages {sorted(languages)}; v1 expects one topic language",
                                "LANGUAGE", severity="warning"))
    return findings, questions


# --------------------------------------------------------------------------- style (skill-only warnings)

_MATH_OR_CODE_RE = re.compile(r"\\\(.*?\\\)|\\\[.*?\\\]|\$\$.*?\$\$|`[^`\n]*`", re.S)
_EMPHASIS_RES = [
    re.compile(r"\*\*[^*\n]+?\*\*"),
    re.compile(r"(?<![\w\\*])\*(?![\s*])[^*\n]+?(?<![\s\\])\*(?![\w*])"),
    re.compile(r"(?<![\w\\])__(?!\s)[^_\n]+?(?<!\s)__(?![\w])"),
    re.compile(r"(?m)^#{1,6}\s"),
]
_TEXT_KEYS = ("question", "solution", "hint", "answer_box", "options", "correct_keyword",
              "incorrect_keywords", "left", "right", "explanation")
_NON_PORTABLE_REGEX = re.compile(r"\(\?[aiLmsux-]+\)|\(\?<[=!]|\(\?P?<\w|\(\?#|\\[AZz]")


def _texts(value: Any) -> List[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        out: List[str] = []
        for item in value:
            if isinstance(item, dict) and item.get("type") == "text":
                out.append(str(item.get("text", "")))
            elif not isinstance(item, dict):
                out.extend(_texts(item))
        return out
    return []


def style_findings(q: Dict[str, Any], ct_key: str, qno: int, line: Optional[int], path: str = "") -> List[Finding]:
    """Warnings the platform verifier doesn't raise but its generation rules forbid."""
    found: List[Finding] = []
    for key in _TEXT_KEYS:
        if key not in q:
            continue
        for text in _texts(q[key]):
            masked = _MATH_OR_CODE_RE.sub(" ", text)
            if any(r.search(masked) for r in _EMPHASIS_RES):
                found.append(Finding("Markdown emphasis or heading inside a field; fields are plain text + LaTeX "
                                     "(write scientific names as \\(\\textit{...}\\))", "STYLE", severity="warning",
                                     ct_key=ct_key, question_no=qno, field=f"{path}{key}", line=line))
                break
    for i, ph in enumerate(q.get("placeholders") or []):
        if not isinstance(ph, dict):
            continue
        for key in ("correct_keyword", "incorrect_keywords"):
            if key in ph:
                found.extend(style_findings({key: ph[key]}, ct_key, qno, line, f"{path}placeholders[{i}]."))
        if q.get("question_type") == "PATTERN_MATCH" and isinstance(ph.get("value"), str) \
                and _NON_PORTABLE_REGEX.search(ph["value"]):
            found.append(Finding("Regex uses engine-specific syntax (inline flags, lookbehind, named groups or \\A/\\Z); "
                                 "the learner-side grader may not support it. Use classes like [Tt] instead",
                                 "STYLE", severity="warning", ct_key=ct_key, question_no=qno,
                                 field=f"{path}placeholders[{i}].value", line=line))
    for i, m in enumerate(q.get("matches") or []):
        if isinstance(m, dict):
            found.extend(style_findings(m, ct_key, qno, line, f"{path}matches[{i}]."))
            explanation = m.get("explanation")
            if explanation is None or (isinstance(explanation, str) and not explanation.strip()):
                found.append(Finding("Match has no explanation; the platform's topic preview needs one for every match",
                                     "PLATFORM", severity="warning", ct_key=ct_key, question_no=qno,
                                     field=f"{path}matches[{i}].explanation", line=line))
    for i, child in enumerate(q.get("subparts") or []):
        if isinstance(child, dict):
            found.extend(style_findings(child, ct_key, qno, line, f"{path}subparts[{i}]."))
    return found


_IDENTITY = None


def tp_identity():
    """topic_identity module: the vendored copy offline, injectable by the server."""
    global _IDENTITY
    if _IDENTITY is None:
        skill_root = os.path.dirname(_HERE)
        if skill_root not in sys.path:
            sys.path.insert(0, skill_root)
        from qc_models import topic_identity  # type: ignore
        _IDENTITY = topic_identity
    return _IDENTITY


async def validate_topic_async(topic: Any, *, verifier: Optional[QuestionVerifier] = None,
                               source_lines: Optional[Dict[Tuple[str, int], int]] = None,
                               only: Optional[Sequence[Tuple[str, int]]] = None,
                               concurrency: int = 8) -> Report:
    """Full validation. `verifier` defaults to the local vendored verifier.

    `only` limits per-question verification to these (ct_key, question_no) pairs
    (topic-level checks still run).
    """
    findings, questions = check_topic_structure(topic, source_lines)
    model_checks = True
    if verifier is None and pydantic_problem():
        findings.append(Finding(f"Question-model validation skipped: {pydantic_problem()}. Only structure "
                                "and IDs were checked; install pydantic>=2 (if allowed) and re-run.",
                                "SETUP", severity="warning"))
        model_checks = False
    verify = verifier or (local_question_verifier() if model_checks else None)
    wanted = set(only) if only is not None else None
    sem = asyncio.Semaphore(max(1, concurrency))

    async def run(ct_key: str, qno: int, payload: Dict[str, Any], line: Optional[int]) -> List[Finding]:
        async with sem:
            issues = await verify(payload)
        return [finding_from_issue(i, ct_key, qno, line) for i in issues]

    for ct_key, qno, payload, line in questions:
        if wanted is None or (ct_key, qno) in wanted:
            findings.extend(style_findings(payload, ct_key, qno, line))
    targets = [q for q in questions if model_checks and (wanted is None or (q[0], q[1]) in wanted)]
    for result in await asyncio.gather(*(run(*q) for q in targets)):
        findings.extend(result)
    cts = len(topic.get("cts", [])) if isinstance(topic, dict) and isinstance(topic.get("cts"), list) else 0
    return Report(findings=findings, cts=cts, questions=len(questions), model_checks=model_checks)


def validate_topic(topic: Any, **kwargs: Any) -> Report:
    return asyncio.run(validate_topic_async(topic, **kwargs))


# --------------------------------------------------------------------------- output

def format_report(report: Report, source: str = "") -> str:
    lines: List[str] = []
    by_question: Dict[Tuple[Optional[str], Optional[int]], List[Finding]] = {}
    for f in report.findings:
        by_question.setdefault((f.ct_key, f.question_no), []).append(f)
    for (ct_key, qno), items in by_question.items():
        head = "Topic" if ct_key is None else (f"CT {ct_key}" if qno is None else f"CT {ct_key} / Variant {qno}")
        line = next((f.line for f in items if f.line), None)
        lines.append(f"{head}" + (f" ({source}:{line})" if line and source else ""))
        for f in items:
            field = f" [{f.field}]" if f.field else ""
            tag = " (warning)" if f.severity == "warning" else ""
            lines.append(f"  - {f.code}{field}{tag}: {f.message}")
    n_err, n_warn = len(report.errors), len(report.findings) - len(report.errors)
    bad = len(report.invalid_questions())
    if report.valid and not report.model_checks:
        lines.append(f"STRUCTURE OK, MODELS NOT CHECKED: {report.cts} CTs, {report.questions} questions. "
                     "Question-model validation needs pydantic 2.x; report this as not fully validated.")
    elif report.valid:
        lines.append(f"VALID: {report.cts} CTs, {report.questions} questions"
                     + (f", {n_warn} warning(s)" if n_warn else "")
                     + ". The platform's LaTeX parser is not run offline and can still flag a block on import.")
    else:
        lines.append(f"INVALID: {n_err} error(s) in {bad} question(s)"
                     + (" plus topic-level errors" if any(f.ct_key is None or f.question_no is None for f in report.errors) else "")
                     + f"; {n_warn} warning(s). Fix only the reported items, re-run the parser, then this validator.")
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Validate a topic (.json or topic-md .md) offline.")
    parser.add_argument("input")
    parser.add_argument("--json", action="store_true", help="print the report as JSON")
    parser.add_argument("--partial", action="store_true",
                        help="topic still being written: fewer CTs than 'Total CTs' is only a warning")
    args = parser.parse_args(argv)
    try:
        topic, issues, info = tp.load_topic_file(args.input, partial=args.partial)
    except tp.ConversionError as exc:
        if args.json:
            print(json.dumps({"valid": False, "parse_errors": [i.to_dict() for i in exc.issues]}, ensure_ascii=False, indent=2))
        else:
            for i in exc.issues:
                print(i.format())
            print("INVALID: the Markdown could not be converted; fix the errors above first.")
        return 1
    except OSError as exc:
        print(f"ERROR: cannot read {args.input}: {exc}", file=sys.stderr)
        return 2
    report = validate_topic(topic, source_lines=info.get("source_lines"))
    if args.json:
        print(json.dumps(report.to_dict(), ensure_ascii=False, indent=2))
    else:
        for i in issues:
            print(i.format())
        print(format_report(report, os.path.basename(args.input) if args.input.endswith(".md") else ""))
    if not report.valid:
        return 1
    return 0 if report.model_checks else 3


if __name__ == "__main__":
    sys.exit(main())
